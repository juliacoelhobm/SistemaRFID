export type BluetoothPeripheral = {
  id: string;
  name: string;
  serviceUUIDs: Array<string>;
  manufacturerData:string
};
