import React, {useState,useEffect, useCallback} from 'react'
import {KeyboardAvoidingView, Platform, View,TouchableHighlight, ScrollView, TouchableOpacity, StyleSheet} from 'react-native'
import {TextInput, Text, Button, useTheme} from 'react-native-paper'
import { useDispatch } from 'react-redux';
import {loginStart} from './../../redux/user/userActions'
import {connect} from 'react-redux'
import {RootState} from './../../redux/RootReducer'
import BtnSocialLogin from './../../components/btn-social-login/BtnSocialLogin'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { loggedSuccessStart} from './../../redux/user/userActions'

export interface LoginProps{
  isLoading : boolean,
  errorMessage : string
}

const Login = ({isLoading, errorMessage}:LoginProps)=>{
	const {colors} = useTheme();
	// console.log("login view")
	const [email, setEmail] = useState('')
	const [password, setPassword] = useState('')
	const dispatch = useDispatch()

// 	useEffect(() => {
// 		console.log('disparou o listener')
// /* later */

// 		  const listener = ({ payload: { event, data } }) => {
// 		 	console.log("greetings  listen  auth ===>>> ", event, data)
// 		      switch (event) {
// 		      	case 'parsingCallbackUrl':

// 		      		if(data&&data.url){
// 		      			console.log("url =====> ",data.url)
// 		      			if(data.url == "myapp://"){
// 		      				// Hub.remove('auth', listener)
// 		      				return 
// 		      			}
// 		      			console.log('passed ...')
// 		      			const urlList = data.url.split('#')[1]
// 		      			const token = urlList.split('&')[0].split('=')[1]
// 		      			console.log('token ====>>> ',token)
// 		      			const jsonValue =  JSON.stringify(token);
						
// 		    			const result =  AsyncStorage.setItem('AUTH_USER_TOKEN_KEY', jsonValue)		  
		    			

// 		      			if (token)
		      				
// 		      				dispatch(loggedSuccessStart())
// 		      				Hub.remove('auth', listener)
// 		      				// dispatch(getUserStart())
// 		      			}
		      			
		     
// 		      		break
// 		        case "signIn":
// 		          console.log("Sign in");
		          
// 		          break;
// 		        case "signOut":
// 		          console.log("Sign out");
// 		          break;
// 		        default:
// 		          break;
// 		      }
//     }
//     Hub.listen("auth", listener)
	    
//   }, []);

	const loginAccess = ()=> {

		const credentials= {
	  		email ,
	  		password
	  	}
	  	return dispatch (loginStart(credentials))

	}

	const googleLogin = useCallback(async () => {

			/* try{
				const resp = await Auth.federatedSignIn({provider: CognitoHostedUIIdentityProvider.Google })
					if(resp){
						console.log('resp google ===> ',resp)
						
					}else{
						console.log('resp google error',resp)
				}
				
			} catch(error){
				console.log('error google', error)
			} */

        
    	}, []);

		
	

	 // const { type, token, expires } = await Expo.Facebook.logInWithReadPermissionsAsync('YOUR_FACEBOOK_APP_ID', {
   //      permissions: ['public_profile'],
   //    });
   const type = 'success'
    // if (type === 'success') {
    //   // sign in with federated identity
    //   // { token, expires_at: expires},
    //   Auth.federatedSignIn('facebook',  { name: 'USER_NAME' })
    //     .then(credentials => {
    //       console.log('get aws credentials', credentials);
    //     }).catch(e => {
    //       console.log(e);
    //     });
    // }
	
	const facebookLogin =async ()=> {
		
		try {

			/* await Auth.federatedSignIn({ provider: 'Facebook' , }).then(
				(resp)=>{
				 console.log('resp facebook ===> ',resp)
				 // setTimeout(getSession,500)
				},(error)=>{
					console.log('resp facebook error',error)
			}) */
			// var linkpp = 'https://graph.facebook.com/' + response.id + '/picture?type=small';


		}catch(error){
			console.log('error facebook', error)

		}
	}
	return (
		<KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}>
		
			
			<TouchableOpacity style={styles.touch} onPress={() => facebookLogin() }>
						<BtnSocialLogin Provider='facebook' Icon='facebook' />
					</TouchableOpacity>
					<TouchableOpacity style={styles.touch} onPress={() => googleLogin()}>
						<BtnSocialLogin Provider='google' Icon='google' />
					</TouchableOpacity>
			<Text style={{color:'#c6c6c6'}}>ou</Text>
			
			<View style={styles.textFields}>
				<ScrollView>
				<Text style={styles.text}>
	      			E-mail
	      		</Text>
				<TextInput  style={{marginTop:-15,color:'black', backgroundColor:'white'}} autoCapitalize='none' label="Email" value={email}
      			onChangeText={email => setEmail(email)} />
      			<Text style={styles.text}>
      				Senha
      			</Text>
      			<TextInput style={{marginTop:-10,color:'black', backgroundColor:'white'}} label="Senha" autoCapitalize='none' secureTextEntry={true}
      		       			value={password}
      			onChangeText={password => setPassword(password)} />
			
      		<Text>
      			{errorMessage}
      		</Text>
				</ScrollView>
			</View>
			
			<Button  autoCapitalize='none' style={[styles.button, {backgroundColor: colors.primaryButton}]} onPress={()=>loginAccess()} loading={isLoading}>
      			<Text autoCapitalize='none'  style={{color:'#c6c6c6'}}> 
				  Entrar
				</Text>
      		</Button>
      		<Text style={{fontFamily:'Poppins-Regular', color:'#c6c6c6',marginTop:20}}>Esqueceu a senha?</Text>
			

		
		</KeyboardAvoidingView>
		
		
		)
}
const mapStateToProps = (state : RootState)=>(
  {
    isLoading: state.user.isLoading , errorMessage : state.user.errorMessage
  }
)
export default connect(mapStateToProps)(Login)


const styles = StyleSheet.create({
	container : {
		flex: 1,
	    //justifyContent: "flex-start",
	    alignItems: "center",
	    paddingTop: 15,
	    backgroundColor:'white',
		height:'70%'
	},
	content:{
		padding:15
		,alignItems: "center"
		

	},
	textFields:{
		
		width:'90%',
		marginTop:0
	},
	text : {
		color:'black',
		fontSize:22,
		fontFamily : 'Poppins-Bold'
		,marginTop:5
		,height:45

	},
	title : {
		fontSize : 18
	}
	,subtitle : {
		fontSize : 14
	}
	,touch :{
		width:'90%'
		,alignItems: "center"
	},
	button:{ 
    
	    // flexDirection : 'row',
	    justifyContent : 'center',
	    alignItems : 'center',
	    width : '90%'
	    , borderWidth: 1
	    , borderColor : '#c6c6c6'
	    , borderRadius : 32
	    ,height : 50
	}
	, footer:{
		position : 'absolute',
		bottom : 0,
		height : 48,
		width : '100%',
		borderTopWidth : 1,
		borderTopColor: 'grey'

	},
	footerText:{
		color : 'grey',
		includeFontPadding : true,
		textAlignVertical : 'center',
		textAlign : 'center',
		fontSize : 16,
		paddingTop : 8

	},
	image:{
		marginTop:10,
		width:'98%'
		,height: 300
		,resizeMode: 'contain'
		// ,borderWidth:2
		// ,borderColor:'black'
		,alignItems: "center",
	}

})