import { useNavigation } from "@react-navigation/core";
import { StackNavigationProp } from "@react-navigation/stack";
import React, { useEffect, useState } from "react";
import { View, Text, Animated, Easing, StyleSheet } from "react-native";
import { Button, TextInput, ProgressBar, Colors , useTheme} from "react-native-paper";
import { SignUpStackParamList } from "../../navigation/SignUpNavigation";
import ModalWrapper from "./../../components/modalWrapper/ModalWrapper"
import Modal from "react-native-modal"

interface SignUpEmailProps {
	name: string;
	setName: (text: string) => void;
}

type SignUpEmailScreenProp = StackNavigationProp<
	SignUpStackParamList,
	"SignUpEmail"
>;

const SignUpEmail = ({ name, setName }: SignUpEmailProps) => {
	const navigation = useNavigation<SignUpEmailScreenProp>();
	const {colors} = useTheme();
	const [offsetX] = useState(new Animated.Value(-400));
	const [statusBar, setStatusBar] = useState(0);
	const [showModal, setShowModal] = useState(true);
	const translate = Animated.timing(offsetX, {
		toValue: 0,
		duration: 2000,
		easing: Easing.inOut(Easing.linear),
		useNativeDriver: true,
	});
	const reset = Animated.timing(offsetX, {
		toValue: -430,
		duration: 0,
		useNativeDriver: true,
	});
	const animation = Animated.sequence([translate, reset]);
	useEffect(() => {
		Animated.loop(animation).start();

		// Substitua esse setTimeout por uma chamada http ou qualquer outra chamada de serviço.
		setTimeout(() => {
			console.log("Chamar serviço");
		}, 1000);
	}, [animation]);

	useEffect(() => {
		setTimeout(() => setStatusBar(0.2), 700);
	}, []);

	const transform = { transform: [{ translateX: offsetX }] };
	return (

		<View style={styles.container}>
			{/*<ModalWrapper showModal={showModal} setShowModal={setShowModal} >
				<BlubbLanding showModal={showModal} setShowModal={setShowModal} />
			</ModalWrapper>*/}
			<View style={{ height: 140, width: "80%" }}>
				<Text style={{ marginVertical: 20, fontFamily:'Poppins-Regular', fontSize:18  }}>Qual seu nome ?</Text>
				<TextInput
					fontFamily={"Poppins-Regular"}
        			theme={{ fonts: { regular: "" } }}
					autoCapitalize='words' 
					mode={"outlined"}
					// style={styles.input}
					label={"Nome"}
					value={name}
					

					onChangeText={(text) => setName(text)}
				/>
			</View>
			<View style={{ width: "80%" }}>
				<Text style={{ marginLeft: "auto" }}>1 de 5</Text>
				<ProgressBar
					style={{ marginVertical: 20 }}
					progress={statusBar}
					color={Colors.black}
				/>
				<Button style={[styles.button , {backgroundColor: colors.primaryButton}]}
					mode="contained"
					contentStyle={{width: '100%',height:50}}
          			labelStyle={{width: '100%'}}
					onPress={() => navigation.navigate("SignUpEmail")}
				>
					Avançar
				</Button>
			</View>
		</View>
	);
};

export default SignUpEmail;
const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: "flex-start",
		alignItems: "center",
		paddingTop: 40,
		backgroundColor:'white'
	},
	syncContentContainer: {
		paddingHorizontal: 25,
		paddingTop: 40,
		paddingBottom: 20,
	},
	title1: {
		fontWeight: "700",
		fontSize: 32,
	},
	title3: {
		fontWeight: "700",
		fontSize: 18,
	},
	body2: {
		fontSize: 14,
	},
	syncProgressBarContainer: {
		flexDirection: "row",
	},
	syncProgressBar: {
		height: 4,
		marginHorizontal: 10,
		width: 200,
		backgroundColor: "#0000ff",
	},
	button:{ 
		
		flexDirection : 'row',
		justifyContent : 'center',
		alignItems : 'center',
		width : '100%'
		, borderWidth: 1
		, borderColor : '#c6c6c6'
		, borderRadius : 32
		
		,height : 50}
});

/*


			<Animated.View style={styles.syncProgressBarContainer}>
				<Animated.View style={[transform, styles.syncProgressBar]} />
				<Animated.View style={[transform, styles.syncProgressBar]} />
				<Animated.View style={[transform, styles.syncProgressBar]} />
				<Animated.View style={[transform, styles.syncProgressBar]} />
			</Animated.View>

*/
