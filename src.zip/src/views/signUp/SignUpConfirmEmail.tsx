
import { useNavigation } from "@react-navigation/core";
import { StackNavigationProp } from "@react-navigation/stack";
import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import { Button, Colors, ProgressBar, TextInput, useTheme } from "react-native-paper";
import { SignUpStackParamList } from "../../navigation/SignUpNavigation";
import {useDispatch} from 'react-redux'
import {signUpConfirmationStart} from "./../../redux/user/userActions"
import {connect} from 'react-redux'
import {RootState} from './../../redux/RootReducer'

interface SignUpConfirmEmailProps {
  isConfirmedUser:boolean;
  userData:{name:string , email : string}
}

type SignUpConfirmEmailScreenProp = StackNavigationProp<
  SignUpStackParamList,
  "SignUpConfirmEmail"
>;


const SignUpConfirmEmail = ({ isConfirmedUser, userData }: SignUpConfirmEmailProps) => {
  const navigation = useNavigation<SignUpConfirmEmailScreenProp>();
  const [code, setCode] = useState('');
  const {colors} = useTheme();

  const [statusBar, setStatusBar] = useState(0.3);
  useEffect(() => {
    setTimeout(() => setStatusBar(0.6), 700);
  }, []);

  useEffect(() => {
      console.log("entrou no useEffect *****")
      if(isConfirmedUser){
        console.log("isConfirmedUser howold  =====> " , isConfirmedUser)
      navigation.navigate("SignIn");
    }
  }, [isConfirmedUser]);

  const dispatch = useDispatch();

  const callSignUpConfirm = ()=>{

    dispatch(signUpConfirmationStart({email:userData.email, code}))




    // navigation.navigate("login")
  }


  return (
    <View style={styles.container}>
      <View style={{ height: 140, width: "80%" }}>
        <Text style={{ marginVertical: 5 ,fontFamily:'Poppins-Regular', fontSize:18 }}>Um código de confirmação foi enviado para seu e-mail. Digite-o abaixo.</Text>
        <TextInput

          autoCapitalize='none' 
          label={"Código de confirmação"}
          // secureTextEntry={!showPassword}
          value={code}
          mode={"outlined"}
          style={styles.input}
          keyboardType='numeric'
          // right={
          //   showPassword ? (
          //     <TextInput.Icon
          //       name="eye"
          //       size={24}
          //       onPress={() => setShowPassword((prev) => !prev)}
          //     />
          //   ) : (
          //     <TextInput.Icon
          //       name="eye-off"
          //       size={24}
          //       onPress={() => setShowPassword((prev) => !prev)}
          //     />
          //   )
          // }
          onChangeText={(text) => setCode(text)}

        />
      </View>
      <View style={{ width: "80%" }}>
        <Text style={{ marginLeft: "auto" }}>5 de 5</Text>
        <ProgressBar
          style={{ marginVertical: 20 }}
          progress={statusBar}
          color={Colors.black}
        />
        <Button style={[styles.button , {backgroundColor: colors.primaryButton}]}
          mode="contained"
          contentStyle={{width: '100%',height:50}}
          labelStyle={{width: '100%'}}
          onPress={() => callSignUpConfirm()}
          // onPress={() => navigation.navigate("SignUpHowOld")}
        >
          Avançar
        </Button>
      </View>
    </View>
  );
};
const mapStateToProps = (state : RootState)=>(
  {
    isConfirmedUser: state.user.isConfirmedUser, userData: state.user.userData , errorMessage : state.user.errorMessage
  }
)
export default connect(mapStateToProps)(SignUpConfirmEmail)
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    paddingTop: 40,
    backgroundColor:'white'
  },
  input: {
    marginTop:10,
    paddingBottom: 0,
    marginBottom: 0,
  
    width: "100%",
    backgroundColor: "#efefef",
    height: 65,
    fontSize: 16,
    borderWidth:1
  },
  button:{ 
    
    flexDirection : 'row',
    justifyContent : 'center',
    alignItems : 'center',
    width : '100%'
    , borderWidth: 1
    , borderColor : '#c6c6c6'
    , borderRadius : 32
    
    ,height : 50}
});






// const handleSubmit = (event: React.FormEvent) => {
//     event.preventDefault();

//     const { confirmationCode } = this.state;

//     // show progress spinner
//     this.setState({ loading: true });

//     Auth.confirmSignUp(this.state.username, confirmationCode)
//       .then(() => {
//         this.handleOpenNotification('success', 'Succesfully confirmed!', 'You will be redirected to login in a few!');
//       })
//       .catch(err => {
//         this.handleOpenNotification('error', 'Invalid code', err.message);
//         this.setState({
//           loading: false
//         });
//       });
//   };
