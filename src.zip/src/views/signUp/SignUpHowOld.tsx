import { useNavigation } from "@react-navigation/core";
import { StackNavigationProp } from "@react-navigation/stack";
import React, { useEffect, useState } from "react";
import { Platform, StyleSheet,  Text, View, TouchableOpacity } from "react-native";
import { ProgressBar, Colors, Button, TextInput , useTheme} from "react-native-paper";
import { SignUpStackParamList } from "../../navigation/SignUpNavigation";
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment'
import {connect} from 'react-redux'
import {RootState} from './../../redux/RootReducer'
interface SignUpHowOldProps {
	birthdate: string;
	cognitoData : any;
	userData : any;
	isConfirmedUser : boolean;
	isLoading : boolean;
	setBirthdate: (text: Date) => void;
	signUp: () => void;
}

type SignUpHowOldScreenProp = StackNavigationProp<
	SignUpStackParamList,
	"SignUpHowOld"
>;

const SignUpHowOld = ({ birthdate, setBirthdate, signUp, cognitoData, isConfirmedUser, userData, isLoading }: SignUpHowOldProps) => {
	const [statusBar, setStatusBar] = useState(0.6);
	const [date, setDate] = useState(new Date(1598051730000));
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);
    const {colors} = useTheme();
    useEffect(() => {
    	console.log("entrou no useEffect *****")
    	console.log("userData howold  =====> " , userData)
    	console.log("isConfirmedUser howold  =====> " , isConfirmedUser)
	  	if(userData && userData.email && !isConfirmedUser){
	  	// if(cognitoData && cognitoData.user && !cognitoData.userConfirmed){
	  		console.log("cognitoData howold  =====> " , cognitoData)
			navigation.navigate("SignUpConfirmEmail");
		}
	}, [userData]);

  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    setShow(Platform.OS === 'ios');
    setDate(currentDate);
    moment.locale('pt-br');
    setBirthdate(moment(currentDate).format('DD-MM-YYYY'));
    console.log('currentDate', currentDate)
  };

  const callSignUp = async () =>{

  	const signUpValue = await signUp();
  	console.log("signUpValue ===> " , signUpValue)
  	
  }
  

	useEffect(() => {
		setTimeout(() => setStatusBar(.8), 700);
	}, []);
	const navigation = useNavigation<SignUpHowOldScreenProp>();
	

	return (
		<View style={styles.container}>
			<View style={{ height: 140, width: "80%" }}>
				<Text style={{ marginVertical: 20 }}>Qual sua data de nascimento ?</Text>
				<TouchableOpacity style={{width:'100%',height:60,borderWidth:2, }} onPress={()=>setShow(true)}>
					<View pointerEvents="none"> 
						<TextInput
							selectTextOnFocus={false}
							label={"Nascimento"}
							// mode={"outlined"}
							value={birthdate}
							style={{ height: 55, backgroundColor:'white',borderWidth:0 }}
							// onChangeText={(text) => setBirthdate(text)}
						/>
					</View>
				</TouchableOpacity>
			</View>
			<View style={{width:'100%',margin:0}}>
        
      			
				{show && (
			        <DateTimePicker
			          testID="dateTimePicker"
			          value={date}
			          mode={'date'}
			          is24Hour={true}
			          display="spinner"
			          onChange={onChange}
			          // style={{borderWidth:5}}
			        />
			        )}
			      
			</View>
			<View style={{ width: "80%" }}>
				<Text style={{ marginLeft: "auto" }}>4 de 5</Text>
				<ProgressBar
					style={{ marginVertical: 20 }}
					progress={statusBar}
					color={Colors.black}
				/>
				<Button style={[styles.button , {backgroundColor: colors.primaryButton}]}
					mode="contained"
					contentStyle={{width: '100%',height:50}}
          labelStyle={{width: '100%'}}
					loading={isLoading}
					onPress={() => {
						// navigation.navigate("SignUpEmail");
						callSignUp();

					}}
				>
					Avançar
				</Button>
			</View>
		</View>
	);
};
const mapStateToProps = (state : RootState)=>(
  {
    isLoading: state.user.isLoading, cognitoData: state.user.cognitoData, userData: state.user.userData, isConfirmedUser:state.user.isConfirmedUser , errorMessage : state.user.errorMessage
  }
)
export default connect(mapStateToProps)(SignUpHowOld)

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: "flex-start",
		alignItems: "center",
		paddingTop: 40,
		backgroundColor:'white'
	},
	button:{ 
		
		flexDirection : 'row',
		justifyContent : 'center',
		alignItems : 'center',
		width : '100%'
		, borderWidth: 1
		, borderColor : '#c6c6c6'
		, borderRadius : 32
		
		,height : 50}
});
