import { useNavigation } from "@react-navigation/core";
import { StackNavigationProp } from "@react-navigation/stack";
import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import { Button, Colors, ProgressBar, TextInput , useTheme} from "react-native-paper";
import { SignUpStackParamList } from "../../navigation/SignUpNavigation";

interface SignUpPasswordProps {
	password: string;
	setPassword: (text: string) => void;
}

type SignUpPasswordScreenProp = StackNavigationProp<
	SignUpStackParamList,
	"SignUpPassword"
>;
 
const SignUpPassword = ({ password, setPassword }: SignUpPasswordProps) => {
	const navigation = useNavigation<SignUpPasswordScreenProp>();
	const [showPassword, setShowPassword] = useState(false);
	const {colors} = useTheme();
	const [statusBar, setStatusBar] = useState(0.4);
	useEffect(() => {
		setTimeout(() => setStatusBar(0.6), 700);
	}, []);

	return (
		<View style={styles.container}>
			<View style={{ height: 140, width: "80%" }}>
				<Text style={{ marginVertical: 20, fontFamily:'Poppins-Regular', fontSize:18  }}>Qual sua senha ?</Text>
				<TextInput
					autoCapitalize='none' 
					label={"Senha"}
					secureTextEntry={!showPassword}
					value={password}
					mode={"outlined"}
					style={styles.input}
					right={
						showPassword ? (
							<TextInput.Icon
								name="eye"
								size={24}
								onPress={() => setShowPassword((prev) => !prev)}
							/>
						) : (
							<TextInput.Icon
								name="eye-off"
								size={24}
								onPress={() => setShowPassword((prev) => !prev)}
							/>
						)
					}
					onChangeText={(text) => setPassword(text)}
				/>
			</View>
			<View style={{ width: "80%" }}>
				<Text style={{ marginLeft: "auto" }}>3 de 5</Text>
				<ProgressBar
					style={{ marginVertical: 20 }}
					progress={statusBar}
					color={Colors.black}
				/>
				<Button style={[styles.button , {backgroundColor: colors.primaryButton}]}
					mode="contained"
					contentStyle={{width: '100%',height:50}}
          			labelStyle={{width: '100%'}}
					onPress={() => navigation.navigate("SignUpHowOld")}
				>
					Avançar
				</Button>
			</View>
		</View>
	);
};

export default SignUpPassword;
const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: "flex-start",
		alignItems: "center",
		paddingTop: 40,
		backgroundColor:'white'
	},
	input: {
		paddingBottom: 10,
		marginBottom: 10,
		width: "100%",
		backgroundColor: "#efefef",
		height: 50,
		fontSize: 16,
	},
	button:{ 
		
		flexDirection : 'row',
		justifyContent : 'center',
		alignItems : 'center',
		width : '100%'
		, borderWidth: 1
		, borderColor : '#c6c6c6'
		, borderRadius : 32
		
		,height : 50}
});
