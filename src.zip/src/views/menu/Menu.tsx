import React from 'react';

import {
  ActivityIndicator,	
  AppRegistry,
  Alert,
  Text,
  View,
  SafeAreaView,
  StyleSheet,
  PixelRatio,
  Platform,
  TouchableHighlight,
} from 'react-native';
const Menu = ()=>{
	return  <View><Text>Menu</Text></View>
}
export default Menu