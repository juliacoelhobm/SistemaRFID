import { StyleSheet, Text, View } from "react-native";
import React from "react";

type Props = {};

const Security = (props: Props) => {
  return (
    <View>
      <Text>Security</Text>
    </View>
  );
};

export default Security;

const styles = StyleSheet.create({});
