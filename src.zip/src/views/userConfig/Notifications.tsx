import { StyleSheet, Text, View } from "react-native";
import React from "react";

type Props = {};

const Notifications = (props: Props) => {
  return (
    <View>
      <Text>Notifications</Text>
    </View>
  );
};

export default Notifications;

const styles = StyleSheet.create({});
