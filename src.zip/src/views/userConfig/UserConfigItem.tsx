import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React from "react";
import { Button } from "react-native-paper";

type userConfigItemProps = {
  title: string;
  action: () => void;
};

const UserConfigItem = ({ title, action }: userConfigItemProps) => {
  return (
    <>
      <TouchableOpacity onPress={action} style={styles.userConfigItemStyles}>
        <View style={styles.userConfigItemTitleContainer}>
          <Button icon="account-circle">{""}</Button>
          <Text>{title}</Text>
        </View>
        <Button icon="chevron-right">{""}</Button>
      </TouchableOpacity>
    </>
  );
};

export default UserConfigItem;

const styles = StyleSheet.create({
  userConfigItemStyles: {
    borderBottomWidth: 1,
    padding: 15,
    margin: 5,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  userConfigItemTitleContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
});
