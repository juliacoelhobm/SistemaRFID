import {
  KeyboardAvoidingView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Image,
  TouchableOpacity,
  Platform
} from "react-native";
import { useDispatch } from 'react-redux';
import {updateUserStart} from './../../redux/userApp/userAppActions'
import React, { useState , useEffect} from "react";
import { Button , useTheme} from "react-native-paper";
import {connect} from 'react-redux'
import {RootState} from './../../redux/RootReducer'
import { UserDataApiType} from "./../../@types/user/user"

import IconCircle from './../../assets/png/showblubb/ring_gradient_130x130px.png';
import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png';

import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment'
// user_pict_gray_130x130px.png


export interface Props{
  isLoading : boolean,
  errorMessage : string,
  user : UserDataApiType,
  categories : any,
  selectedBlubb : any,
 
  collection : any,
  
  followersFromUser:any
  ,selectedUser:any
}

const EditProfile = ({isLoading, errorMessage, user}: Props) => {
  //const dispatch = useDispatch();
  const {colors} = useTheme();
  const [name, setName] = useState("");
  const [nickname, setNickname] = useState("");
  const [age, setAge] = useState("");
  const [address, setAddress] = useState("");
  const [bio, setBio] = useState("");
  const [filePath, setFilePath] = useState('');
  const [fileData, setFileData] = useState('');
  const [fileUri, setFileUri] = useState('');
  const [date, setDate] = useState(new Date(Date.now()));
  const [initiFileUri, setInitFileUri] = useState('');
  const [mode, setMode] = useState('date');
  const [show, setShow] = useState(false);
  const dispatch = useDispatch()

  useEffect(() => {
        setName(user.nome)
        setNickname(user.nickname || user.givenName)
        setBio(user.profile )
        setAge(user.birthdate)
        setAddress(user.address)
        if(user.picture){
          console.log('picture ===> ',user.picture)
          setFileUri(user.picture)
          setInitFileUri(user.picture)
        }
        console.log('user ===> ', user)
  },[user])

  const submitEditProfile = () => {
    const data:any = {
      name,
      nickname,
      
      address,
      profile : bio,
      // picture : user.picture
      // phoneNumber,
      // gender:
      // , categories
    };
    console.log('data to send ', data)
    filePath ? data.file = filePath : ''
    age ? data.birthdate= age : ''
    //Criar aq a chamada da ação updateUserStart passando os dados de input
    dispatch(updateUserStart(data))
  };

  const renderFileUri = () =>{
    console.log("fileUri",fileUri)
    if (fileUri) {
      return <Image
        source={{ uri: fileUri }}
        style={styles.selectedImages}
      />
    } else {      
        return <Image resizeMode='contain' source={IconUser} style={{width:'100%',height:100, marginBottom:10}} />
    }
  }

  const launchImageLibraryFunction = async () => {
    let options = {
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };
    const response = await launchImageLibrary(options)
      // console.log('Response = ', response);
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
        alert(response.customButton);
      } else {
        const source = { uri: response.uri };
        console.log('response library', JSON.stringify(response));
         const resp = response.assets[0]
          setFilePath(resp) 
          setFileData(resp.data)
          setFileUri(resp.uri)
      }
  }

  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    console.log('currentDate ==>',currentDate)
    setShow(Platform.OS === 'ios');
    setDate(currentDate);
    moment.locale('pt-br');
    setAge(moment(currentDate).format('DD-MM-YYYY'));
    console.log('currentDate', currentDate)
  };

  return (
    <KeyboardAvoidingView 
    behavior={Platform.OS === "ios" ? "padding" : "height"}
    style={styles.container}>
    
    <View style={styles.inner}>
      <View style={styles.photoPerfilContainer}>
        {renderFileUri()}
      </View>
      <View>
        <TouchableOpacity onPress={launchImageLibraryFunction} style={styles.btnIcon}  >
          <Text>Definir foto de perfil</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.infoContainer}>
      
        <Text style={styles.inputTitle}>Nome</Text>
        <TextInput
          value={name}
          onChangeText={(text) => setName(text)}
          placeholder="Escreva seu nome"
        />
        <Text style={styles.inputTitle}>Nickname</Text>
        <TextInput
          value={nickname}
          onChangeText={(text) => setNickname(text)}
          placeholder="Defina seu nome de usuário"
        />
        <View style={{ height: 100, width: "80%" }}>
       
        <Text style={styles.inputTitle}>Nascimento</Text>
        <TouchableOpacity style={{width:'100%',height:60 }} onPress={()=>setShow(true)}>
          <View pointerEvents="none"> 
            <TextInput
              selectTextOnFocus={false}
              label={"Nascimento"}
              // mode={"outlined"}
              value={age}
              style={{ height: 55, backgroundColor:'transparent',borderWidth:0 }}
              // onChangeText={(text) => setBirthdate(text)}
            />
          </View>
        </TouchableOpacity>
      </View>
      <View style={{width:'100%',margin:0}}>
        
            
        {show && (
              <DateTimePicker
                testID="dateTimePicker"
                value={date}
                mode={'date'}
                is24Hour={true}
                display="spinner"
                onChange={onChange}
                // style={{borderWidth:5}}
              />
              )}
            
      </View>
        <Text style={styles.inputTitle}>Mora onde ?</Text>
        <TextInput
          value={address}
          onChangeText={(text) => setAddress(text)}
          multiline
          placeholder="Escreva seu endereço"
        />
        <Text style={styles.inputTitle}>Quem é você ?</Text>
        <TextInput
          value={bio}
          onChangeText={(text) => setBio(text)}
          multiline
          placeholder="Escreva sua bio"
        />
        <Button
        loading={isLoading}
        style={{
          width: "60%",
          alignSelf: "center",
          borderRadius: 15,
          marginTop: 40,
          backgroundColor: colors.primaryButton
        }}
        mode="contained"
        onPress={() => submitEditProfile()}
      >
        Salvar
      </Button>

      </View>
      
      
      </View>

    </KeyboardAvoidingView>
  );
};


const profileStateToProps = (state : RootState)=>(
  {
    user : state.userApp.user, selectedUser: state.userApp.selectedUser , followersFromUser:state.userApp.followersFromUser ,categories:state.categories.categories, isLoading: state.userApp.isLoading , errorMessage : state.user.errorMessage
  }
)



export default connect(profileStateToProps)(EditProfile)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // padding: 20,
    backgroundColor:'white'
    ,height:'80%'
  },
  inner: {
    padding: 24,
    flex: .9,
    justifyContent: "space-around"
  },
  selectedImages:{
    width:50,
    height:100,
    alignItems: "center",
    resizeMode:'contain',
    // marginTop:50
    // marginBottom:50
    borderRadius:120/2
  },
  photoPerfilContainer: {
    borderBottomWidth: 1,
    //
    height:100,
    alignItems:'center'
    // ,borderWidth:1
  },
  btnIcon:{
    marginTop:5,
    // height:25,
    // borderWidth:1,
    // borderColor:'black',
    alignItems:'center',
  },
  infoContainer: {
    padding: 2,
    backgroundColor:'white'
  },
  inputTitle: {
    fontSize: 24,
  },
});
