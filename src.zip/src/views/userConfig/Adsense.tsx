import { StyleSheet, Text, View } from "react-native";
import React from "react";

type Props = {};

const Adsense = (props: Props) => {
  return (
    <View>
      <Text>Adsense</Text>
    </View>
  );
};

export default Adsense;

const styles = StyleSheet.create({});
