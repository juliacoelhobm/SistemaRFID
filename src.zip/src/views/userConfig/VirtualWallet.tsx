import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { Button } from "react-native-paper";

type Props = {};

const VirtualWallet = (props: Props) => {
  // const dispatch = useDispatch();

  const buyPloCoins = () => {
    // dispatch(butPloCoinsStart())
  };

  const checkHistory = () => {
    // dispatch(checkHistoryStart())
  };

  return (
    <View style={styles.container}>
      <View>
        <Text>
          Na Carteira Virtual você administra suas PLoCoins, a moeda usada para
          aumentar o tempo que suas Blubbs ficarão disponíveis onde você as
          publicou.
        </Text>
      </View>
      <View style={styles.walletAlertContainer}>
        <Text>Saldo em PloCoins</Text>
        <Text>PLC 0,00</Text>
      </View>
      <View style={styles.buttonContainer}>
        <Button
          style={styles.btn}
          mode="contained"
          onPress={() => buyPloCoins()}
        >
          Comprar PloCoins
        </Button>
        <Button
          style={styles.btn}
          mode="contained"
          onPress={() => checkHistory()}
        >
          Ver Histórico
        </Button>
      </View>
    </View>
  );
};

export default VirtualWallet;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "space-between",
  },
  walletAlertContainer: {
    borderRadius: 300,
    flex: 0.7,
    borderWidth: 2,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonContainer: {
    justifyContent: "space-between",
  },
  btn: {
    marginTop: 10,
    borderRadius: 15,
  },
});
