import { StyleSheet, Text, View } from "react-native";
import React from "react";
import UserConfigItem from "./UserConfigItem";

type Props = {};

const InviteFriends = (props: Props) => {
  const inviteFriendsMenu = [
    {
      title: "Convidar amigos por SMS",
      action: () => console.log("convidar por sms"),
    },
    {
      title: "Convidar amigos por email",
      action: () => console.log("convidar por email"),
    },
  ];
  return (
    <View>
      {inviteFriendsMenu.map((item, idx) => (
        <UserConfigItem key={idx} title={item.title} action={item.action} />
      ))}
    </View>
  );
};

export default InviteFriends;

const styles = StyleSheet.create({});
