import { StyleSheet, Text, View } from "react-native";
import React from "react";

type Props = {};

const Privacy = (props: Props) => {
  return (
    <View>
      <Text>Privacy</Text>
    </View>
  );
};

export default Privacy;

const styles = StyleSheet.create({});
