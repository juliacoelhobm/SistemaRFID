import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList,
} from "react-native";
import React from "react";
import {useDispatch} from "react-redux"
import { Button, Divider } from "react-native-paper";
import {logout} from "./../../redux/user/userActions"
import {logoutStart} from "./../../redux/userApp/userAppActions"
import UserConfigItem from "./UserConfigItem";

type Props = {
  navigation: any;
};

const UserConfig = ({ navigation }: Props) => {
  const dispatch = useDispatch();
  const userConfigMenu = [
    {
      title: "Editar Perfil",
      action: () => navigation.navigate("EditProfile"),
      imgIcon: "",
    },
    {
      title: "Convidar amigos",
      action: () => navigation.navigate("InviteFriends"),
      imgIcon: "",
    },
    {
      title: "Carteira Virtual",
      action: () => navigation.navigate("VirtualWallet"),
      imgIcon: "",
    },
    {
      title: "Conta",
      action: () => navigation.navigate("Account"),
      imgIcon: "",
    },
    {
      title: "Notificações",
      action: () => navigation.navigate("Notifications"),
      imgIcon: "",
    },
    {
      title: "Privacidade",
      action: () => navigation.navigate("Privacy"),
      imgIcon: "",
    },
    {
      title: "Segurança",
      action: () => navigation.navigate("Security"),
      imgIcon: "",
    },
    {
      title: "Anúncios",
      action: () => navigation.navigate("Adsense"),
      imgIcon: "",
    },
    {
      title: "Ajuda",
      action: () => navigation.navigate("Help"),
      imgIcon: "",
    },
    {
      title: "Sobre",
      action: () => navigation.navigate("About"),
      imgIcon: "",
    },
    {
      title: "Sair",
      //IMPORTAR AÇÃO DE FAZER O LOGOUT
      action: () => {
        dispatch(logout())
        dispatch(logoutStart())
      }
      
    },
  ];
  return (
    <View>
      <FlatList
        data={userConfigMenu}
        renderItem={(item) => (
          <UserConfigItem
            key={item.index}
            title={item.item.title}
            action={item.item.action}
          />
        )}
        keyExtractor={(item) => item.title}
      />
    </View>
  );
};

export default UserConfig;

const styles = StyleSheet.create({});
