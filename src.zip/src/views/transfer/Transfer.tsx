import {
    KeyboardAvoidingView,
    StyleSheet,
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    Platform,
    ScrollView
  } from "react-native";
  import { useDispatch } from 'react-redux';
  import { useNavigation} from '@react-navigation/native'
  import {updateUserStart} from './../../redux/userApp/userAppActions'
  import {postProductStart, updateProductStart} from './../../redux/products/productsActions'
  import React, { useState , useEffect} from "react";
  import { Button , useTheme,DataTable} from "react-native-paper";
  import {connect} from 'react-redux'
  import {RootState} from './../../redux/RootReducer'
  import { UserDataApiType} from "./../../@types/user/user"
  import { ProdutoDataApiType} from "./../../@types/produto/produto"
  import { Badge, ListItem, Icon } from '@rneui/themed'
  import {CategoriasDataApiType} from "./../../@types/categories/categories"
  import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
  import DateTimePicker from '@react-native-community/datetimepicker';
  import moment from 'moment'
  import MapView, { Marker } from 'react-native-maps';
import { ICON_SIZE } from "react-native-paper/lib/typescript/components/TextInput/Adornment/TextInputIcon";
  // user_pict_gray_130x130px.png

  import csv from 'csvtojson';
  
  export interface Props{
    isLoading : boolean,
    errorMessage : string,
    user : UserDataApiType,
    categories :CategoriasDataApiType,
    selectedBlubb : any,
    collection : any,
    product:ProdutoDataApiType,
    products:Array<[]>,
    productsList:[]
  }
  const Transfer=({isLoading, errorMessage, user, product, products, productsList, categories}: Props)=> {
  
    const [page, setPage] = React.useState(0);
    const [numberOfItemsPerPage, setNumberOfItemsPerPage] = React.useState(10);
  /*   const [csvRow, setCsvRow]=React.useState(10);
    const [pages, setPages]=React.useState(10); */
    const [csvFileUrl, setCsvFileUrl]=React.useState('http://venegas.com.br/rfid/data/data.csv');
    const [numItemsPerPage, setNumItemsPerPage]=React.useState(10);
                
               
  
    const [state, setState] = React.useState({
      tableHead: [],
      tableData: [
        []
      ],
      currentPageData: [
        []
      ],
      numberOfPages: 1
    });
  
    useEffect(() => {
      setTableData(csvFileUrl);
      setNumberOfItemsPerPage(numItemsPerPage);
    }, []);
  
    useEffect(() => {
      setCurrentPageData();
    }, [page]);
  
    useEffect(() => {
      setCurrentPageData();
    }, [state.tableData]);
  
    const setCurrentPageData = () => {
      const startIndex = page * numberOfItemsPerPage;
      let endIndex = startIndex + numberOfItemsPerPage;
      if (endIndex > state.tableData.length) {
        endIndex = state.tableData.length - 1;
      }
      if (state.tableData.length > 1) {
        setState({
          ...state,
          currentPageData: state.tableData.slice(startIndex, endIndex)
        });
      }
    }
  
    const setTableData = (csvFileUrl: any) => {
      fetch(csvFileUrl)
        .then(async (response) => {
          const resp = await response.text();
          csv({
            noheader: true,
            output: "csv"
          }).fromString(resp)
            .then((csvRow) => {
              let pages = (csvRow.length / numberOfItemsPerPage);
              if (csvRow.length > numberOfItemsPerPage * pages) {
                pages = pages + 1;
              }
              setState({
                ...state,
                tableHead: csvRow[0],
                tableData: csvRow.slice(1),
                numberOfPages: pages
              });
            })
        })
        .catch((error) => {
          console.error("some error occurred", error);
        });
    }
  
    return (
      <View style={styles.container}>
        <DataTable>
          <DataTable.Header>
            {
              state.tableHead.map((rowData, index) => (
                <DataTable.Title key={index}>{rowData}</DataTable.Title>
              ))
            }
          </DataTable.Header>
  
          {
            state.currentPageData.map((rowData, index) => (
              <DataTable.Row key={index}>
                {
                  rowData.map((cellData, cellIndex) => (
                    <DataTable.Cell key={cellIndex}>{cellData}</DataTable.Cell>
                  ))
                }
              </DataTable.Row>
            ))
          }
  
          <DataTable.Pagination
            page={page}
            numberOfPages={state.numberOfPages}
            onPageChange={(page) => setPage(page)}
            label={`Page ${page + 1} of ${state.numberOfPages}`}
            showFastPagination
            optionsLabel={'Rows per page'}
          />
        </DataTable>
      </View>
    );
  };

  
  
  const stateToProps = (state : RootState)=>(
    {
      user : state.userApp.user, selectedUser: state.userApp.selectedUser, productsList: state.products.productsList ,products:state.products.products, product:state.products.product, isLoading: state.userApp.isLoading , errorMessage : state.user.errorMessage
    }
  )
  
  
  
  export default connect(stateToProps)(Transfer)
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      // padding: 20,
      backgroundColor:'white'
      //,height:'80%'
    },
    
    head: {
      height: 40, backgroundColor: '#f1f8ff', color: '#fff'
    },
    text: { margin: 6 },
    contentContainer:{
      borderColor:'black',
      borderWidth:2,
      padding:10,
      //backgroundColor:'red'
      //height:150
    },
    topStyle: {
      padding: 12,
      justifyContent: "space-around"
    },
    selectedImages:{
      width:200,
      height:200,
      alignItems: "center",
      // resizeMode:'contain',
      // marginTop:50
      marginBottom:10,
      borderRadius:200/6
    },
    photoPerfilContainer: {
      //borderBottomWidth: 1,
      height:130,
      alignItems:'center'
      
    },
    btnIcon:{
      marginTop:5,
      // height:25,
      // borderWidth:1,
      // borderColor:'black',
      alignItems:'center',
    },
    infoContainer: {
      padding: 2,
      backgroundColor:'white'
    },
    inputTitle: {
      fontSize: 18,
      paddingVertical:2
    },
    inputText: {
      fontSize: 20,
    },
  });
  