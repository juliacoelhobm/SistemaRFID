import {
    KeyboardAvoidingView,
    StyleSheet,
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    Platform,
    ScrollView
  } from "react-native";
  import { useDispatch } from 'react-redux';
  import { useNavigation} from '@react-navigation/native'
  import {updateUserStart} from './../../redux/userApp/userAppActions'
  import {postProductStart, updateProductStart} from './../../redux/products/productsActions'
  import React, { useState , useEffect} from "react";
  import { Button , useTheme} from "react-native-paper";
  import {connect} from 'react-redux'
  import {RootState} from './../../redux/RootReducer'
  import { UserDataApiType} from "./../../@types/user/user"
  import { ProdutoDataApiType} from "./../../@types/produto/produto"
  import { Badge, ListItem, Icon } from '@rneui/themed'
  import IconCircle from './../../assets/png/showblubb/ring_gradient_130x130px.png';
  import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png';
  
  import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
  import DateTimePicker from '@react-native-community/datetimepicker';
  import moment from 'moment'
  import MapView, { Marker } from 'react-native-maps';
import { ICON_SIZE } from "react-native-paper/lib/typescript/components/TextInput/Adornment/TextInputIcon";
  // user_pict_gray_130x130px.png

  const apiKey = 'AIzaSyD6_lxrnSfNGuhKxErqagxzGb5AGuCcZbg';
  
  
  export interface Props{
    isLoading : boolean,
    errorMessage : string,
    user : UserDataApiType,
    categories : any,
    product:ProdutoDataApiType,
    products:Array<[]>,
    productsList:[],
    latitude:any,
    longitude:any,
  }
  
  const ProductDetails = ({isLoading, errorMessage, user, product, products, productsList}: Props) => {
    //const dispatch = useDispatch();
    const navigation = useNavigation()
    const {colors} = useTheme();
    const [name, setName] = useState("");
    const [nickname, setNickname] = useState("");
    const [age, setAge] = useState("");
    const [address, setAddress] = useState("");
    const [data, setData] = useState("");
    const [description, setDescription] = useState("");
    const [type, setType] = useState("");
    const [qtd, setQtd] = useState(0);
    const [target, setTarget] = useState("");
    const [bounds, setBounds] = useState({});
    const [position, setPosition] = useState({coords:{latitude:'',longitude:''}});
    const [bio, setBio] = useState("");
    const [filePath, setFilePath] = useState('');
    const [fileData, setFileData] = useState('');
    const [fileUri, setFileUri] = useState('');
    const [date, setDate] = useState(new Date(Date.now()));
    const [initiFileUri, setInitFileUri] = useState('');
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);
    const dispatch = useDispatch()
  
    useEffect(() => {
          //setName(user.name)
          /* setNickname(user.nickname || user.givenName)
          setBio(user.profile )
          setAge(user.birthdate) */
          console.log('product ===> ', product)
          console.log('product ===> ', product.identificacao)
          console.log('products =====> ', products)
          console.log('productsList =====> ', productsList)
          let identificacao:any
          if(product.identificacao && product.identificacao.length){
            identificacao = product.identificacao[0]
            console.log('identificacao ==>>>', identificacao);
          }
          if(identificacao.type){
            setType(identificacao.type)
          }      
          if(identificacao.codigo){
            setData(identificacao.codigo)
          }
          if(product.quantidade){
            setQtd(product.quantidade)
          }
          if(product.date){
            setDate(product.date)
            moment.locale('pt-br');
            setAge(moment(product.date).format('DD-MM-YYYY'));
            
          }
          if(product.nome){
            setName(product.nome)
          }
          if(product.description){
            setDescription(product.description)
          }
          if(product.target){
            setTarget(product.target)
          }
          
          if(product.bounds){
            setBounds(product.bounds)
          }
          if(product.position){
            console.log(product.position.coords)
            setPosition(product.position)
          }
          if(product.picture){
            console.log('picture ===> ',product.picture)
            setFileUri(product.picture)
            setInitFileUri(product.picture)
          }
          
    },[])
  
    const goLogs = () => {
      
      console.log('logs to send ')
      //dispatch(postProductStart({barcodes:products,barcodesData:productsList}))
      navigation.navigate('Logs')
    };
  
    const renderFileUri = () =>{
      console.log("fileUri",fileUri)
      if (fileUri) {
        return <Image
          source={{ uri: fileUri }}
          style={styles.selectedImages}
        />
      } else {      
          return <Image resizeMode='contain' source={IconUser} style={{width:'100%',height:90, marginBottom:5,marginTop:30}} />
      }
    }
  
    const launchImageLibraryFunction = async () => {
      let options:any = {
        storageOptions: {
          skipBackup: true,
          path: 'images',
        },
      };
      const response = await launchImageLibrary(options)
        // console.log('Response = ', response);
        if (response.didCancel) {
          console.log('User cancelled image picker');
        } else if (response.errorCode) {
          console.log('ImagePicker Error: ', response.errorMessage);
       
        } else {
          const source = { uri: response.uri };
          console.log('response library', JSON.stringify(response));
           const resp = response.assets[0]
            setFilePath(resp) 
            setFileData(resp.data)
            setFileUri(resp.uri)
        }
    }
  
    const onChange = (event: any, selectedDate: Date) => {
      const currentDate = selectedDate || date;
      console.log('currentDate ==>',currentDate)
      setShow(Platform.OS === 'ios');
      setDate(currentDate);
      moment.locale('pt-br');
      setAge(moment(currentDate).format('DD-MM-YYYY'));
      console.log('currentDate', currentDate)
    };
  
    return (
      <View 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}>
      
      <View style={styles.topStyle}>
        <View style={styles.photoPerfilContainer}>
          {renderFileUri()}
        </View> 
        <Badge value={qtd||1} status="primary"  />
      </View>
        <View style={styles.infoContainer}>
          
          
          <ScrollView contentContainerStyle={styles.contentContainer}>
          <Button
            loading={isLoading}
            style={{
              width: "60%",
              alignSelf: "center",
              borderRadius: 15,
              marginTop: 40,
              backgroundColor: colors.primaryButton
            }}
            mode="contained"
            onPress={() => goLogs()}
          >
          logs
        </Button>
            <Text style={styles.inputTitle}>Quantidade: {qtd}</Text>
            <Text style={styles.inputTitle}>Nome: {name}</Text>
            
            <Text style={styles.inputTitle}>Code</Text>
            <Text style={styles.inputTitle}>{data}</Text>
            
            <Text style={styles.inputTitle}>Type: {type}</Text>
           
          {/* <View style={{ height: 100, width: "80%" }}>
         
          <Text style={styles.inputTitle}>Validade</Text>
          <TouchableOpacity style={{width:'100%',height:60 }} onPress={()=>setShow(true)}>
            <View pointerEvents="none"> 
              <TextInput
                selectTextOnFocus={false}
                label={"Vencimento"}
                // mode={"outlined"}
                value={age}
                style={{ height: 55, backgroundColor:'transparent',borderWidth:0 }}
                //onChangeText={(text) => setDate(text)}
              />
            </View>
          </TouchableOpacity>
          

        </View> */}
        
        
          <Text style={styles.inputTitle}>Descrição</Text>
          <Text style={styles.inputTitle}>{description}</Text> 
          
         {/*  <MapView
          initialRegion={{
            latitude: Number(position.coords.latitude)||37.78825,
            longitude: Number(position.coords.longitude)||-122.4324,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}
          
          style={{height:300, width:'100%'}}

        >
          <Marker
            pinColor='#090909'
            coordinate={product.position.coords}
            title={product.data}
            description={product.description}
          />
        </MapView> */}
          </ScrollView>
        </View>
        
       
        
        
        
        
  
      </View>
    );
  };
  
  
  const profileStateToProps = (state : RootState)=>(
    {
      user : state.userApp.user, selectedUser: state.userApp.selectedUser, productsList: state.products.productsList ,products:state.products.products, product:state.products.product, isLoading: state.userApp.isLoading , errorMessage : state.user.errorMessage
    }
  )
  
  
  
  export default connect(profileStateToProps)(ProductDetails)
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      // padding: 20,
      backgroundColor:'white'
      //,height:'80%'
    },
    contentContainer:{
      borderColor:'black',
      borderWidth:2,
      padding:10,
      //backgroundColor:'red'
      //height:150
    },
    topStyle: {
      padding: 12,
      justifyContent: "space-around"
    },
    selectedImages:{
      width:200,
      height:200,
      alignItems: "center",
      // resizeMode:'contain',
      // marginTop:50
      marginBottom:10,
      borderRadius:200/6
    },
    photoPerfilContainer: {
      //borderBottomWidth: 1,
      height:130,
      alignItems:'center'
      
    },
    btnIcon:{
      marginTop:5,
      // height:25,
      // borderWidth:1,
      // borderColor:'black',
      alignItems:'center',
    },
    infoContainer: {
      padding: 2,
      backgroundColor:'white'
    },
    inputTitle: {
      fontSize: 18,
      paddingVertical:2
    },
    inputText: {
      fontSize: 20,
    },
  });
  