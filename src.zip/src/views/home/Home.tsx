import {
    KeyboardAvoidingView,
    StyleSheet,
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    TouchableHighlight,
    Platform,
    ScrollView,
    Switch,
    PermissionsAndroid
  } from "react-native";
  import { useDispatch } from 'react-redux';
  import { useNavigation} from '@react-navigation/native'

  import {postProductStart, updateProductStart,setMode} from '../../redux/products/productsActions'
  import {getUserStart} from '../../redux/userApp/userAppActions'
  import { getAllCategoriesStart } from '../../redux/categories/categoriesActions'
  import React, { useState , useEffect} from "react";
  import { Button , useTheme} from "react-native-paper";
  import {connect} from 'react-redux'
  import {RootState} from '../../redux/RootReducer'
  import { UserDataApiType} from "../../@types/user/user"
  import { ProdutoDataApiType} from "../../@types/produto/produto"
  import { Badge, ListItem, Icon } from '@rneui/themed'
  import IconCircle from './../../assets/png/showblubb/ring_gradient_130x130px.png';
  import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png';
  
  import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
  import DateTimePicker from '@react-native-community/datetimepicker';
  import moment from 'moment'
  import MapView, { Marker } from 'react-native-maps';
    import { ICON_SIZE } from "react-native-paper/lib/typescript/components/TextInput/Adornment/TextInputIcon";
  // user_pict_gray_130x130px.png
  
  
  export interface Props{
    isLoading : boolean,
    errorMessage : string,
    user : UserDataApiType,
    categories : any,
    product:ProdutoDataApiType,
    products:Array<[]>,
    productsList:[],
    latitude:any,
    longitude:any,
    mode:string
  }
  
  const Home = ({isLoading, mode, errorMessage, user, categories, product, products, productsList}: Props) => {
    //const dispatch = useDispatch();
    const menuList = [
        {name : 'Produtos', desc:'Visualizar a lista de produtos', screen:'Products'},
        {name : 'Capturar', desc:'Capturar QrCode, código de barras', screen:'Qrcode'},
        {name : 'Capturar c/ scanner', desc:'Conectar scanner', screen:'Connect'},
        {name : 'Mapa', desc:'Visualizar itens no mapa', screen:'Map'},
    ]
    const navigation = useNavigation()
    const {colors} = useTheme();
    
    const [menu, setMenu] = useState(menuList);
    const [isEnabled, setIsEnabled] = useState(false);
    const [position, setPosition] = useState({coords:{latitude:'',longitude:''}});
    
    const dispatch = useDispatch()
  
    useEffect(() => {
          //setName(user.name)
          /* setNickname(user.nickname || user.givenName)
          setBio(user.profile )
          setAge(user.birthdate) */
          
          //console.log('products =====> ', products)
          console.log('productsList =====> ', productsList)
          console.log('user =====> ', user)
          
          
          
    },[user])

    useEffect(() => {
        permissionAccess()
        mode == 'coleta' ?
          setIsEnabled(false)
        : setIsEnabled(true)
        dispatch(getUserStart())
  },[])

  const toggleSwitch = ()=>{
    mode == 'coleta' ?
          setIsEnabled(true)
        : setIsEnabled(false);
        const newMode =  (mode == 'coleta' ? 'inventario':'coleta')
        dispatch(setMode(newMode))
  }


  const permissionAccess = async ()=>{
    console.log('permissionAccess was called')
    const granted =  await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,{
        'title': 'RFID App',
        'message': 'RFID App access to your location '
      }
    );
    console.log('granted permission', granted)
    

  }
  
   
  
    const renderFileUri = () =>{
      console.log("fileUri",fileUri)
      if (fileUri) {
        return <Image
          source={{ uri: fileUri }}
          style={styles.selectedImages}
        />
      } else {      
          return <Image resizeMode='contain' source={IconUser} style={{width:'100%',height:90, marginBottom:5,marginTop:30}} />
      }
    }




    
  
    
    
  
    return (

      <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}>
      
      <View style={styles.inner}>
        <Text>Bem-vindo {user?.nome || 'usuário'}</Text>
        <View style={styles.modeContainer}>
          <Text>Modo {mode || 'coleta'}</Text>
          <Switch
        trackColor={{false: '#767577', true: '#81b0ff'}}
        thumbColor={isEnabled ? '#f5dd4b' : '#f4f3f4'}
        ios_backgroundColor="#3e3e3e"
        onValueChange={toggleSwitch}
        value={isEnabled}
      />
        </View>
        <ScrollView contentContainerStyle={styles.contentContainer}>
  
        {
            menu.map((l, i) => {
            moment.locale('pt-br');
            
            return (
            <ListItem key={i} 
            bottomDivider
            Component={TouchableHighlight}
            containerStyle={{}}
            disabledStyle={{ opacity: 0.5 }}
            onLongPress={() => console.log("onLongPress()")}
            onPress={()=>{
                console.log(l)
                navigation.navigate(l.screen)
            }}
            pad={20}
            >
                {l.type == 'adicionar' ? <Badge value={l.qtd} status="success" />:<Badge value={l.qtd} status="error" />}
                
                <ListItem.Content >
                <ListItem.Title>{l.name}</ListItem.Title>
                <ListItem.Subtitle>{l.desc}</ListItem.Subtitle>
                </ListItem.Content>
            </ListItem>
                )})
        }
          
          </ScrollView>
        
        </View>
       
      </KeyboardAvoidingView>
    );
  };
  
  
  const profileStateToProps = (state : RootState)=>(
    {
      user : state.userApp.user, selectedUser: state.userApp.selectedUser, caterories: state.categories.categories,mode: state.products.mode, productsList: state.products.productsList ,products:state.products.products, product:state.products.product, isLoading: state.userApp.isLoading , errorMessage : state.user.errorMessage
    }
  )
  
  
  
  export default connect(profileStateToProps)(Home)
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      // padding: 20,
      backgroundColor:'white'
     
    },
    contentContainer:{},
    inner: {
      padding: 24,
      flex: .9,
      //justifyContent: "space-around"
    },
    modeContainer:{
      marginVertical:20,
      alignItems: 'center',
      justifyContent: 'center',
    },
    selectedImages:{
      width:200,
      height:200,
      alignItems: "center",
      // resizeMode:'contain',
      // marginTop:50
      marginBottom:10,
      borderRadius:200/6
    },
    photoPerfilContainer: {
      borderBottomWidth: 1,
      height:250,
      alignItems:'center'
      // ,borderWidth:1
    },
    btnIcon:{
      marginTop:5,
      // height:25,
      // borderWidth:1,
      // borderColor:'black',
      alignItems:'center',
    },
    infoContainer: {
      padding: 2,
      backgroundColor:'white',
      alignContent:'flex-start',
      
    },
    inputTitle: {
      fontSize: 18,
    },
    inputText: {
      fontSize: 20,
    },
  });
  