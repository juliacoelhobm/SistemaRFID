import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import { useNavigation } from "@react-navigation/native";
import {
  KeyboardAvoidingView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Image,
  TouchableOpacity,
  Platform,
  ScrollView,
  StatusBar
} from "react-native";
import AppIntroSlider from 'react-native-app-intro-slider';
import {connect} from 'react-redux'
import {RootState} from '../../redux/RootReducer'
import { UserDataApiType} from "../../@types/user/user" 
import { useDispatch } from 'react-redux';
import {CategoriasDataApiType} from "../../@types/categories/categories"

const styles = StyleSheet.create({
  buttonCircle: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(0, 0, 0, .2)',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image:{resizeMode:'contain', width:'90%', alignSelf:'center'},
  slide:{},
  text:{},
  title:{},
  
  //[...]
});

export interface Props{
    isLoading : boolean,
    errorMessage : string,
    user : UserDataApiType,
    products:[]
    categories :CategoriasDataApiType,
    productsByCategory:[],
    filterByCategory:boolean
  }
  

  

const Intro =({products, productsByCategory, filterByCategory, categories}:Props)=> {

  const navigation = useNavigation()

  const _renderItem:any = ({ item }) => {
    return (
      <View style={styles.slide}>
        <Text style={styles.title}>{item.title}</Text>
        <Image style={styles.image} source={item.image} />
        <Text style={styles.text}>{item.text}</Text>
      </View>
    );
  }

  const slides = [
    {
      key: 'zero',
      title: 'RFID Connect',
      text: 'Coleta de itens, inventário, Controle de estoque, relatórios.\nCapture e gerencie seus itens de forma pratica e rapida.\nUtilize leitura por QrCode, scanner(RFID) ou importe dados já consistentes',
      image: require('./../../assets/png/icon.png'),
      backgroundColor: '#59b2ab',
      
    },
    {
      key: 'one',
      title: 'RFID Connect - Coleta',
      text: 'Coleta de produtos.\nCapture com QrCode, scanner ou importe dados já consistentes',
      image: require('./../../assets/png/icon.png'),
      backgroundColor: '#59b2ab',
      
    },
    {
      key: 'two',
      title: 'RFID Connect - Controle de estoque',
      text: 'Controle de estoque',
      image: require('./../../assets/png/icon.png'),
      backgroundColor: '#febe29',
      
    },
    {
      key: 'three',
      title: 'RFID Connect - Inventário',
      text: 'Checagem de estoque com inventário \n\npor QrCode, Scanner ou importação de dados',
      image: require('./../../assets/png/icon.png'),
      backgroundColor: '#22bcb5',
      
    }
  ];
 
 const _renderNextButton = () => {
    return (
      <View style={styles.buttonCircle}>
        <Icon
          name="md-arrow-forward-circle-outline"
          color="rgba(255, 255, 255, .9)"
          size={24}
        />
      </View>
    );
  };
 const _renderDoneButton = () => {
    return (
      <View style={styles.buttonCircle}>
        <Icon
          name="md-checkmark"
          color="rgba(255, 255, 255, .9)"
          size={24}
        />
      </View>
    );
  };
  const _done=()=>{
    navigation.navigate('Home')
  }
 
    return (
      <View style={{flex:1, margin:10, }}>
         {/* <StatusBar translucent backgroundColor="transparent" /> */}
         <AppIntroSlider
          renderItem={_renderItem}
          data={slides}
          renderDoneButton={_renderDoneButton}
          renderNextButton={_renderNextButton}
          onDone={_done}
        />
      </View>
      
    );
  
}

const productsStateToProps = (state : RootState)=>(
  {
    products:state.products.products, productsByCategory: state.products.productsByCategory, filerByCategory: state.products.filterByCategory ,categories:state.categories.categories, isLoadingProducts :state.products.isLoadingProducts ,errorMessage : state.user.errorMessage
  }
)

export default connect(productsStateToProps)(Intro)