'use strict';
import React, { PureComponent,useState , useEffect} from 'react';
import { Alert, AppRegistry, ImageBackgroundBase, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import {Avatar, Badge, Button, ListItem, SearchBar } from '@rneui/themed'
import { RNCamera } from 'react-native-camera';
import { color, Value } from 'react-native-reanimated';

import {useTheme} from 'react-native-paper'
import TouchableScale from 'react-native-touchable-scale';
import LinearGradient from 'react-native-linear-gradient'; // Only if no expo
import { MultipleSelectList,SelectList  } from 'react-native-dropdown-select-list'
import {connect} from 'react-redux'
import {RootState} from '../../redux/RootReducer'
import { UserDataApiType} from "../../@types/user/user" 
import { useNavigation} from '@react-navigation/native'
import { useDispatch } from 'react-redux';

import { postSelectedProductStart, postProductStart, getAllProductsStart, getProductsByCategoryStart} from './../../redux/products/productsActions'
import {createCategoryStart, getAllCategoriesStart} from '../../redux/categories/categoriesActions'
import {CategoriasDataApiType} from "../../@types/categories/categories"

const PendingView = () => (
  <View
    style={{
      flex: 1,
      backgroundColor: 'lightgreen',
      justifyContent: 'center',
      alignItems: 'center',
    }}
  >
    <Text>Waiting</Text>
  </View>
);

interface StateProperties {
  name: any;
  quantidade: any;
  bounds: any;
  data: any;
  type:any;
  target:any;
  title:any;
  subtitle:any;
  picture:string;
  identificacao:any;
 

}
export interface Props{
  isLoading : boolean,
  errorMessage : string,
  user : UserDataApiType,
  products:[]
  categories :CategoriasDataApiType,
  productsByCategory:[],
  filterByCategory:boolean
}


const Products =({products, productsByCategory, filterByCategory, categories}:Props)=> {

  const navigation = useNavigation()
  const {colors, fonts} = useTheme()
  const dispatch =  useDispatch();

  const [barcodes, setBarcodes] = useState<StateProperties[]>([]);
  const [barcodesDisplay, setBarcodesDisplay] = useState<StateProperties[]>([]);
  const [barcodesData, setBarcodesData] = useState<StateProperties[]>([]);
  const [camera, setCamera] = useState(null);
  const [selected, setSelected] = React.useState([]);
  const [expanded, setExpanded] = React.useState(false);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState('');
  const [categoriesToShow, setCategoriesToShow] = useState([{nome:'Todas',_id:0}]);
  const [selectedCategory, setSelectedCategory] = useState({key:0,value:'Filtro por categoria'});

  const updateSearch = (search: React.SetStateAction<string>) => {
    setSearch(search);
    let newBarcodes = barcodes.filter((item)=>{
      console.log(item.identificacao[0].codigo.indexOf(search) )
      console.log('search',search)
      return item.identificacao[0].codigo.indexOf(search) != -1

    })
    if(!search) newBarcodes = barcodes;
    setBarcodesDisplay(newBarcodes)

  };

  const getAllCategories=()=>{
    dispatch(getAllCategoriesStart())
  }
  const getAllProducts=()=>{
    dispatch(getAllProductsStart())
  }

  /* dispatch(getAllCreatedBlubbsByUserStart()) */

  useEffect(() => {
    console.log('products ====>  ', products)
    setBarcodes (products)
    setBarcodesDisplay (products)
  },[products]);
  useEffect(() => {
    getAllProducts()
    getAllCategories();
  },[]);
  useEffect(() => {
    if(categories&&categories.length&&categoriesToShow.length==1){
      setCategoriesToShow([categoriesToShow[0], ...categories])
    }
    console.log('categoriesToShow',categoriesToShow)
  });
  const goToEdit=(item: StateProperties)=>{
    console.log('item',item)
    dispatch(postSelectedProductStart(item))

    //navigation.navigate('ProductDetails')
    navigation.navigate('ProductEdit')
  }
  const goToDetail=(item: StateProperties)=>{
    console.log('item',item)
    dispatch(postSelectedProductStart(item))
    navigation.navigate('ProductDetails')
  }
   // return (<View style={styles.container}><Text style={{color:'white'}}>Products</Text></View>)
     return (
      <View style={styles.container}>

      
        
        <View style={{ position:'absolute',flex: 1,width:'100%', justifyContent: 'center' }}>
       <View style={styles.view}>
          <SearchBar
            placeholder="Digite aqui..."
            onChangeText={updateSearch}
            value={search}
          />
          <View style={styles.infoContainer}>
          <SelectList 
            setSelected={(val: any) => {
              console.log('val' , val)
              categoriesToShow.map((el: { _id: any; nome: any; }, ind: any)=>{
                if (el.nome == val ){
                  if(el.nome == 'Todas'){
                    getAllProducts()
                  } else{
                     dispatch(getProductsByCategoryStart(el._id))
                    setCategory(el._id)
                  }          
                }
              })
            }} 
            data={categoriesToShow.map((el: { _id: any; nome: any; }, ind: any)=>{
              return {key: el._id , value : el.nome}
            })} 
            defaultOption={selectedCategory}
            searchPlaceholder='Categorias'
            placeholder="Filtro por categoria"
            search={false} 
            notFoundText = 'Nenhum resultado encontrado'
            save="value"
        /></View>
        </View>
          <FlatList
              data={barcodesDisplay}
              keyExtractor={item => item.identificacao[0].codigo}
              renderItem={({item})=>(
                <React.Fragment key={item.identificacao[0].codigo}>
                  {/* <ListItem.Accordion
                    content={
                      <>
                        <Icon name="place" size={30} />
                        <ListItem.Content>
                          <ListItem.Title>List Accordion</ListItem.Title>
                        </ListItem.Content>
                      </>
                    }
                    isExpanded={expanded}
                    onPress={() => {
                      setExpanded(!expanded);
                    }}> */}
                <ListItem.Swipeable

                leftContent={(reset) => (
                  <Button
                    title="Editar"
                    onPress={() =>{goToEdit(item)} }
                    icon={{ name: 'edit', color: 'white' }}
                    buttonStyle={{ minHeight: '100%' }}
                  />
                )}
                rightContent={(reset) => (
                  <Button
                    title="Retirar"
                    onPress={() => {
                     
                      Alert.alert(
                        "Confirmação",
                        "Deseja realente apagar o item "+ item.identificacao[0].codigo,
                        [
                          {
                            text: "Cancelar",
                            onPress: () => console.log("Cancel Pressed"),
                            style: "cancel"
                          },
                          { text: "OK", onPress: () => {
                            console.log("OK Pressed")
                            let newList = barcodes.filter(a =>
                              a.data !== item.identificacao[0].codigo
                            )
                          let newListData = barcodesData.filter(a =>
                              a !== item.identificacao[0].codigo
                            )
                          setBarcodes(
                            newList
                          );
                          setBarcodesData(
                            newListData
                          );
                          setTimeout(()=>{dispatch(postProductStart({barcodes:newList,barcodesData:newListData}))},1000)
                          reset()
                          } }
                        ])
    
                      
                    }}
                    icon={{ name: 'delete', color: 'white' }}
                    buttonStyle={{ minHeight: '100%', backgroundColor: 'red' }}
                  />
                )}

                Component={TouchableScale}
                
                linearGradientProps={{
                  colors: ['#FF9800', '#F44336'],
                  start: { x: 1, y: 0 },
                  end: { x: 0.2, y: 0 },
                }}
                ViewComponent={LinearGradient} // Only if no expo
                topDivider
                >
                 <Badge value={item.quantidade||1} status="primary" />
               
                <ListItem.Content>
                
                  <ListItem.Title  style={{ color: 'white', fontWeight: 'bold' }}>{item.identificacao[0].codigo}</ListItem.Title>
                  <ListItem.Subtitle>Quantidade: {item.quantidade||1}     tipo: {item.identificacao[0].tipo}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron size={18} raised color='black' onPress={() =>{goToDetail(item)} } />
              </ListItem.Swipeable>
{/* </ListItem.Accordion> */}

</React.Fragment>
              )

    }
/>
  
            </View>
        </View>
      
    );
  

  
}



const productsStateToProps = (state : RootState)=>(
  {
    products:state.products.products, productsByCategory: state.products.productsByCategory, filerByCategory: state.products.filterByCategory ,categories:state.categories.categories, isLoadingProducts :state.products.isLoadingProducts ,errorMessage : state.user.errorMessage
  }
)



export default connect(productsStateToProps)(Products)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'black',
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  view: {
    margin: 10,
  },
  infoContainer: {
    flex:1,
    padding: 2,
    backgroundColor:'white'
  },
  capture: {
    flex: 0,
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 15,
    paddingHorizontal: 20,
    alignSelf: 'center',
    margin: 20,
  },
});

