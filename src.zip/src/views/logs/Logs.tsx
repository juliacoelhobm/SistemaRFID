import {
    KeyboardAvoidingView,
    StyleSheet,
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    Platform,
    ScrollView
  } from "react-native";
  import { useDispatch } from 'react-redux';
  import { useNavigation} from '@react-navigation/native'
  import {updateUserStart} from '../../redux/userApp/userAppActions'
  import {postProductStart, updateProductStart, getLogsStart} from '../../redux/products/productsActions'
  import React, { useState , useEffect} from "react";
  import { Button , useTheme} from "react-native-paper";
  import {connect} from 'react-redux'
  import {RootState} from '../../redux/RootReducer'
  import { UserDataApiType} from "../../@types/user/user"
  import { ProdutoDataApiType} from "../../@types/produto/produto"
  import { Badge, ListItem, Icon } from '@rneui/themed'
  import IconCircle from './../../assets/png/showblubb/ring_gradient_130x130px.png';
  import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png';
  
  import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
  import DateTimePicker from '@react-native-community/datetimepicker';
  import moment from 'moment'
  import MapView, { Marker } from 'react-native-maps';
    import { ICON_SIZE } from "react-native-paper/lib/typescript/components/TextInput/Adornment/TextInputIcon";
  // user_pict_gray_130x130px.png
  
  
  export interface Props{
    isLoading : boolean,
    errorMessage : string,
    user : UserDataApiType,
    categories : any,
    product:ProdutoDataApiType,
    products:Array<[]>,
    productsList:[],
    latitude:any,
    longitude:any,
    logs:any
  }
  
  const Logs = ({isLoading, errorMessage, user,logs, product, products, productsList}: Props) => {
   
    const navigation = useNavigation()
    const {colors} = useTheme();
    const [name, setName] = useState("");
    const [nickname, setNickname] = useState("");
    const [age, setAge] = useState("");
    const [address, setAddress] = useState("");
    const [data, setData] = useState("");
    const [description, setDescription] = useState("");
    const [type, setType] = useState("");
    const [qtd, setQtd] = useState(0);
    const [target, setTarget] = useState("");
    const [bounds, setBounds] = useState({});
    const [logsData, setLogsData] = useState([]);
    const [position, setPosition] = useState({coords:{latitude:'',longitude:''}});
    const [bio, setBio] = useState("");
    const [filePath, setFilePath] = useState('');
    const [fileData, setFileData] = useState('');
    const [fileUri, setFileUri] = useState('');
    const [date, setDate] = useState(new Date(Date.now()));
    const [initiFileUri, setInitFileUri] = useState('');
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);
    const dispatch = useDispatch()
  
    useEffect(() => {
          //setName(user.name)
          /* setNickname(user.nickname || user.givenName)
          setBio(user.profile )
          setAge(user.birthdate) */
          console.log('product ===> ', product)
          console.log('products =====> ', products)
          console.log('logs =====> ', logs)
          if(product.data){
            setData(product.data)
          }
          if(product.qtd){
            setQtd(product.qtd)
          }
          if(product.date){
            setDate(product.date)
            moment.locale('pt-br');
            setAge(moment(product.date).format('DD-MM-YYYY'));
            
          }
          if(product.name){
            setName(product.name)
          }
          if(product.description){
            setDescription(product.description)
          }
          if(product.target){
            setTarget(product.target)
          }
          if(product.type){
            setType(product.type)
          }
          if(product.bounds){
            setBounds(product.bounds)
          }
          
          if(product.position){
            console.log(product.position.coords)
            setPosition(product.position)
          }
          if(product.picture){
            console.log('picture ===> ',product.picture)
            setFileUri(product.picture)
            setInitFileUri(product.picture)
          }
          console.log('product id ===> ', product._id)
          dispatch(getLogsStart(product._id))

          
    },[])
  
    const submitLogs = () => {
      const dataToSend:any = {
        name,
        date,
        data,
        target,
        type,
        bounds,
        description,
        qtd,
        picture:fileUri||'',
        logs
        // picture : user.picture
        // , categories
      };
      console.log('data to send ', dataToSend)
      //filePath ? dataToSend.file = filePath : ''
      //age ? dataToSend.birthdate= age : ''
      //Criar aq a chamada da ação updateUserStart passando os dados de input

      productsList.map((item,index)=>{
        console.log(item, index)
        console.log('data',data)
        if(item == data){
          console.log('entrou', dataToSend)
          products[index]=dataToSend
        }

      })
      console.log('products',products)
      dispatch(postProductStart({barcodes:products,barcodesData:productsList}))
      navigation.navigate('Products')
    };
  
    const renderFileUri = () =>{
      console.log("fileUri",fileUri)
      if (fileUri) {
        return <Image
          source={{ uri: fileUri }}
          style={styles.selectedImages}
        />
      } else {      
          return <Image resizeMode='contain' source={IconUser} style={{width:'100%',height:90, marginBottom:5,marginTop:30}} />
      }
    }
  
    
    
  
    return (

      <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}>
      
      <View style={styles.inner}>
        
        <ScrollView contentContainerStyle={styles.contentContainer}>
  
        {
        logs.map((l:{
        date: Date, EstoqueAnterior: number, EstoqueAtual:number,
        quantidade: number,tipo: any;usuario: any,log: any}, i) => {
          moment.locale('pt-br');
          const dateTransform = (moment(l.date).format('DD-MM-YYYY h:m'));
          return (
            <ListItem key={i} bottomDivider>
              {l.tipo == 'Entrada' ? <Badge value={l.quantidade} status="success" />:<Badge value={l.quantidade} status="error" />}
              
              <ListItem.Content>
                <ListItem.Title>operação: {l.tipo} {l.quantidade} - qtd anterior: {l.EstoqueAnterior} qtd atualizada: {l.EstoqueAtual}</ListItem.Title>
                <ListItem.Subtitle>por: {user.nome} em {dateTransform}</ListItem.Subtitle>
              </ListItem.Content>
            </ListItem>
          )})
        }
      </ScrollView>
        
        </View>
        {/* <MapView
          initialRegion={{
            latitude: Number(position.coords.latitude)||37.78825,
            longitude: Number(position.coords.longitude)||-122.4324,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}
          
          style={{height:300, width:'100%'}}

        >
          <Marker
            pinColor='#090909'
            coordinate={product.position.coords}
            title={product.data}
            description={product.description}
          />
        </MapView> */}
        
        
        
  
      </KeyboardAvoidingView>
    );
  };
  
  
  const profileStateToProps = (state : RootState)=>(
    {
      user : state.userApp.user, selectedUser: state.userApp.selectedUser, logs: state.products.logs, productsList: state.products.productsList ,products:state.products.products, product:state.products.product, isLoading: state.userApp.isLoading , errorMessage : state.user.errorMessage
    }
  )
  
  
  
  export default connect(profileStateToProps)(Logs)
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      // padding: 20,
      backgroundColor:'white'
     
    },
    inner: {
      padding: 24,
      flex: .9,
      //justifyContent: "space-around"
    },
    selectedImages:{
      width:200,
      height:200,
      alignItems: "center",
      // resizeMode:'contain',
      // marginTop:50
      marginBottom:10,
      borderRadius:200/6
    },
    photoPerfilContainer: {
      borderBottomWidth: 1,
      height:250,
      alignItems:'center'
      // ,borderWidth:1
    },
    btnIcon:{
      marginTop:5,
      // height:25,
      // borderWidth:1,
      // borderColor:'black',
      alignItems:'center',
    },
    infoContainer: {
      padding: 2,
      backgroundColor:'white',
      alignContent:'flex-start',
      
    },
    inputTitle: {
      fontSize: 18,
    },
    inputText: {
      fontSize: 20,
    },
  });
  