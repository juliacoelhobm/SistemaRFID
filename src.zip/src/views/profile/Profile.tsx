import React, { Fragment, Component, useState, useEffect , useRef} from 'react';
import {StyleSheet,Image, View, ScrollView, TouchableOpacity} from 'react-native';
import {Avatar,Text} from 'react-native-paper';
import { useNavigation} from '@react-navigation/native'
import { useDispatch } from 'react-redux';
import {connect} from 'react-redux'
import {RootState} from './../../redux/RootReducer'
import { UserDataApiType} from "./../../@types/user/user" 
import {useTheme,Button} from 'react-native-paper'
import Topic from "../../components/category/Category";
import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png'
import {getAllProductsStart ,getLogsStart} from '../../redux/products/productsActions'
import { Badge, ListItem, Icon } from '@rneui/themed'
import moment from 'moment'

export interface Props{
  isLoading : boolean,
  errorMessage : string,
  user : UserDataApiType,
  products:[],
  logs:[]
  
}
const Profile =  ({isLoading, errorMessage, user, logs, products}: Props) => {
  const navigation = useNavigation()
  const {colors, fonts} = useTheme()
  const dispatch =  useDispatch();
  const [selectedItem, setSelectedItem] = useState(0)
  const [selectedProduct, setSelectedProduct] = useState('')
  // const [colorButton, setColorButton] = useState(colors.primaryButton)

  
  const changeButton = (value: React.SetStateAction<number>)=>{

    if(value) dispatch(getLogsStart('63ad8c46288d60aa40790178'))
    setSelectedItem (value)

  }

  const getLogs = (id:any)=>{
    dispatch(getLogsStart(id))
    setSelectedItem (1)

  }
 
  useEffect(() => {
        console.log('profile user',user)
        console.log('logs===>>> ',logs)
        console.log('products===>>> ',products)
        
        dispatch(getAllProductsStart())
        /* dispatch(getAllCreatedBlubbsByUserStart()) */
  },[logs])

  return (
    <View style={styles.container}>
      {/*<Avatar.Text size={64} label="SK" />*/}
      {user&&user.picture?(
                <Image  source={{'uri':user.picture}} style={{width:100,height:100,borderRadius:50}} />

        ):(
                <Image resizeMode="contain" source={IconUser} style={{width:100,height:100}} />

        )}
      <Text style={styles.userLink}>{user.nome||'Tiago Hilkner Venegas'}</Text>
      <Text style={styles.description}>
        {user.email}
      </Text>
      
      <View style={{ flexDirection:'row', alignItems:'center'}}>
        <Button style={[styles.shareButton, {borderWidth:1, borderColor:'black',marginHorizontal:10
          ,backgroundColor: !selectedItem ? colors.primaryButton : 'white' }]} onPress={()=>{changeButton(0)} } loading={isLoading}>
          <Text style={{color:'#c6c6c6',fontFamily:'Poppins-Regular'}}> 
            produtos
          </Text>
        </Button>
        <Button style={[styles.shareButton, {borderWidth:1, borderColor:'black',backgroundColor: selectedItem ? colors.primaryButton : 'white'}]} onPress={()=> {changeButton(1)}} loading={isLoading}>
          <Text style={{color:'#c6c6c6',fontFamily:'Poppins-Regular'}}> 
           Registros
          </Text>
        </Button>
      </View>
      {
        !selectedItem?
        <View style={styles.collectionsContainer}>
        <ScrollView>
        {
        products.map((l:{
          _id:string, nome: string, createdAt: Date, EstoqueAnterior: number, EstoqueAtual:number,
        quantidade: number,tipo: any;usuario: any,identificacao:any}, i) => {
          moment.locale('pt-br');
          const dateTransform = (moment(l.createdAt).format('DD-MM-YYYY h:m'));
          return (
            <ListItem key={i} bottomDivider onPress={(event)=>{getLogs(l._id)}}>
              <Badge value={l.quantidade} status="success" />
              
              <ListItem.Content>
                <ListItem.Title>qtd:{l.quantidade} nome: {l.nome}</ListItem.Title>
                <ListItem.Subtitle>código: {l.identificacao[0].codigo} tipo: {l.identificacao[0].tipo}</ListItem.Subtitle>
                <ListItem.Subtitle>por: {user.nome} em {dateTransform}</ListItem.Subtitle>
              </ListItem.Content>
            </ListItem>
          )})
        }
        </ScrollView>
      </View>:
      <View style={styles.collectionsContainer}>
        <ScrollView>
        {
        logs.map((l:{
        date: Date, EstoqueAnterior: number, EstoqueAtual:number,
        quantidade: number,tipo: any;usuario: any,log: any}, i) => {
          moment.locale('pt-br');
          const dateTransform = (moment(l.date).format('DD-MM-YYYY h:m'));
          return (
            <ListItem key={i} bottomDivider>
              {l.tipo == 'Entrada' ? <Badge value={l.quantidade} status="success" />:<Badge value={l.quantidade} status="error" />}
              
              <ListItem.Content>
                <ListItem.Title>operação: {l.tipo} {l.quantidade} - qtd anterior: {l.EstoqueAnterior} qtd atualizada: {l.EstoqueAtual}</ListItem.Title>
                <ListItem.Subtitle>por: {user.nome} em {dateTransform}</ListItem.Subtitle>
              </ListItem.Content>
            </ListItem>
          )})
        }
    
        
        
            
         
        </ScrollView>
      </View>

      }
      

    </View>
  );
};

// export default Profile;

const profileStateToProps = (state : RootState)=>(
  {
    user : state.userApp.user, logs:state.products.logs, products: state.products.products ,  isLoading: state.user.isLoading , errorMessage : state.user.errorMessage
  }
)



export default connect(profileStateToProps)(Profile)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffff',
  },
  collectionsContainer: {
    flex: 1,
    width: '100%',
  },
  categoriesContainer: {
    width: "95%",
    flex: 1,
    alignSelf: "center",
    paddingBottom: 0,
    alignItems:'center',
    

  },
  inner: {
    borderColor:'black',
    borderWidth:1,
    
  },
  categories: {
    flexDirection: "row",
    justifyContent: "space-evenly",

  },
  shareButton: {
    borderRadius: 25,
    marginTop:30,
    width: "42%",
    height: 40,
    // alignItems: "center",
    // justifyContent: "center",
  },
  description: {
    textAlign: 'center',
  },
  userLink: {
    fontSize: 18,
    marginVertical: 10,
  },
  userInfoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '75%',
    marginVertical: 10,
  },
  userInfoBlock: {
    fontFamily:'Poppins-Regular',
    alignItems: 'center',
  },
});
