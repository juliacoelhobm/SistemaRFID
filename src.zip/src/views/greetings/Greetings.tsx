import React, {useState, useEffect, useCallback} from 'react'
import AsyncStorage from '@react-native-async-storage/async-storage';

import { useNavigation } from "@react-navigation/native";
import {
  ActivityIndicator,	
  AppRegistry,
  Alert,
  Linking,
  Image,
  View,
  SafeAreaView,
  StyleSheet,
  PixelRatio,
  Platform,
  TouchableOpacity
} from 'react-native';

import {Button, useTheme, TextInput, Text} from 'react-native-paper'
import { useDispatch } from 'react-redux';
import {mainProps} from './../../../Main'
import {logout, loggedSuccessStart, loggedSuccess} from './../../redux/user/userActions'
import {RootState} from './../../redux/RootReducer'
import {connect} from 'react-redux'
import BtnSocialLogin from './../../components/btn-social-login/BtnSocialLogin'

import * as Location from "expo-location";

  
  

// You can get the current config object
// const currentConfig = Auth.configure();
// console.log('currentConfig', currentConfig)
// type greetingsProps = Omit <mainProps, 'isLoading'>

export interface greetingsProps{
  userData : any,
  user : any,
  isLoading : boolean,
  isLogged : boolean,
  errorMessage : string,
  navigation : any
}
const Greetings = ({userData, isLoading, navigation, user,isLogged} : greetingsProps)=>{
	const [text, setText] = useState('')
	const [loading, setLoading] = useState(false)
	const [init, setInit] = useState(false)
	console.log('userData Greetings ===>>>', userData)
	console.log('userData Greetings ===>>>', user)

	const {colors, fonts} = useTheme()
	const dispatch = useDispatch()
	
	
	const verifyLocationPermission = async ()=>{
  	/* let { status } = await Location.requestForegroundPermissionsAsync()
  	console.log('status',status)
      if (status !== 'granted') {
      	console.log('Permission to access location was denied')
        return false;
      } else{
      	return true;
      } */
  	}

  verifyLocationPermission();


	const getSession = async ()=>{

						 console.log('resp session ===> ')


		

	}

	const googleLogin = useCallback(async () => {

/* 			try{
				const resp = await Auth.federatedSignIn({provider: CognitoHostedUIIdentityProvider.Google })
					if(resp){
						console.log('resp google ===> ',resp)
						
					}else{
						console.log('resp google error',resp)
				}
				
			} catch(error){
				console.log('error google', error)
			} */

        
    	}, []);

		
	

	 // const { type, token, expires } = await Expo.Facebook.logInWithReadPermissionsAsync('YOUR_FACEBOOK_APP_ID', {
   //      permissions: ['public_profile'],
   //    });
   const type = 'success'
    // if (type === 'success') {
    //   // sign in with federated identity
    //   // { token, expires_at: expires},
    //   Auth.federatedSignIn('facebook',  { name: 'USER_NAME' })
    //     .then(credentials => {
    //       console.log('get aws credentials', credentials);
    //     }).catch(e => {
    //       console.log(e);
    //     });
    // }
	
	const facebookLogin =async ()=> {
		
		/* try {

			await Auth.federatedSignIn({ provider: 'Facebook' , }).then(
				(resp)=>{
				 console.log('resp facebook ===> ',resp)
				 // setTimeout(getSession,500)
				},(error)=>{
					console.log('resp facebook error',error)
			})
			// var linkpp = 'https://graph.facebook.com/' + response.id + '/picture?type=small';


		}catch(error){
			console.log('error facebook', error)

		} */
	}
	return (
		<View style={styles.container}>
			{!loading ? (
			<View style={styles.content}>
				<Image style={styles.image} source={require("./../../assets/png/GettyImages-1314714999.png")}/>
				<Text  style={[styles.subtitle,{color:'grey', marginTop:35, textAlign:'center',fontFamily : 'Poppins-Regular'}]} >
				  Crie sua conta a tenha acesso aos incríveis recursos do RFID Connect.
				</Text>
				<View style={{width:'100%',alignItems: "center", marginTop:35}}>
					<TouchableOpacity style={styles.touch} onPress={() => navigation.navigate('SignUpName')}>
						<BtnSocialLogin Provider='e-mail' Icon='envelope' />
					</TouchableOpacity>
					<TouchableOpacity style={styles.touch} onPress={() => facebookLogin() }>
						<BtnSocialLogin Provider='facebook' Icon='facebook' />
					</TouchableOpacity>
					<TouchableOpacity style={styles.touch} onPress={() => googleLogin()}>
						<BtnSocialLogin Provider='google' Icon='google' />
					</TouchableOpacity>
			
				</View>
				<View style={styles.footer} >
      					<TouchableOpacity onPress={() => navigation.navigate('SignIn')}>
      					<Text style={styles.footerText}>
	      					Já tem uma conta? 
	      					<Text style={{color:colors.primaryButton, fontFamily : 'Poppins-Bold'}}> Entrar</Text>
	      				</Text>
      						
      					</TouchableOpacity>
	      				
	      			</View>
			</View>

				
	      		
		) : (
		<View>
			<Text>Autenticando</Text>
		</View>)}
		
      		
      	</View>
		
		)

		
		
}
const mapStateToProps = (state : RootState)=>(
  {
    isLogged: state.user.isLogged,  isLoading: state.userApp.isLoading , errorMessage : state.user.errorMessage, userData:state.user.userData, user:state.userApp.user
  }
)
export default connect(mapStateToProps)(Greetings)

const styles = StyleSheet.create({
	container : {
		flex:1,
		height:'100%'
		// ,padding: 15,
		// ,borderWidth:2
	},
	content:{
		padding:10
		,alignItems: "center"
		,height:'100%'
		

	},
	title : {
		fontSize : 18
	}
	,subtitle : {
		fontSize : 14
	}
	,touch :{
		width:'90%'
		,alignItems: "center"
	}
	, footer:{
		position : 'absolute',
		bottom : 0,
		height : 50,
		width : '100%',
		borderTopWidth : 1,
		borderTopColor: 'grey',
		// elevation:10

	},
	footerText:{
		color : 'grey',
		includeFontPadding : true,
		textAlignVertical : 'center',
		textAlign : 'center',
		fontSize : 16,
		paddingTop : 8

	},
	image:{
		marginTop:10,
		width:'98%'
		,maxHeight: 300
		,resizeMode: 'contain'
		// ,borderWidth:2
		// ,borderColor:'black'
		,alignItems: "center",
	}

})

