import React, { Fragment, Component, useState, useEffect , useRef} from 'react';


import { useNavigation} from '@react-navigation/native'

// import ImagePicker from 'react-native-image-picker';
//import {postCameraStart} from './../../redux/blubb/blubbActions'
//import {getAllCategoriesStart} from './../../redux/categories/categoriesActions'
import { UserDataApiType} from "./../../@types/user/user" 
//import {getAllBlubbsByRadiusStart, setBlubb, setUpdateBlubbles} from './../../redux/blubb/blubbActions'

// import Message from 'react-native-animated-message';
import { RNCamera } from 'react-native-camera';
import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
import {
    Alert,
  Animated,
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  TextInput,
  StatusBar,
  Image,
  Dimensions,
  TouchableOpacity,
  PermissionsAndroid
} from 'react-native';

import {useTheme,Button} from 'react-native-paper'


import {
  Colors
} from 'react-native/Libraries/NewAppScreen';

// const cameraPermission = await Camera.getCameraPermissionStatus()
// const microphonePermission = await Camera.getMicrophonePermissionStatus()
// const newCameraPermission = await Camera.requestCameraPermission()
// const newMicrophonePermission = await Camera.requestMicrophonePermission()
import { useDispatch } from 'react-redux';
import {connect} from 'react-redux'
import {RootState} from './../../redux/RootReducer'
import DropdownAlert from 'react-native-dropdownalert';

import IconArrow from './../../assets/png/tool/icone_next_circle_pink_131X131px.png';
import IconClose from './../../assets/png/tool/icone_close_white_79x79px.png';
import IconRecPink from './../../assets/png/tool/button_rec_pink_152x152px.png';
import IconInvertBlack from './../../assets/png/tool/icone_invert_black_82x79px.png';
import IconTextBlack from './../../assets/png/tool/icone_text_black_80x80px.png';
import IconTextWhite from './../../assets/png/texttool/icone_text_white_80x80px.png';
import IconDrawing from './../../assets/png/texttool/icone_drawing_white_80x80px.png';
import IconFlashBack from './../../assets/png/tool/icone_flash_black_80x80px.png';
import IconUpload from './../../assets/png/tool/icone_upload_black_80x80px.png';
import IconHelp from './../../assets/png/tool/icone_help_white_79x79px.png';

import IconAlign from './../../assets/png/texttool/icone_align_black_80x80px.png';
import IconColor from './../../assets/png/texttool/icone_color_background_black_80x80px.png';
import IconColorLetter from './../../assets/png/texttool/icone_color_letter_black_80x80px.png';
import IconEffectBlack from './../../assets/png/texttool/icone_effects_black_80x80px.png';
import IconLetter from './../../assets/png/texttool/icone_type_letter_black_80x80px.png';
import IconCircle from './../../assets/png/showblubb/ring_gradient_130x130px.png';
import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png';
import IconBlubbText from './../../assets/png/showblubb/type_blubb_white_159x29px.png';






// import IconHelp from './../../assets/png/tool/icone_help_white_79x79px.png';


let options = {
        title: 'Select Image',
        customButtons: [
          { name: 'customOptionKey', title: 'Choose Photo from Custom Option' },
        ],
        mediaType: 'mixed',
        // cameraType // back or front
        storageOptions: {
          skipBackup: true,
          path: 'images',
        },
      };

export interface Props{
  isLoading : boolean,
  errorMessage : string,
  user : UserDataApiType,
  categories : any,
  updateBubbles:any,
  options:any
}
const Camera =  ({isLoading, errorMessage,options, user, categories,updateBubbles}: Props) => {
  const navigation = useNavigation()
  let dropDownAlertRef:any = useRef();
  const {colors, fonts} = useTheme()

  let moveAnim = useRef(new Animated.Value(100)).current;
  const up = () => {
    // console.log('entrou no up')
    // Will change fadeAnim value to 1 in 5 seconds
    Animated.timing(moveAnim, {
      toValue:0,
      duration: 2000,
      useNativeDriver: true
    }).start();

  };

  const down = () => {
    console.log('down')
    // Will change fadeAnim value to 1 in 5 seconds
    Animated.timing(moveAnim, {
      toValue:100,
      duration: 1000,
      useNativeDriver: true
    }).start();
      setTimeout(()=>{
        // textTool ? setTextTool(false) : setTextTool(true)
        
        console.log('textTool ====> ',textTool)
        console.log('initialScreen ====> ',initialScreen)
        console.log('fileUri ====> ',fileUri)
        if(!textTool && initialScreen && !fileUri){
          console.log('entrou no up ***********')
          setTextTool(true)
          setInitialScreen(false)
          up()
        } else if((textTool && !fileUri) && !initialScreen ){
          setTextTool(false)
          setFinal(true)
        } 
        // // else if (fileUri && !textTool){
        // //   setTextTool(true)
        // //   up();
        // // }
        // else if (fileUri){
        //   setTextTool(false)
        //   // setFinal(true)
        // }
          
      },1000);
   }

  

  const text = ()=>{
    if(!initialScreen && !textToolSecond){
      setTextToolSecond(true)
      setTextTool(true)
      up();
    }else{
      setTextToolSecond(false)
      setTimeout(down,100)
    }
    
    
  }
  const clean = ()=>{
    setTextTool(false)
    setFinal(false)
    setInitialScreen(true)
    setFileUri('')
    setTypedText('')
    setTitle('')
  }
  const close =async ()=>{
    console.log('chamou o close',fileUri)
    if(textTool && !final){
      down()
      setTimeout(()=>{
        clean()
      },1000)
    }else if(fileUri ){
      clean()
    
    } else if(final){
      clean()
    }else if(initialScreen){
      navigation.goBack()
    }
    
  }
  // const categories =  (async () => {
  //   await 
  // })();
  // console.log("categories ==> ", categories)
  const alignList = ['center','right','left']
  const effectList = [
    {textDecorationLine:'none', textShadowColor:'transparent'},
    {textDecorationLine:'underline', textShadowColor:'transparent'},
    {textDecorationLine:'underline', textShadowColor:'black'},
    {textDecorationLine:'underline', textShadowColor:'white'},
    {textDecorationLine:'none', textShadowColor:'black'},
    {textDecorationLine:'none', textShadowColor:'white'},
  
  ]
  const colorList = ['black','white','red','green','blue', 'gray','pink','ornage','yellow']
  const fontList = ['Poppins-Regular','monospace','serif','sans-serif','sans-serif-light','sans-serif-thin','sans-serif-condensed','sans-serif-medium']
  const bubbleList = [
    require('./../../assets/png/bubble_blue_855x855px.png'),
    require('./../../assets/png/bubble_gradient1_855x855px.png'),
    require('./../../assets/png/bubble_gradient2_855x855px.png'),
    require('./../../assets/png/bubble_green1_855x855px.png'),
    require('./../../assets/png/bubble_green2_855x855px.png'),
    require('./../../assets/png/bubble_pink_855x855px.png'),
    require('./../../assets/png/bubble_purple_855x855px.png'),
  ]
  const backgroundList = [
    require('./../../assets/png/background_blue.png'),
    require('./../../assets/png/background_black.png'),
    require('./../../assets/png/background_gradient01.png'),
    require('./../../assets/png/background_gradient02.png'),
    require('./../../assets/png/background_gray.png'),
    require('./../../assets/png/background_green.png'),
    require('./../../assets/png/background_lemon.png'),
    require('./../../assets/png/background_pink.png'),
    require('./../../assets/png/background_purple.png'),
    require('./../../assets/png/background_white.png'),
  ]

	const [filePath, setFilePath] = useState('');
	const [fileData, setFileData] = useState('');
	const [fileUri, setFileUri] = useState('');
  const [lastFileUri, setLastFileUri] = useState('');
	const [bubble, setBubble] = useState(bubbleList[0]);
	const [bubbleIndex, setBubbleIndex] = useState(0);
  const [published, setPublished] = useState(false);
  const [textTool, setTextTool] = useState(false);
  const [textToolSecond, setTextToolSecond] = useState(false);
  const [typedText, setTypedText] = useState('');
  const [final, setFinal] = useState(false);
  const [initialScreen, setInitialScreen] = useState(true);
  const [showColor, setShowColor] = useState(false);
  const [colorImage, setColorImage] = useState(backgroundList[0]);
  const [colorIndex, setColorIndex] = useState(0);
  const [textColor, setTextColor] = useState(colorList[0]);
  const [textColorIndex, setTextColorIndex] = useState(0);
  const [ffIndex, setFfIndex] = useState(0);
  const [effectIndex, setEffectIndex] = useState(0);
  const [textAlign, setTextAlign] = useState('center');
  const [alignIndex, setAlignIndex] = useState(0);
  const [fontFamily, setFontFamily] = useState(fontList[0]);
  const [fontSize, setFontSize] = useState(26);
  const [title, setTitle] = useState('');
  const [highLight, setHighLight] = useState(false);
  const [textShadowColor, setTextShadowColor] = useState('transparent')
  const [textDecorationLine, setTextDecorationLine] = useState('none')
  const [camera, setCamera] = useState(null)
  const [loaded, setLoaded] = useState(false)
  const [granted, setGranted] = useState(null)
  const [sketch, setSketch] = useState(null)
  const [flash, setFlash] = useState(RNCamera.Constants.FlashMode.off)
  const [camType, setCamType] = useState(RNCamera.Constants.Type.back)

  // const [messageInstance, message =]= useStte(null);
  // const [categoryIndex, setCategoryIndex] = useState(0);
  // const [selectedCategory, setSelectedCategory] = useState(categories[0].name);
  const [drawing, setDrawing] = useState(false);
  const [position, setPosition] = useState({lat:'',lng:''});
  const [latLng, setlatLng] = useState({'coords':{latitude:'',longitude:''}});

const dispatch =  useDispatch()


    

// console.log('bubble ===>>>', bubble)

	useEffect(() => {
    if(published && !isLoading && updateBubbles){

      // dispatch(setUpdateBlubbles(true))
      clean();
      //navigation.navigate('Camera')
      // setTimeout(()=>{},1000)
           
    }
       
  },[isLoading,updateBubbles])
  
  useEffect(() => {
    // setTypedText('')
    // setTextTool(false)
    // setLoaded(true)
    if(!final && !textTool && initialScreen && !fileUri){
      console.log('entrou no up inicialmente')
      setTimeout(up,100);
      permissionAccess();

    }

  })
  


  const permissionAccess = async ()=>{
    const granted =  await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        title: "App Camera Permission",
        message:"Blubb precisa ter acesso a sua câmera ",
        buttonNeutral: "Perguntar depois",
        buttonNegative: "Cancelar",
        buttonPositive: "OK"
      }
    );
    console.log('granted permission', granted)
    setGranted(granted)

  }

	const chooseImage = async () => {
	    
	    const response= await showImagePicker(options)
	      console.log('Response = ', response);

	      if (response.didCancel) {
	        console.log('User cancelled image picker');
	      } else if (response.error) {
	        console.log('ImagePicker Error: ', response.error);
	      } else if (response.customButton) {
	        console.log('User tapped custom button: ', response.customButton);
	        //alert(response.customButton);
	      } else {
	        const source = { uri: response.uri };

	        // You can also display the image using data:
	        // const source = { uri: 'data:image/jpeg;base64,' + response.data };
	        // alert(JSON.stringify(response));s
	        console.log('response', JSON.stringify(response));
	        
	          const resp = response.assets[0]
          setFilePath(resp) 
          setFileData(resp.data)
          setFileUri(resp.uri)
	        
	      }
	    
  }

  const launchCameraFunction = async () => {
    // let options = {
    //   storageOptions: {
    //     skipBackup: true,
    //     path: 'images',
    //   },
    // };
    try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        title: "App Camera Permission",
        message:"Blubb precisa ter acesso a sua câmera ",
        buttonNeutral: "Perguntar depois",
        buttonNegative: "Cancelar",
        buttonPositive: "OK"
      }
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Camera permission given");
      const response = await launchCamera(options);
   
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.errorCode) {
        console.log('ImagePicker errorCode: ', response.errorCode);
      } else if (response.errorMessage) {
        console.log('errorMessage: ', response.errorMessage);
        //alert(response.errorMessage);
      } else if(response.assets) {
    
        const resp:any = response.assets[0]
          setFilePath(resp) 
          setFileData(resp.data)
          setFileUri(resp.uri)
      }

    } else {
      console.log("Camera permission denied");
    }
  } catch (err) {
    console.warn(err);
  }
    
    

  }

  const launchImageLibraryFunction = async () => {
    
    const response = await launchImageLibrary(options)
      // console.log('Response = ', response);

     
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.errorCode) {
        console.log('ImagePicker errorCode: ', response.errorCode);
      } else if (response.errorMessage) {
        console.log('errorMessage: ', response.errorMessage);
        //alert(response.errorMessage);
      } else if(response.assets) {
        console.log('response library', JSON.stringify(response));
        const resp:any = response.assets[0]
          setFilePath(resp) 
          setFileData(resp.data)
          setFileUri(resp.uri)
          setInitialScreen(false)
      }
       
       
       
      
    

  }

  const PendingView = () => (
  <View
    style={{
      flex: 1,
      backgroundColor: 'lightgreen',
      justifyContent: 'center',
      alignItems: 'center',
    }}
  >
    <Text>Waiting</Text>
  </View>
);

  const renderFileData = ()=> {
    if (fileData) {
    	console.log("fileData",fileData)
      return <Image source={{ uri: 'data:image/jpeg;base64,' + fileData }}
        style={styles.images}
      />
    } else {
      return <Image source={require('./../../assets/images/icon.png')}
        style={styles.images}
      />
    }
  }

  const takePicture = async function() {
    const options = { quality: 0.7,  };//base64: true
    const data = await camera.takePictureAsync(options);
    //  eslint-disable-next-line
    console.log(data);
    setFilePath(data) 
    setInitialScreen(false)
    setFileUri (data.uri)
  };

  const renderFileUri = () =>{
  	console.log("fileUri",fileUri)
    if (fileUri) {
      if(fileUri != lastFileUri){
        setInitialScreen(false)
        setLastFileUri(fileUri)
        console.log('entrou no fileUri')
        setTimeout(down,1000)
      }
      return <Image
        source={{ uri: fileUri }}
        style={styles.selectedImages}
      />
    } else {      
        return <View></View>
      }
    
      // <Image
      //   source={require('./../../assets/images/icon.png')}
      //   style={styles.selectedImages}
      // />
    }
  

  const changeBubbleColor =()=>{
  	let index = bubbleIndex
  	++index
  	if(index>=bubbleList.length){
  		index=0
  	}
  	setBubbleIndex(index)
  	setBubble(bubbleList[index])
  }
  const changeEffect =()=>{
    let index = effectIndex
    ++index
    if(index>=effectList.length){
      index=0
    }
    const params:any = effectList[index]
    setEffectIndex(index)
    setTextDecorationLine(params.textDecorationLine)
    setTextShadowColor(params.textShadowColor)
  }
  const changeTextAlign =()=>{
    let index = alignIndex
    ++index
    if(index>=alignList.length){
      index=0
    }
    setAlignIndex(index)
    setTextAlign(alignList[index])
  }
  const changeTextColor =()=>{
    let index = textColorIndex
    ++index
    if(index>=colorList.length){
      index=0
    }
    setTextColorIndex(index)
    setTextColor(colorList[index])
  }
  // const changeCategory =()=>{
  //   let index = categoryIndex
  //   ++index
  //   if(index>=categories.length){
  //     index=0
  //   }
  //   // setCategoryIndex(index)
  //   // setSelectedCategory(categories[index].name)
  // }

  
  const showDrawing = ()=>{
    setDrawing(true)
  }

  const publishMessage = async (type)=>{
    try {
      // alertWithType parameters: type, title, message, payload, interval.
      // payload object that includes a source property overrides the image source prop. (optional: object)
      // interval takes precedence over the closeInterval prop. (optional: number)
      if(type == "init") {
        dropDownAlertRef.alertWithType('info', 'Info', 'Postando sua nova Blubb');
      } else{
        const message = 'Nova Blubb postada com sucesso'
        dropDownAlertRef.alertWithType('success', 'Sucesso', message);
      }
      
      
      
      // throw 'Error fetch data'; // example error
    } catch (error) {
      dropDownAlertRef.alertWithType('error', 'Error', error);
    }


  }

  const changeColorLetter = ()=>{



  }
  const changeColor = ()=>{
    setShowColor(true)
    let ind = colorIndex + 1
    if(ind == backgroundList.length){
      ind =0
    }
    setColorIndex(ind)
    const img = backgroundList[ind]
    setColorImage(img);
    console.log(img)
    console.log(ind)

  }
  const changeFontFamily = ()=>{
    let ind = ffIndex + 1
    if(ind == fontList.length){
      ind =0
    }
    setFfIndex(ind)
    const img = fontList[ind]
    setFontFamily(img);
    console.log(img)
    console.log(ind)

  }
  const publish = async ()=>{
  	console.log("Camera user ===>>> ",user)
    if(!title){
      return;
    }

  	const obj:any = {
  		title:title,
			category: 'c9a44db2-9192-469c-814e-355e28111e76',
			color: String(bubbleIndex),
			lat: position.lat,
			lng: position.lng,
			user: user.id,
			visibility: 'public',
			file : filePath,
			content: [
        {'userName': user.name},
        {'picture': user.picture || ''},
			  {contentType:'text',backGround:colorIndex, content:typedText, color:textColor, textAlign, fontFamily, fontSize, textDecorationLine, textShadowColor}
        
			]
		}

  	console.log("publish", obj);
    // return
    // await publishMessage("init")

  	//await dispatch(postCameraStart(obj))
    
    //dispatch(setUpdateBlubbles(true))

    setTimeout(()=>{setPublished(true)},500)

    }
    

    // this.message.showMessage('Nova bolha postada com sucesso', 3000)

  



	return (

    
		<View style={styles.container}>
              <View>
                <DropdownAlert
                  ref={(ref) => {
                    if (ref) {
                      dropDownAlertRef = ref;
                    }
                  }}
                />
              </View>
             
		          {
                final ? (
               <View style={styles.body}>
                 
                <View style={{height:380}}>

                <Text style={{textAlign:'center',fontSize:20,marginBottom:0}} >New Blubb</Text>
                <View style={styles.ImageSections}>
                  <View style={{position:'absolute',elevation:0,top:55}}>
                    
                    <Image style={[styles.imageCircle]} source={IconUser} />
                    <Image style={[styles.imageCircle,{top:-150}]} source={IconCircle} />
                  </View>
                  <View style={{alignItems:'center', width:'80%',maxWidth:'80%'}}>
                    <Text numberOfLines={2} style={{elevation:1,width:'100%', textAlign:'center',color:'white',fontSize:20, marginTop:110, textShadowColor:'black', textShadowOffset:{width:2,height:2}, textShadowRadius:70}}>{title}</Text>
                    <Text numberOfLines={1} style={{borderRadius:30, marginHorizontal:5, width:'50%', textAlign:'center',color:'white',fontSize:16, marginTop:60, backgroundColor:'black'}}>{user.name}</Text>
                    {/*{renderFileUri()}*/}
                  </View>
           
                </View>
                <View style={[styles.overlay]} >
                  <Image style={styles.image} source={bubble} />
                </View>
                </View>

                <View>
                  <TextInput autoFocus={true} maxLength={35}
                      placeholder = 'digite seu título aqui' 
                      value={title}
                      numberOfLines={2}
                      onChangeText={(text) => setTitle(text)}
                      style={
                    {textAlign:'center',fontFamily:'Poppins-Regular',fontSize:20,marginVertical:5}} />
                </View>

                {/*<View style={styles.btnParentSection}>
                  

                  <TouchableOpacity onPress={launchCameraFunction} style={styles.btnSection}  >
                    <Text style={styles.btnText}>Tirar uma foto</Text>
                  </TouchableOpacity>

                  <TouchableOpacity onPress={launchImageLibraryFunction} style={styles.btnSection}  >
                    <Text style={styles.btnText}>Ler imagem da biblioteca</Text>
                  </TouchableOpacity>
                </View>*/}
                <View style={styles.footerCamera}>
                  <View style={[styles.buttonContainer]}>

                    <Text>cor da Blubb</Text>
                    <TouchableOpacity onPress={() => changeBubbleColor()}  style={styles.touchableContainer}>
                      <Image source={bubble} style={styles.blubb} />  
                      <View style={styles.absoluteView}>
                        <Text>trocar</Text>
                      </View>
                      
                          
                    </TouchableOpacity>
                  </View>
                  {/*<View style={styles.buttonContainer}>
                    <Text>Tema da nova Blubb?</Text>
                    <TouchableOpacity onPress={() => changeCategory()} style={styles.touchableContainer}>
                      <Text>{selectedCategory}</Text>
                    </TouchableOpacity>
                  </View>*/}
                  <View style={styles.buttonContainer}>
                    <Text>Tempo de duração?</Text>
                    <TouchableOpacity style={[styles.touchableContainer,{backgroundColor: colors.primaryButton}]}>
                      <Text>24h</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={styles.buttonContainer}>
                    <Text>Quem pode ver</Text>
                    <TouchableOpacity style={[styles.touchableContainer,{backgroundColor: colors.primaryButton}]}>
                      <Text>Todos</Text>
                    </TouchableOpacity>
                  </View>
                  <Button 
                  // contentStyle={{width: '100%',height:50}}
                    // labelStyle={{width: '100%'}}
                    style={[styles.shareButton, {backgroundColor: colors.primaryButton}]} onPress={()=> publish()} loading={isLoading}>
                    <Text style={{color:'#c6c6c6',fontFamily:'Poppins-Regular'}}> 
                      Publicar
                    </Text>
                  </Button>
                </View>

              </View>) : initialScreen && !textTool ? (
                 
      granted === PermissionsAndroid.RESULTS.GRANTED ? (

        <View style={styles.containerCam}>
        
        <RNCamera
          ref={ref => {
                        setCamera(ref);
                    }}
          style={styles.preview}
          type={camType}
          flashMode={flash}
          captureAudio={false}
          androidCameraPermissionOptions={{
            title: 'Permission to use camera',
            message: 'We need your permission to use your camera',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
          
        >
          
        </RNCamera>
      </View>) : (<View></View>)
                     
                 
                
                ) :(
                  <View style={[styles.footerCamera,{width:'100%', height:500,alignContent:'center'}]}>
                  {/*<Text>
                    Text Toll
                  </Text>*/}
                  <View style={{flex:1, width:'100%'}}>
                  
                   <TouchableOpacity onPress={changeColor} style={{ width:'100%', height:'100%'}}  >
                    <Image style={{width:'100%'}} source={colorImage} />
                   </TouchableOpacity>
                  </View>
                  {fileUri ? (renderFileUri()):(<View></View>)}
                  {
                    textTool ? (
                      <View style={{ position:'absolute',top:150,width:'90%', backgroundColor:'transparent', paddingTop:5, width:'90%',alignContent:'center'}}>
                        <TextInput
                          style={{fontSize:fontSize, color:textColor, fontFamily, backgroundColor:'transparent', borderWidth:0, borderColor:'transparent', textDecorationLine, textDecorationStyle: "solid",textDecorationColor: "#000",textShadowColor, textShadowOffset:{width:3,height:3},textShadowRadius:90}}
                          autoCapitalize='sentences'//'none'
                          multiline
                          numberOfLines={4}
                          autoFocus={true}
                          maxLength={500}
                          placeholder = 'digite seu texto aqui'
                          value={typedText}
                          textAlign={textAlign}
                          onChangeText={(text) => setTypedText(text)}
                         />
                  </View> 

                      ):(<View></View>)}
                    {!textToolSecond && fileUri && !final ?

                    (<View style={{position:'absolute',bottom:10, right:15,flex:1,width:50,height:50,elevation:3}}>
                        <TouchableOpacity onPress={()=>{setFinal(true)}} style={styles.btnIcon}  >
                         <Image source={IconArrow} style={{width:45,height:45}} />
                       </TouchableOpacity>
                      </View>)
                  : (<View></View>)}
                  {textTool && !fileUri && !final ?

                    (<View style={{position:'absolute',top:10, right:15,flex:1,width:50,height:50,elevation:3}}>
                        <TouchableOpacity onPress={()=>{down(),setFinal(true)}} style={styles.btnIcon}  >
                         <Image source={IconArrow} style={{width:45,height:45}} />
                       </TouchableOpacity>
                      </View>)
                  : (<View></View>)}
                  
                </View>
                )
                  
                 
              }

		          
              {/*<Message
                ref={(message) => {
                  this.message = message;
                  console.log('message',this.message)
                } }
                animation={'slideX'}
                position={'top'}>
              </Message>*/}

              <Animated.View
                    style={[
                      styles.footerContainer,
                      {transform: [
                        {
                          translateY: moveAnim,
                        },
                      ],}
                    ]}
                  >
                    {/*<Text>Fading View!</Text>*/}
                    
                    {/*<Image source={bubble} style={styles.bubble}  />*/}
                    {
                      !textTool ? (
                    
                    <View style={styles.iconContainer}>
                      <TouchableOpacity onPress={launchImageLibraryFunction} style={styles.btnIcon}  >
                       <Image source={IconUpload} style={styles.menuIcon} />
                       </TouchableOpacity>
                       <TouchableOpacity onPress={text} style={styles.btnIcon}  >
                       <Image source={IconTextBlack} style={styles.menuIcon} />
                       </TouchableOpacity>
                        <TouchableOpacity onPress={takePicture} style={styles.btnIconPink}  >
                       <Image source={IconRecPink} style={styles.btnIcon} />
                       </TouchableOpacity>
                       <TouchableOpacity onPress={()=>{flash == RNCamera.Constants.FlashMode.on ? setFlash(RNCamera.Constants.FlashMode.off):setFlash(RNCamera.Constants.FlashMode.on)}} style={styles.btnIcon}  >
                       <Image source={IconFlashBack} style={styles.menuIcon} />
                       </TouchableOpacity>
                       <TouchableOpacity onPress={()=>camType == RNCamera.Constants.Type.back ? setCamType(RNCamera.Constants.Type.front):setCamType(RNCamera.Constants.Type.back)} style={styles.btnIcon}  >
                       <Image source={IconInvertBlack} style={styles.menuIcon} />
                       </TouchableOpacity>
                       
                    </View>):(
                    <View style={styles.iconContainer}>


                      <TouchableOpacity onPress={changeTextAlign} style={styles.btnIcon}  >
                         <Image source={IconAlign} style={styles.menuIcon} />
                       </TouchableOpacity>

                       <TouchableOpacity onPress={changeEffect} style={styles.btnIcon}  >
                         <Image source={IconEffectBlack} style={styles.menuIcon} />
                       </TouchableOpacity>
                        
                       <TouchableOpacity onPress={changeFontFamily} style={styles.btnIcon}  >
                         <Image source={IconLetter} style={styles.menuIcon} />
                       </TouchableOpacity>
                       

                       <TouchableOpacity onPress={changeTextColor} style={styles.btnIcon}  >
                         <Image source={IconColorLetter} style={styles.menuIcon} />
                       </TouchableOpacity>
                       
                       <TouchableOpacity onPress={()=>changeColor()} style={styles.btnIcon}  >
                         <Image source={IconColor} style={styles.menuIcon} />
                       </TouchableOpacity>
                       
                    </View>

                    )
                  }
                  </Animated.View>
                  <TouchableOpacity onPress={close}  style={styles.touchableContainerClose}>
                      <Image source={IconClose} style={styles.close} />  
                   </TouchableOpacity>
                   {
                     fileUri && !final ? (
                       <View style={{flex:1, flexDirection:'row', width:110, position:'absolute',right:5, top:20}}>
                         <View style={{ width:50}}>
                           <TouchableOpacity onPress={text}  style={{width:50}}>
                            <Image source={IconTextWhite} style={styles.close} />  
                           </TouchableOpacity>
                         </View>
                         <View style={{width:50}}>
                           <TouchableOpacity onPress={showDrawing}  style={{width:50}}>
                            <Image source={IconDrawing} style={styles.close} />  
                           </TouchableOpacity>
                         </View>
                       </View>

                       ) : (
                         <View></View>
                       )
                   }


			
		</View>
	);
};
const mapStateToProps = (state : RootState)=>(
  {
    user : state.userApp.user,  errorMessage : state.user.errorMessage
  }
)



export default connect(mapStateToProps)(Camera)



const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 0,
  }
  ,containerCam: {
    flex: 1,
    margin: 0,
    width:'100%',
    height:'100%',
    // backgroundColor:'red'

  },
  menuIcon:{
    width:25,height:25
  },
  btnIcon:{
    width:50,
    height: 50,
    // backgroundColor: '#DCDCDC',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 3,
    marginBottom:10,
    marginHorizontal:4
  
  },
  btnIconPink:{
    width:80,
    height: 80,
    // backgroundColor: '#DCDCDC',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 3,
    marginBottom:10
  
  },
  footerContainer:{
    flex:1,
    flexDirection: 'row',
    width: Dimensions.get('screen').width,
    height : 75,
    backgroundColor : 'white',
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    borderColor : 'black',
    borderWidth:1,
    borderBottomWidth : 0,
    position:'absolute',
    bottom:0,
    // alignItems:'center',
    justifyContent: 'center',
  },
  iconContainer:{
    marginTop:10,
    alignItems:'center',
    flexDirection: 'row',
    width:'90%'
    // ,borderWidth:1,borderColor:'black'
    ,justifyContent: 'center',

  }
  ,cameraContainer: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'black',
    height:500,
    width:500
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    width:'100%',
    height:'100%',
  },
  capture: {
    flex: 0,
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 15,
    paddingHorizontal: 20,
    alignSelf: 'center',
    margin: 20,
  },
	overlay: {
    flex: 1,
    position: 'absolute',
    left: Dimensions.get('screen').width/2-150,
    top: 0,
    width:'100%',
    height:300,
    opacity: 0.5,
    backgroundColor: 'transparent',
    marginTop:30
    // alignItems: "center",
    // justifyContent: "center",
  },
  image:{
  	width:300,
  	height:300,
  	alignItems: "center",
  },
  imageCircle:{
    width:150,
    height:150,
    alignItems: "center",
  },
  selectedImages:{
  	width:'100%',
  	height:'100%',
  	alignItems: "center",
    resizeMode:'contain'
  	// marginTop:50
  	// marginBottom:50
  },
	
	footerCamera: {
		flex: 1,
		// justifyContent: "space-around",
		alignItems: "center",
	},
	absoluteView: {
        flex: 1,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
	blubb:{
		flex: 1,
    resizeMode: 'cover', // or 'stretch'
    width:'100%',
    height:30,
    backgroundColor:'#fff'
	},
	buttonContainer: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "center",
		width: "80%",
		margin:10
	},
	shareButton: {
		borderRadius: 25,
    marginTop:30,
		width: "75%",
		height: 40,
		alignItems: "center",
		justifyContent: "center",
	},
  touchableContainerClose: {
    // borderRadius: 25,
    // backgroundColor: "pink",
    // borderWidth:2,
    width: 50,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    position : 'absolute',
    elevation:2,
    marginHorizontal:10,
    top:10
  },
  close : {
    width:25
    ,height:25
  },
	touchableContainer: {
		borderRadius: 25,
		
		width: "50%",
		height: 30,
		alignItems: "center",
		justifyContent: "center",
	},
	scrollView: {
    backgroundColor: Colors.lighter,
  },

  body: {
    backgroundColor: Colors.white,
    justifyContent: 'center',
    borderColor: 'black',
    borderWidth: 2,
    height: Dimensions.get('screen').height - 20,
    width: Dimensions.get('screen').width,
    paddingTop:20
  },
  ImageSections: {
    display: 'flex',
    flexDirection: 'row',
    paddingHorizontal: 4,
    paddingVertical: 2,
    justifyContent: 'center',
    alignContent:'center',
    marginTop:10
  },
  images: {
    width: 150,
    height: 150,
    borderColor: 'black',
    borderWidth: 1,
    marginHorizontal: 3
  },
  btnParentSection: {
    alignItems: 'center',
    marginTop:100
    // marginBottom:0
  },
  btnSection: {
    width: 225,
    height: 50,
    backgroundColor: '#DCDCDC',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 3,
    marginBottom:10
  },
  btnText: {
    textAlign: 'center',
    color: 'gray',
    fontSize: 14,
    fontWeight:'bold'
  }
});
