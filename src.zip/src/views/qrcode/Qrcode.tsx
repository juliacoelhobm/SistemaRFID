'use strict';
import React, { PureComponent,useState , useEffect} from 'react';
import { AppRegistry, ImageBackgroundBase, FlatList, StyleSheet, Text, TouchableOpacity, View, PermissionsAndroid } from 'react-native';
import { Badge, ListItem, Icon,Button } from '@rneui/themed'
import { RNCamera } from 'react-native-camera';
import { color, Value } from 'react-native-reanimated';
import {connect} from 'react-redux'
import {RootState} from './../../redux/RootReducer'
import { UserDataApiType} from "./../../@types/user/user"
import { ProdutoDataApiType} from "./../../@types/produto/produto"

import {useTheme} from 'react-native-paper'
import { MultipleSelectList } from 'react-native-dropdown-select-list'
import TouchableScale from 'react-native-touchable-scale';
import LinearGradient from 'react-native-linear-gradient'; // Only if no expo

import { createProductStart, postProductStart, getAllProductsStart} from './../../redux/products/productsActions'

import { useNavigation} from '@react-navigation/native'
import { useDispatch } from 'react-redux';

import Geolocation, { getCurrentPosition } from 'react-native-geolocation-service';



const PendingView = () => (
  <View
    style={{
      flex: 1,
      backgroundColor: 'lightgreen',
      justifyContent: 'center',
      alignItems: 'center',
    }}
  >
    <Text>Waiting</Text>
  </View>
);

interface StateProperties {
  bounds: any;
  data: any;
  type:any;
  target:any;
  position:any;
  qtd:any;
}

export interface Props{
  isLoading : boolean,
  errorMessage : string,
  user : UserDataApiType,
  categories : any,
  products:any,
  productsList:any
}





const Qrcode =({products, productsList,user}:Props)=> {

  const navigation = useNavigation()
  const {colors, fonts} = useTheme()
  const dispatch =  useDispatch();

  const [barcodes, setBarcodes] = useState<StateProperties[]>([]);
  const [barcodesData, setBarcodesData] = useState<StateProperties[]>([]);
  const [camera, setCamera] = useState(null);
  const [selected, setSelected] = React.useState([]);
  const [expanded, setExpanded] = React.useState(false);
  const [liberado, setLiberado] = React.useState(true);
  const [position, setPosition] = React.useState({});
  



  const getPosition = async ()=>{
    Geolocation.getCurrentPosition(
      (positionProp) => {
        console.log(positionProp);
        setPosition(positionProp)
      },
      (error) => {
        // See error code charts below.
        console.log(error.code, error.message);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  }
  const permissionAccess = async ()=>{
    console.log('permissionAccess was called')
    const granted =  await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,{
        'title': 'RFID App',
        'message': 'RFID App access to your location '
      }
    );
    console.log('granted permission', granted)
    

    if (granted === 'granted') {
      getPosition()
    }
    

  }

  const checkTime = ()=>{
    setLiberado(false)
    setTimeout(()=>setLiberado(true),2000)
  }

  useEffect(() => {
    permissionAccess();
    getPosition()
   
  },[]);
  // useEffect(() => {
  //   !productsList ? productsList = []:'';
  // },[productsList]);
   
   const barcodeRecognized = (scanResult:any) => {
        //setBarcodes(scanResult);
        /* console.warn(scanResult.type);
        console.warn(scanResult.data);
        console.warn(scanResult.bounds.origin); */
        if (scanResult.data != null) {
          scanResult.position = position;
          if (!barcodesData.includes(scanResult.data)) {
            
            scanResult.qtd = 1;

            //barcodes.push(scanResult);
            setBarcodes([
              scanResult,
              ...barcodes // Put old items at the end
            ]);
            setBarcodesData([
              scanResult.data,
              ...barcodesData // Put old items at the end
            ]);
            
            
            //console.warn('onBarCodeRead call');
            checkTime()
          }else{
            if(!liberado) return
            barcodesData.map((el, index)=>{
              if(el == scanResult.data){
                const itemFound = barcodes[index]
                const qtd = itemFound.qtd + 1;
                barcodes[index].qtd = qtd;
                checkTime();
              }
              console.log('qtd', barcodes[index].qtd )

            })
           
            

          }
        }
        
        console.log('barcodes', barcodes)
    }
    
    const RenderBarcode = (value:{bounds: any,data: any, type:any, qtd:number},index: number) => {
      const bounds=value.bounds;
      const data = value.data;
      const type = value.type;
      console.log('bounds =======>>>>>  ',bounds ,data, type);
      const x = Number(bounds.origin[0].x);
      const y = Number(bounds.origin[0].y);
      
      return (
        <React.Fragment key={data}>
          <View
            style={{
              borderWidth: 1,
              borderRadius: 5,
              position: 'absolute',
              borderColor: '#F00',
              justifyContent: 'center',
              alignContent: 'center',
              alignSelf:'center',
              backgroundColor: 'rgba(255, 255, 255, 0.9)',
              padding: 10,
              //...bounds.size,
              left: 50,
              top: 50+ 50 * index,
              width:250,
            }}
          >
            <Text style={{
              color: '#000',
              flex: 1,
              position: 'absolute',
              textAlign: 'center',
              backgroundColor: 'transparent',
              width:250
            }}>{data} - {type}</Text>

            <Button 
            style={{
              color: '#fff',
              flex: 1,
              position: 'absolute',
              textAlign: 'center',
              backgroundColor: 'transparent',
              top:15
            }}
            onPress={() => {
              setBarcodes(
                barcodes.filter(a =>
                  a.data !== data
                )
              );
            }}>
              <Text style={{
              color: '#fff',
             
            }}>Retirar</Text>
            </Button>
            
          </View>
        </React.Fragment>
      )};
      const RenderBarcodes = () => (
        <View style={{position:'absolute', flex:1,top:50,  paddingLeft:50, backgroundColor:'transparent'}}>
          <Text style={{color:'white'}}>Códigos lidos</Text>
          {/* {barcodes && barcodes.map(RenderBarcode)} */}
        </View>
      );

      const takePicture = async function(camera: RNCamera) {
        const options = { quality: 0.5, base64: true };
        const data = await camera.takePictureAsync(options);
        //  eslint-disable-next-line
        console.log(data.uri);
      };
      const saveQrcodes = async function() {
        console.log('productsList ==> ' ,productsList);
        
        barcodesData.map((item: any,index: number)=>{
          let dataToSend ={}
          if (!productsList.includes(item)) {
            productsList = [item, ...productsList]
            const element:any = barcodes[index];
            if(element.logs && element.logs.length){
              element.logs = [{date : new Date(Date.now()) , user : {name : user.name} , type : 'Entrada', qtd : element.qtd}, ...element.logs]
            }else{
              element.logs = [{date : new Date(Date.now()) , user : {name : user.name} , type : 'Entrada', qtd : element.qtd}]
            }
            
            console.log('element===>>>',element)
            products = [element, ...products]
            dataToSend = {
              nome: element.data,
              empresa: user.empresa,
              ativo: true,
              //date: new Date(Date.now()),
              compra:'0',
              venda:'0',
              //link: '',
              //picture: '',
              //description: '',
              //categoria: '',
             // position,
              //qtd: element.qtd,
              quantidade: element.qtd,
              //lastQtd: 0,
              //lastAction: '',
              identificacao:[{tipo: element.type, codigo:element.data}],
              minimo: 0,
              tipoTransacao : 'Entrada',
              localizacao : position
    
            }
            
            

          }else{
            productsList.map((e: any,i: number)=>{
              if(e == item){
                const element = products[i]
                const qtd_last = element.qtd;
                const total = barcodes[index].qtd + products[i].qtd;
                products[i].logs = [{date : new Date(Date.now()) , user : {name : 'Tiago Hilkner Venegas'} , type : 'Entrada',qtd_last, qtd : barcodes[index].qtd, total},...products[i].logs]
                console.log(products[i].logs)
                
                products[i].qtd = barcodes[index].qtd +element.qtd;

                dataToSend = {
                  nome: element.data,
                  empresa: user.empresa,
                  ativo: true,
                  //date: new Date(Date.now()),
                  compra:'0',
                  venda:'0',
                  //link: '',
                  //picture: '',
                  //description: '',
                  //categoria: '',
                 // position,
                  //qtd: element.qtd,
                  quantidade: element.qtd,
                  //lastQtd: 0,
                  //lastAction: '',
                  identificacao:[{tipo: element.type, codigo:element.data}],
                  minimo: 0,
                  tipoTransacao : 'Entrada',
                  localizacao : position
        
                }
              }

            })
            
          }

          console.log('dataToSend', dataToSend)
          dispatch(createProductStart(dataToSend))


        })
        
        //dispatch(postProductStart({barcodes:products,barcodesData : productsList}))
        
        setTimeout(()=>{
          dispatch(getAllProductsStart());
          navigation.navigate('Products') },800)
        
        //  eslint-disable-next-line
      };

     /*  const renderItem = ({item} ) => (
        <React.Fragment key={item.data}>
       
        </React.Fragment>
      ) */

     


   // return (<View style={styles.container}><Text style={{color:'white'}}>Qrcode</Text></View>)
     return (
    
      
      <View style={styles.container}>
        <RNCamera
        ref={ref => {
            setCamera(ref);
        }}
          style={styles.preview}
          defaultTouchToFocus
          type={RNCamera.Constants.Type.back}
          flashMode={RNCamera.Constants.FlashMode.on}
          //onGoogleVisionBarcodesDetected={this.barcodeRecognized}
          
          androidCameraPermissionOptions={{
            title: 'Permission to use camera',
            message: 'We need your permission to use your camera',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
          androidRecordAudioPermissionOptions={{
            title: 'Permission to use audio recording',
            message: 'We need your permission to use your audio',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
          onBarCodeRead={barcodeRecognized}
        >
          {({ camera, status, recordAudioPermissionStatus }) => {
            
            if (status !== 'READY') return <PendingView />;
            return (
              <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center' }}>
                
                <TouchableOpacity onPress={() => saveQrcodes()} style={styles.capture}>
                  <Text style={{ fontSize: 14 }}> Gravar </Text>
                </TouchableOpacity>
              </View>
              
            );
          }}
          
        </RNCamera>
        {barcodes && barcodes.length ? <RenderBarcodes />  : <View></View>}
        <View style={{ position:'absolute',flex: 1,width:'100%', justifyContent: 'center' }}>
       
          <FlatList
              data={barcodes}
              keyExtractor={item => item.data}
              renderItem={({item})=>(
                <React.Fragment key={item.data}>
                  {/* <ListItem.Accordion
                    content={
                      <>
                        <Icon name="place" size={30} />
                        <ListItem.Content>
                          <ListItem.Title>List Accordion</ListItem.Title>
                        </ListItem.Content>
                      </>
                    }
                    isExpanded={expanded}
                    onPress={() => {
                      setExpanded(!expanded);
                    }}> */}
                <ListItem.Swipeable
                leftContent={(reset) => (
                  <Button
                    title="Info"
                    onPress={() =>{reset()} }
                    icon={{ name: 'info', color: 'white' }}
                    buttonStyle={{ minHeight: '100%' }}
                  />
                )}
                rightContent={(reset) => (
                  <Button
                    title="Retirar"
                    onPress={() => {
                      setBarcodes(
                        barcodes.filter(a =>
                          a.data !== item.data
                        )
                      );
                      setBarcodesData(
                        barcodesData.filter(a =>
                          a !== item.data
                        )
                      );
                    reset()}}
                    icon={{ name: 'delete', color: 'white' }}
                    buttonStyle={{ minHeight: '100%', backgroundColor: 'red' }}
                  />
                )}

                Component={TouchableScale}
                
                linearGradientProps={{
                  colors: ['#FF9800', '#F44336'],
                  start: { x: 1, y: 0 },
                  end: { x: 0.2, y: 0 },
                }}
                ViewComponent={LinearGradient} // Only if no expo
                topDivider
                >
                <Badge value={item.qtd||1} status="primary" />
                <ListItem.Content>
                  <ListItem.Title  style={{ color: 'white', fontWeight: 'bold' }}>{item.data}</ListItem.Title>
                  <ListItem.Subtitle>{item.type} - qtd: {item.qtd}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
              </ListItem.Swipeable>
{/* </ListItem.Accordion> */}

              </React.Fragment>
              )
              
              }
            />
        
        
            
         
        </View>
        {/* <View style={{ flex: 1, justifyContent: 'center' }}>

        
        <MultipleSelectList 
        setSelected={(val: React.SetStateAction<never[]>) => setSelected(val)} 
        data={barcodesData} 
        save="value"
        onSelect={() => console.log(selected)} 
        label="QrCodes"
        placeholder="Adicione QrCodes"
        
        search={false}
        inputStyles={{backgroundColor:'white'}}
        dropdownTextStyles={{backgroundColor:'white'}}
        dropdownItemStyles={{backgroundColor:'white'}}
        boxStyles={{borderRadius:0, backgroundColor:'white'}} //override default styles
        notFoundText='Item não encontrado'
       
        />
        </View> */}

      </View>
      
    );
  
}



const stateToProps = (state : RootState)=>(
  {
    user : state.userApp.user, selectedUser: state.userApp.selectedUser, productsList: state.products.productsList ,products:state.products.products, product:state.products.product, isLoading: state.userApp.isLoading , errorMessage : state.user.errorMessage
  }
)



export default connect(stateToProps)(Qrcode)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'black',
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  capture: {
    flex: 0,
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 15,
    paddingHorizontal: 20,
    alignSelf: 'center',
    margin: 20,
  },
});

