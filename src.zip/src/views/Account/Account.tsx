import { FlatList, StyleSheet, Text, View } from "react-native";
import React from "react";
import UserConfigItem from "../userConfig/UserConfigItem";

type Props = {
  navigation: any;
};

const Account = ({ navigation }: Props) => {
  const accountMenu = [
    {
      title: "Informações pessoais",
      action: navigation.navigate("profileInfo"),
    },
    // {
    //   title: "Formas de pagamento",
    //   action: navigation.navigate("PaymentMethods"),
    // },
    {
      title: "Sua atividade",
      action: navigation.navigate("Activity"),
    },
    {
      title: "Status da conta",
      action: navigation.navigate("AccountStatus"),
    },
    // {
    //   title: "Idioma",
    //   action: navigation.navigate("Language"),
    // },
    {
      title: "Uso de dados",
      action: navigation.navigate("DataUsage"),
    },
    {
      title: "Temas de interesse",
      action: navigation.navigate("Themes"),
    },
  ];

  return (
    <View>
      {/* 
          <FlatList
        data={accountMenu}
        renderItem={(item) => (
          <UserConfigItem title={item.item.title} action={item.item.action} />
        )}
        keyExtractor={(item) => item.title}
      />


        */}
      <Text>Minha Conta</Text>
    </View>
  );
};

export default Account;

const styles = StyleSheet.create({});
