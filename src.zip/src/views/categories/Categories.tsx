import {
    KeyboardAvoidingView,
    StyleSheet,
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    Platform,
    ScrollView
  } from "react-native";
  import { useDispatch } from 'react-redux';
  import { useNavigation} from '@react-navigation/native'
  import {updateUserStart} from '../../redux/userApp/userAppActions'
  import {postProductStart, updateProductStart} from '../../redux/products/productsActions'
  import {createCategoryStart, getAllCategoriesStart} from '../../redux/categories/categoriesActions'
  import React, { useState , useEffect} from "react";
  import { Button , useTheme} from "react-native-paper";
  import {connect} from 'react-redux'
  import {RootState} from '../../redux/RootReducer'
  import { UserDataApiType} from "../../@types/user/user"
  import { ProdutoDataApiType} from "../../@types/produto/produto"
  import {CategoriasDataApiType} from "../../@types/categories/categories"
  import { Badge, ListItem, Icon,FAB, Dialog  } from '@rneui/themed'
  import IconCircle from './../../assets/png/showblubb/ring_gradient_130x130px.png';
  import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png';
  
  import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
  import DateTimePicker from '@react-native-community/datetimepicker';
  import moment from 'moment'
  import MapView, { Marker } from 'react-native-maps';
    import { ICON_SIZE } from "react-native-paper/lib/typescript/components/TextInput/Adornment/TextInputIcon";
  // user_pict_gray_130x130px.png
  
  
  export interface Props{
    isLoading : boolean,
    errorMessage : string,
    user : UserDataApiType,
    categories :CategoriasDataApiType,
    product:ProdutoDataApiType,
    products:Array<[]>,
    productsList:[],
    latitude:any,
    longitude:any,
 
  }
  
  const Categories = ({isLoading, errorMessage, user, product, products, productsList, categories}: Props) => {
    //const dispatch = useDispatch();
    const navigation = useNavigation()
    const {colors} = useTheme();
    const [name, setName] = useState("");
    const [nickname, setNickname] = useState("");
    const [age, setAge] = useState("");
    const [address, setAddress] = useState("");
    const [data, setData] = useState("");
    const [description, setDescription] = useState("");
    const [type, setType] = useState("");
    const [qtd, setQtd] = useState(0);
    const [target, setTarget] = useState("");
    const [bounds, setBounds] = useState({});
    const [logs, setLogs] = useState([]);
    const [position, setPosition] = useState({coords:{latitude:'',longitude:''}});
    const [bio, setBio] = useState("");
    const [filePath, setFilePath] = useState('');
    const [fileData, setFileData] = useState('');
    const [fileUri, setFileUri] = useState('');
    const [date, setDate] = useState(new Date(Date.now()));
    const [initiFileUri, setInitFileUri] = useState('');
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);
    const [visible, setVisible] = useState(true);
    const dispatch = useDispatch()

    const getAllCategories=()=>{
      dispatch(getAllCategoriesStart())
    }
  
    useEffect(() => {

      if(user){
        /* console.log('user ==>',user)
        console.log('user.empresa ==>',user.empresa) */

      }
      if(!categories) categories = []

      getAllCategories();
          
          /* if(categories.length == 0){
            const newCategories:CategoriasDataApiType = [
                {nome:'Alimentos',id:1,productsList:[]},
                {nome:'Insumos',id:2,productsList:[]},
                {nome:'Materia de Construção',id:3,productsList:[]},


            ]
            dispatch(createCategoryStart(newCategories))
          } else {


          } */
         
          
          
          
        
          
    },[])

    const toggleDialog1 = () => {
      setVisible(!visible);
    };
  
    const submitLogs = () => {
      const dataToSend:any = {
        name,
        date,
        data,
        target,
        type,
        bounds,
        description,
        qtd,
        picture:fileUri||'',
        logs
        // picture : user.picture
        // , categories
      };
      console.log('data to send ', dataToSend)
      //filePath ? dataToSend.file = filePath : ''
      //age ? dataToSend.birthdate= age : ''
      //Criar aq a chamada da ação updateUserStart passando os dados de input

      productsList.map((item,index)=>{
        console.log(item, index)
        console.log('data',data)
        if(item == data){
          console.log('entrou', dataToSend)
          products[index]=dataToSend
        }

      })
      console.log('products',products)
      dispatch(postProductStart({barcodes:products,barcodesData:productsList}))
      navigation.navigate('Products')
    };

    const createCategory=(text: CategoriasDataApiType)=>{
      console.log('text',text)
      dispatch(createCategoryStart({nome: text, empresa: user.empresa}))
      const interval = setInterval(()=>{
        if(!isLoading){
          getAllCategories();
          clearInterval(interval)
        }
      },500)
      
    }
  
    const renderFileUri = () =>{
      console.log("fileUri",fileUri)
      if (fileUri) {
        return <Image
          source={{ uri: fileUri }}
          style={styles.selectedImages}
        />
      } else {      
          return <Image resizeMode='contain' source={IconUser} style={{width:'100%',height:90, marginBottom:5,marginTop:30}} />
      }
    }
  
    
    
  
    return (

      <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}>
      
      <View style={styles.inner}>
        
        <ScrollView contentContainerStyle={styles.contentContainer}>
  
        {
    categories&&categories.map((l:{
        nome: string,
        id: string,
}, i) => {
    moment.locale('pt-br');
    //const dateTransform = (moment(l.date).format('DD-MM-YYYY h:m'));
    return (
      <ListItem key={i} bottomDivider>
        <Badge value={1} status="success" />
        
        <ListItem.Content>
          <ListItem.Title>{l.nome}</ListItem.Title>
          {/* <ListItem.Subtitle>id: {l.id} </ListItem.Subtitle> */}
        </ListItem.Content>
      </ListItem>
    )})
  }
          
          </ScrollView>
          <Dialog
            isVisible={!visible}
            onBackdropPress={toggleDialog1}
          >
            <Dialog.Title title="Criar categoria"/>
            <Text>Digite o nome da nova categoria</Text>
            <TextInput
            style={styles.inputText}
            value={name}
            onChangeText={(text) => setName(text)}
            placeholder="nome da categoria"
           
          />
          
          <Button
          loading={isLoading}
          style={{
            width: "40%",
            alignSelf: "center",
            borderRadius: 15,
            marginTop: 40,
            backgroundColor: colors.primaryButton
          }}
          mode="contained"
          onPress={() =>  
            {
              createCategory(name)
              setVisible(!visible);
            
            }
            /* Alert.alert(
            "Esolha uma opção",
            "O que deseja fazer com o item  "+ data,
            [
              {
                text: "Cancelar",
                onPress: () => {setVisible(!visible);},
                style: "cancel"
              },
              { text: "Acrescentar", onPress: () => {setVisible(!visible);} }
            ]) */
          }
        >
          Criar
        </Button>
          </Dialog>
          
          <FAB
            loading={isLoading}
            visible={visible}
            icon={{ name: 'add', color: 'white' }}
            size="small"
            onPress={() => setVisible(!visible)}
            color={colors.primaryButton}
          />
        </View>
        {/* <MapView
          initialRegion={{
            latitude: Number(position.coords.latitude)||37.78825,
            longitude: Number(position.coords.longitude)||-122.4324,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}
          
          style={{height:300, width:'100%'}}

        >
          <Marker
            pinColor='#090909'
            coordinate={product.position.coords}
            title={product.data}
            description={product.description}
          />
        </MapView> */}
        
        
        
  
      </KeyboardAvoidingView>
    );
  };
  
  
  const profileStateToProps = (state : RootState)=>(
    {
      user : state.userApp.user, categories:state.categories.categories, selectedUser: state.userApp.selectedUser, productsList: state.products.productsList ,products:state.products.products, product:state.products.product, isLoading: state.categories.isLoading , errorMessage : state.user.errorMessage
    }
  )
  
  
  
  export default connect(profileStateToProps)(Categories)
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      // padding: 20,
      backgroundColor:'white'
     
    },
    inner: {
      padding: 24,
      flex: .9,
      //justifyContent: "space-around"
    },
    selectedImages:{
      width:200,
      height:200,
      alignItems: "center",
      // resizeMode:'contain',
      // marginTop:50
      marginBottom:10,
      borderRadius:200/6
    },
    photoPerfilContainer: {
      borderBottomWidth: 1,
      height:250,
      alignItems:'center'
      // ,borderWidth:1
    },
    btnIcon:{
      marginTop:5,
      // height:25,
      // borderWidth:1,
      // borderColor:'black',
      alignItems:'center',
    },
    infoContainer: {
      padding: 2,
      backgroundColor:'white',
      alignContent:'flex-start',
      
    },
    inputTitle: {
      fontSize: 18,
    },
    inputText: {
      fontSize: 20,
    },
  });
  