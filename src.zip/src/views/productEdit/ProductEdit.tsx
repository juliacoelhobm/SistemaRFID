import {
  Alert,
    KeyboardAvoidingView,
    StyleSheet,
    Text,
    TextInput,
    View,
    Image,
    TouchableOpacity,
    Platform,
    PermissionsAndroid,
    ScrollView,

  } from "react-native";
  import { useDispatch } from 'react-redux';
  import { useNavigation} from '@react-navigation/native'
  import {updateUserStart} from '../../redux/userApp/userAppActions'
  import {postProductStart, updateProductStart, getAllProductsStart} from '../../redux/products/productsActions'
  import React, { useState , useEffect} from "react";
  import { Button , useTheme} from "react-native-paper";
  import {connect} from 'react-redux'
  import {RootState} from '../../redux/RootReducer'
  import { UserDataApiType} from "../../@types/user/user"
  import {CategoriasDataApiType} from "../../@types/categories/categories"
  import { ProdutoDataApiType} from "../../@types/produto/produto"
  import { MultipleSelectList,SelectList  } from 'react-native-dropdown-select-list'
  import IconCircle from './../../assets/png/showblubb/ring_gradient_130x130px.png';
  import IconUser from './../../assets/png/showblubb/user_pict_gray_130x130px.png';
  import {Avatar, Badge, ListItem, ButtonGroup } from '@rneui/themed'
  import {launchCamera, launchImageLibrary,showImagePicker} from 'react-native-image-picker';
  import DateTimePicker from '@react-native-community/datetimepicker';
  import moment from 'moment'
  import categoriesActionTypes from "../../redux/categories/categoriesTypes";
  import Geolocation, { getCurrentPosition } from 'react-native-geolocation-service';
  // user_pict_gray_130x130px.png

  const apiKey = 'AIzaSyD6_lxrnSfNGuhKxErqagxzGb5AGuCcZbg';
  
  interface LogsProperties {
   
    date: any; 
    user: any;
    type:any;
    position?:any;
    qtd:any;
    
  }
  interface IdentificacaoProperties {
    codigo: any; 
    tipo: any;
  }
  //
  export interface Props{
    isLoading : boolean,
    errorMessage : string,
    user : UserDataApiType,
    categories :CategoriasDataApiType,
    selectedBlubb : any,
    collection : any,
    product:ProdutoDataApiType,
    products:Array<[]>,
    productsList:[]
  }
  
  const ProductEdit = ({isLoading, errorMessage, user, product, products, productsList, categories}: Props) => {
    //const dispatch = useDispatch();
    const navigation = useNavigation()
    const {colors} = useTheme();
    const [name, setName] = useState("");
    const [nickname, setNickname] = useState("");
    const [age, setAge] = useState("");
    const [address, setAddress] = useState("");
    const [data, setData] = useState("");
    const [_id, setId] = useState(null);
    const [description, setDescription] = useState("");
    const [type, setType] = useState("");
    const [target, setTarget] = useState("");
    const [bounds, setBounds] = useState({});
    const [position, setPosition] = useState({});
    const [qtd, setQtd] = useState(0);
    const [bio, setBio] = useState("");
    const [logs, setLogs] = useState<LogsProperties[]>([]);
    const [filePath, setFilePath] = useState('');
    const [fileData, setFileData] = useState('');
    const [fileUri, setFileUri] = useState('');
    const [date, setDate] = useState(new Date(Date.now()));
    const [initiFileUri, setInitFileUri] = useState('');
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);
    const [modifyType, setModifyType] = useState('');
    const [modify, setModify] = useState(false);
    const [edited, setEdited] = useState(false);
    const [qtdModify, setQtdModify] = useState(0);
    const [newQtd, setNewQtd] = useState(0);
    const [category, setCategory] = useState('');
    const [compra, setCompra] = useState('1');
    const [venda, setVenda] = useState('2');
    const [tipoTransacao, setTipoTransacao] = useState('Entrada'); //Saida
    const [qtdMov, setQtdMov] = useState(0); 
    const [identificacao, setIdentificacao] = useState<IdentificacaoProperties[]>([]);
    const [selectedCategory, setSelectedCategory] = useState({key:0,value:'Defina uma categoria'});


    const dispatch = useDispatch()


    const getPosition = async ()=>{
      Geolocation.getCurrentPosition(
        (positionProp) => {
          console.log(positionProp);
          setPosition(positionProp)
        },
        (error) => {
          // See error code charts below.
          console.log(error.code, error.message);
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
      );
    }
    const permissionAccess = async ()=>{
      console.log('permissionAccess was called')
      const granted =  await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,{
          'title': 'RFID App',
          'message': 'RFID App access to your location '
        }
      );
      console.log('granted permission', granted)
      
  
      if (granted === 'granted') {
        getPosition()
      }
      
  
    }

    

    useEffect(() => {
      if(!isLoading && edited){
        setEdited(false)
        dispatch(getAllProductsStart())
        navigation.navigate('Products')
      }
     
    });
    useEffect(() => {
      permissionAccess();
      getPosition()
      if(!isLoading && edited){
        navigation.navigate('Products')
      }
     
    },[]);
  
    useEffect(() => {
          //setName(user.name)
          /* setNickname(user.nickname || user.givenName)
          setBio(user.profile )
          setAge(user.birthdate) */
          console.log('product ===> ', product)
          console.log('products =====> ', products)
          console.log('productsList =====> ', productsList)
          let identificacaoProd:any
          if(product.identificacao && product.identificacao.length){
            setIdentificacao(product.identificacao)
            identificacaoProd = product.identificacao[0]
            console.log('identificacaoProd ==>>>', identificacaoProd);
          }
          if(identificacaoProd.type){
            setType(identificacaoProd.type)
          }      
          if(identificacaoProd.codigo){
            setData(identificacaoProd.codigo)
          }
          if(product.quantidade){
            setQtd(product.quantidade)
          }
          if(product.compra){
            setCompra(String(product.compra))
          }
          if(product.venda){
            setVenda(String(product.venda))
          }
          if(product._id){
            setId(product._id)
          }
          if(product.date){
            console.log('product.date',product.date)
            //setDate(new Date(product.date))
            moment.locale('pt-br');
            setAge(moment(product.date).format('DD-MM-YYYY'));
            
          }
          if(product.nome){
            setName(product.nome)
          }
          if(product.description){
            setDescription(product.description)
          }
          if(product.target){
            setTarget(product.target)
          }
          
          if(product.bounds){
            setBounds(product.bounds)
          }
          if(product.position){
            setPosition(product.position)
          }
          if(product.logs){
            setLogs(product.logs)
          }
          if(product.categoria){
            setCategory(product.categoria)
            categories.map((el: { nome: any, _id:any },index: string)=>{
              console.log(el._id , el.nome)
              if(el._id==product.categoria){
                console.log('found')
                setSelectedCategory({key:el._id,value:el.nome})
              }

            })

          }
          if(product.qtd){
            setQtd(product.qtd)
            setNewQtd(product.qtd)
          }
          if(product.picture){
            console.log('picture ===> ',product.picture)
            setFileUri(product.picture)
            setInitFileUri(product.picture)
          }
          
    },[product])
  
    const submitProductEdit = () => {
      const dataToSend:any = {
        _id,
        nome : name,
        date,
        description,
        position,
        quantidade: qtd,
        qtdModify,
        tipoTransacao,
        identificacao,
        //picture:fileUri||'',
        categoria: category,
        compra,
        venda,
        // picture : user.picture
        // , categories
      };
      console.log('data to send ', dataToSend)
      //filePath ? dataToSend.file = filePath : ''
      //age ? dataToSend.birthdate= age : ''
      //Criar aq a chamada da ação updateUserStart passando os dados de input

      productsList.map((item,index)=>{
        console.log(item, index)
        console.log('data',data)
        if(item == data){
          console.log('entrou', dataToSend)
          products[index]=dataToSend
        }

      })
      console.log('products',products)
      dispatch(updateProductStart(dataToSend))
      setEdited(true)
    };
  
    const renderFileUri = () =>{
      console.log("fileUri",fileUri)
      if (fileUri) {
        return <Image
          source={{ uri: fileUri }}
          style={styles.selectedImages}
        />
      } else {      
          return <Image resizeMode='contain' source={IconUser} style={{width:'100%',height:100, marginBottom:10}} />
      }
    }
  
    const launchImageLibraryFunction = async () => {
      let options:any = {
        storageOptions: {
          skipBackup: true,
          path: 'images',
        },
      };
      const response = await launchImageLibrary(options)
        // console.log('Response = ', response);
        if (response.didCancel) {
          console.log('User cancelled image picker');
        } else if (response.errorCode) {
          console.log('ImagePicker Error: ', response.errorMessage);
       
        } else {
          const source = { uri: response.uri };
          console.log('response library', JSON.stringify(response));
           const resp = response.assets[0]
            setFilePath(resp) 
            setFileData(resp.data)
            setFileUri(resp.uri)
        }
    }
  
    const onChange = (event: any, selectedDate: any) => {
      const currentDate = selectedDate;
      console.log('currentDate ==>',currentDate)
      setShow(Platform.OS === 'ios');
      setDate(currentDate);
      moment.locale('pt-br');
      setAge(moment(currentDate).format('DD-MM-YYYY'));
      console.log('currentDate', currentDate)
    };

    const component1 = () => <Button
    loading={isLoading}
    style={{
      width: "30%",
      alignSelf: "center",
      borderRadius: 0,
      marginTop: 0,
      backgroundColor: colors.primaryButton
    }}
    mode="contained"
    onPress={() =>  {
      const newValue = qtdModify > 0  ? qtdModify-1 : 0

      modifyType == 'Saida' ? setNewQtd(qtd - newValue) : setNewQtd(qtd + newValue)
      setQtdModify(newValue)
    }}
  >-</Button>
    const component2 = () => <Text style={styles.inputTitleQtd}>{qtdModify}</Text>
    const component3 = () => <Button
    loading={isLoading}
    style={{
      width: "30%",
      alignSelf: "center",
      borderRadius: 0,
      marginTop: 0,
      backgroundColor: colors.primaryButton
    }}
    mode="contained"
    onPress={() =>  {
      const newValue = qtdModify+1
      //if(modifyType=='Saida' && newValue > newQtd)
      modifyType == 'Saida' ? setNewQtd(qtd - newValue) : setNewQtd(qtd + newValue)
      
      setQtdModify(newValue)
    }}
  >+</Button>

    const buttons = [{ element: component1 }, { element: component2 }, { element: component3 }]
  
    return (
      <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}>

      { modify ? (
          <View style={{backgroundColor: 'white',borderColor:'pink', elevation:11, width:'100%', height:600, alignItems:'center'}}>
            <Text style={styles.inputTitle}>Modificar quantidade</Text>
            <Text>{modifyType == 'adicionar' ? 'Escolha quantos itens deseja adicionar' : 'Escolha quantos itens deseja Saida'}</Text>
            
            <Text>Quantidate atual {qtd}</Text>
            
            <ButtonGroup
                onPress={(index)=>{
                  console.log('pressed'+index)
                }}
                selectedIndex={1}
                buttons={buttons}
                containerStyle={{height: 100}} />

            <Text style={styles.inputTitle}>Quantidate atualizada:{newQtd}</Text>

            <Button
              loading={isLoading}
              style={{
                width: "40%",
                alignSelf: "center",
                borderRadius: 15,
                marginTop: 40,
                backgroundColor: colors.primaryButton
              }}
              mode="contained"
              onPress={() =>  {
                let total;
                const qtd_last = product.qtd;
                total = (modifyType == 'Saida' ? product.qtd - qtdModify : product.qtd + qtdModify);
                 
                const newLog = {date : new Date(Date.now()) , user : {name : 'Tiago Hilkner Venegas'} , type :modifyType, qtd_last, qtd : qtdModify, total}
                setLogs([newLog , ...logs])
                setQtd(newQtd)
                setModify(false)
              }}
            >confirmar</Button>

          </View>
        ) : (<View></View>)
      }

      
      
      <View style={styles.inner}>

      <ScrollView contentContainerStyle={styles.contentContainer}>

        <View style={styles.photoPerfilContainer}>
          {renderFileUri()}
        </View>
        <View>
          <TouchableOpacity onPress={launchImageLibraryFunction} style={styles.btnIcon}  >
            <Text>Definir foto do produto</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.infoContainer}>

        <SelectList 
            setSelected={(val: any) => {
              console.log('val' , val)
              categories.map((el: { _id: any; nome: any; }, ind: any)=>{
                if (el.nome == val){
                  setCategory(el._id)
                }
  
              })

              
            }} 
            data={categories.map((el: { _id: any; nome: any; }, ind: any)=>{
              return {key: el._id , value : el.nome}

            })} 
            defaultOption={selectedCategory}
            searchPlaceholder='Categorias'
            placeholder="Defina uma categoria"
            save="value"
        />
        
          <Text style={styles.inputTitle}>Nome</Text>
          
          <TextInput
            style={styles.inputText}
            value={name}
            onChangeText={(text) => setName(text)}
            placeholder="Escreva o nome do item"
           
          />

<Text style={styles.inputTitle}>Quantidade: {qtd}</Text>
          <Button
          loading={isLoading}
          style={{
            width: "40%",
            alignSelf: "center",
            borderRadius: 15,
            marginTop: 40,
            backgroundColor: colors.primaryButton
          }}
          mode="contained"
          onPress={() =>  Alert.alert(
            "Esolha uma opção",
            "O que deseja fazer com o item  "+ data,
            [
              {
                text: "Saída",
                onPress: () => {setModifyType('Saida'),setTipoTransacao('Saida'),setModify(true)},
                style: "cancel"
              },
              { text: "Entrada", onPress: () => {setModifyType('Entrada'),setTipoTransacao('Entrada'),setModify(true)} }
            ])}
        >
          alterar
        </Button>



          <Text style={styles.inputTitle}>Compra</Text>
          <TextInput
            style={styles.inputText}
            value={compra}
            onChangeText={(text) => setCompra(text)}
            placeholder="Escreva o preço de compra do item"
            keyboardType="numeric"
          />
          <Text style={styles.inputTitle}>Venda</Text>
          <TextInput
            style={styles.inputText}
            value={venda}
            onChangeText={(text) => setVenda(text)}
            placeholder="Escreva o preço de venda do item"
            keyboardType="numeric"
           
          />
          
          <Text style={styles.inputTitle}>Code</Text>
          <TextInput
            style={styles.inputText}
            value={data}
            onChangeText={(text) => setData(text)}
            placeholder="Defina código do item"
          />
         
         
          <Text style={styles.inputTitle}>Validade</Text>
          <TouchableOpacity style={{width:'100%',height:50 }} onPress={()=>setShow(true)}>
            <View pointerEvents="none"> 
              <TextInput
                selectTextOnFocus={false}
                label={"Vencimento"}
                // mode={"outlined"}
                value={age}
                style={{ height: 40, backgroundColor:'transparent',borderWidth:0 }}
                //onChangeText={(text) => setDate(text)}
              />
            </View>
          </TouchableOpacity>
       
        
          
              
          {show && (
                <DateTimePicker
                  testID="dateTimePicker"
                  value={date}
                  mode={'date'}
                  is24Hour={true}
                  display="spinner"
                  onChange={onChange}
                  //style={{borderWidth:5}}
                />
                )}
              
      
          <Text style={styles.inputTitle}>Descrição</Text>
          <TextInput
            style={styles.inputText}
            value={description}
            onChangeText={(text) => setDescription(text)}
            multiline
            placeholder="Escreva a descrição do item"
          />
          {/* <Text style={styles.inputTitle}>Quem é você ?</Text>
          <TextInput
            value={bio}
            onChangeText={(text) => setBio(text)}
            multiline
            placeholder="Escreva sua bio"
          /> */}
          
  
        </View>

        </ScrollView>

        <Button
          loading={isLoading}
          style={{
            width: "60%",
            alignSelf: "center",
            borderRadius: 15,
            marginTop: 40,
            backgroundColor: colors.primaryButton
          }}
          mode="contained"
          onPress={() => submitProductEdit()}
        >
          Salvar
        </Button>
        
        
        </View>
  
      </KeyboardAvoidingView>
    );
  };
  
  
  const profileStateToProps = (state : RootState)=>(
    {
      user : state.userApp.user, categories: state.categories.categories , productsList: state.products.productsList ,products:state.products.products, product:state.products.product, isLoading: state.products.isLoadingProducts , errorMessage : state.user.errorMessage
    }
  )
  
  
  
  export default connect(profileStateToProps)(ProductEdit)
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      // padding: 20,
      backgroundColor:'white'
      ,height:'80%'
    },
    inner: {
      padding: 12,
      flex: 1,
      justifyContent: "space-around"
    },
    selectedImages:{
      width:150,
      height:150,
      alignItems: "center",
      // resizeMode:'contain',
      // marginTop:50
      marginBottom:10,
      borderRadius:200/6
    },
    photoPerfilContainer: {
      borderBottomWidth: 1,
      // height:150,
      alignItems:'center'
      // ,borderWidth:1
    },
    btnIcon:{
      marginTop:5,
      height:20,
      // borderWidth:1,
      // borderColor:'black',
      alignItems:'center',
    },
    infoContainer: {
      flex:1,
      padding: 2,
      backgroundColor:'white'
    },
    inputTitle: {
      marginTop:5,
      fontSize: 14,
    },
    inputTitleQtd: {
      marginTop:5,
      fontSize: 20,
      color:'white'
    },
    inputText: {
      fontSize: 16,
    },
  });
  