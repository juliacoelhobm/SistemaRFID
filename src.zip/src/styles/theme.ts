
import {DefaultTheme as PaperDefaultTheme, DarkTheme as PaperDarkTheme, Theme as PaperTheme, configureFonts} from 'react-native-paper'

type CustomColors = {
	primary1 : string;
	primaryButton : string;
	light1 : string;
	light2 : string;
	dark1 : string;
	dark2 : string;
	secondary1 : string;
	secondary2 : string;
	secondary3 : string;
	secondary4 : string;
	secondary5 : string;
	accend1 : string;
	accend2 : string;
	accend3 : string;
	accend4 : string;
	accend5 : string;
	backgroundLight1 : string;
	backgroundLight2 : string;
	backgroundDark1 : string;
	textdark1 : string;
	textdark2 : string;
	textLight1 : string;
	textLight2 : string;
	brandColor1 : string;
	brandColor2 : string;
	brandColor3 : string;
	brandColor4 : string;
	brandColor5 : string;
}
type PaperColors = PaperTheme['colors']
type Colors = PaperColors & CustomColors
export interface Theme extends PaperTheme{
	colors : Colors,

}
const _fontConfig = {
	
		medium : 'Poppins-Bold' 
		,regular : 'Poppins-Regular' 
	
};

// const fontConfig = {
//     ios: _fontConfig,
//     android: _fontConfig,
// };

type FontWeight =
  | 'normal'
  | 'bold'
  | '100'
  | '200'
  | '300'
  | '400'
  | '500'
  | '600'
  | '700'
  | '800'
  | '900';

const fontConfig = {
  default: {
    regular: {
      fontFamily: 'Poppins-Regular',
      fontWeight: <FontWeight>'normal',
    },
    medium: {
      fontFamily: 'Poppins-Bold',
      fontWeight: <FontWeight>'bold',
    },
    // light: {
    //   fontFamily: 'HelveticaNeue-Light',
    //   fontWeight: <FontWeight>'normal',
    // },
    
  },
};




// let customFonts = {
//     'Poppins-Regular': require('./../assets/fonts/Poppins-Regular.ttf'),
//     'Poppins-Bold': require('./../assets/fonts/Poppins-Bold.ttf'),
    
// }


const theme:Theme = {
  ...PaperDefaultTheme,
  roundness: 2,
  colors: {
    ...PaperDefaultTheme.colors,
    primary: '#662d91',
    primaryButton: '#ec008c',
    accent: '#f0a2d1',
    background : '#f7f9fa',
    surface : '#92d9f3',
    text : 'black',
    // text : '#d399fe',
    primary1 : '#662d91',
	light1 : '#d399fe',
	light2 : '#995cc8',
	dark1 : '#502671',
	dark2 : '#35184b',
	secondary1 : '#92d9f3',
	secondary2 : '#3cc2f4',
	secondary3 : '#00aeef',
	secondary4 : '#008fc5',
	secondary5 : '#025979',
	accend1 : '#f0a2d1',
	accend2 : '#f059b3',
	accend3 : '#ec008c',
	accend4 : '#c10073',
	accend5 : '#870351',
	backgroundLight1 : '#f7f9fa',
	backgroundLight2 : '#f6eaff',
	backgroundDark1 : '#35184b',
	textLight1 : '#000000',
	textLight2 : '#502671',
	textdark1 : '#de99f3',
	textdark2 : '#35184b',
	brandColor1 : '#ec008c',
	brandColor2 : '#66d291',
	brandColor3 : '#00aeef',
	brandColor4 : '#0db14b',
	brandColor5 : '#9aca3c',

  },
  fonts: configureFonts(fontConfig),

  // fonts : {
  // 	regular : 'Poppins-Regular',
  // 	medium : 'Poppins-Bold'
  // }

};

export default theme;









