// import { StatusBar } from 'expo-status-bar';
import React from 'react';
import {useEffect} from 'react'
import { Provider, useDispatch } from 'react-redux';
import {loginStart} from './redux/user/userActions'
import store from './redux/store';
import {PersistGate} from 'redux-persist/integration/react'
import { StyleSheet, Text, View } from 'react-native';
import Main from './Main'
import {Provider as PaperProvider} from 'react-native-paper'
import theme from './styles/theme'
import { NavigationContainer } from '@react-navigation/native';
// import Constants from 'expo-constants';
import DropdownAlertComponent from  './components/messages/DropDownAlertComponent'
import SplashScreen from  "react-native-splash-screen";

// import * as SplashScreen from 'expo-splash-screen';

// SplashScreen.preventAutoHideAsync()
//   .then(result => console.log(`SplashScreen.preventAutoHideAsync() succeeded: ${result}`))
//   .catch(console.warn); // it's good to explicitly catch and inspect any error



const App =()=> {
  React.useEffect(() => {
     SplashScreen.hide();
   });
  
  return (
    // @ts-ignore
    <Provider store={store.store}>
          <PersistGate persistor={store.persistor}  >

            <View style={{flex:1}}>
              <NavigationContainer>
                <PaperProvider theme={theme}>
                  <DropdownAlertComponent/>
                  <Main/>
                </PaperProvider>
                
              </NavigationContainer>
              
            </View>
              
           </PersistGate> 
        </Provider>
        )

}
export default App

