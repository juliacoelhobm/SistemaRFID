export interface EmpresaDataApiType {
   
  nome: string,
  email: string,
  telefone: string,
  cnpj: string,
  ativo: boolean,
  inicioAtividades: Date,
  finalAtividades: Date,
  site?: string,
  observacao: string,
  endereco: JSON;
}