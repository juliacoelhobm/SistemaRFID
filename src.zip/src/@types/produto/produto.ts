interface IdentificacaoProperties {
  codigo: any; 
  tipo: any;
}
export interface ProdutoDataApiType {
    _id: any;
    nome: string,
    empresa:string,
    bounds : JSON,
    data : string,
    type: string,
    target: string,
    ativo: boolean,
    date: Date,
    compra:string,
    venda:string,
    link?: string,
    picture?: string,
    description: string,
    categoria: string,
    endereco: JSON,
    position:{coords: {latitude: any,longitude: any}},
    logs:[],
    qtd: number,
    quantidade: number,
    lastQtd: number,
    lastAction: string,
    identificacao:[],
    minimo: 0,
  }