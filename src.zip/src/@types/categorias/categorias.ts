export interface CategoriasDataApiType {
   
    nome: string,
    id: string,
    productsList: any,

  }