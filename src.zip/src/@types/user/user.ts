export interface UserDataApiType {
  picture: string;
  name: string;
  empresa?: string,
  nome: string,
  email: string,
  password: string,
  ativo?: boolean,
  permissoes?: JSON
}