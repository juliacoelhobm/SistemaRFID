import userAppActionTypes from '../userApp/userAppTypes';
import {UserDataApiType} from './../../@types/user/user'
// CREATE NEW USER

export const createNewUserStart = (user: any) => ({
  type: userAppActionTypes.CREATE_NEW_USER_START,
  payload: user,
});

export const setSelectedUser = (user: any) => ({
  type: userAppActionTypes.SET_SELECTED_USER,
  payload: user,
});

export const createNewUserSuccess = (successMessage: string) => ({
  type: userAppActionTypes.CREATE_NEW_USER_SUCCESS,
  payload: successMessage,
});

export const createNewUserFailure = (error: string) => ({
  type: userAppActionTypes.CREATE_NEW_USER_FAILURE,
  payload: error,
});

// logout

export const logoutFailure = error => ({
  type: userAppActionTypes.LOGOUT_FAILURE,
  payload: error,
});
export const logoutStart = () => ({
  type: userAppActionTypes.LOGOUT,
  payload: {},
});
export const logoutSuccess = () => ({
  type: userAppActionTypes.LOGOUT_SUCCESS,
  payload: {},
});

// UPDATE USER

export const updateUserStart = (user : UserDataApiType) => ({
  type: userAppActionTypes.UPDATE_USER_START,
  payload: user,
});

export const updateUserSuccess = (successMessage: string) => ({
  type: userAppActionTypes.UPDATE_USER_SUCCESS,
  payload: successMessage,
});

export const updateUserFailure = (error: string) => ({
  type: userAppActionTypes.UPDATE_USER_FAILURE,
  payload: error,
});

// UPDATE USER

export const updateUserCategoriesStart = (user : {categories : string[]}) => ({
  type: userAppActionTypes.UPDATE_USER_CATEGORIES_START,
  payload: user,
});

export const updateUserCategoriesSuccess = (user: UserDataApiType) => ({
  type: userAppActionTypes.UPDATE_USER_CATEGORIES_SUCCESS,
  payload: user,
});

export const updateUserCategoriesFailure = (error: string) => ({
  type: userAppActionTypes.UPDATE_USER_CATEGORIES_FAILURE,
  payload: error,
});

//DELETE USER

export const deleteUserStart = (userId: string) => ({
  type: userAppActionTypes.DELETE_USER_START,
  payload: userId,
});

export const deleteUserSuccess = (successMessage: string) => ({
  type: userAppActionTypes.DELETE_USER_SUCCESS,
  payload: successMessage,
});

export const deleteUserFailure = (error: string) => ({
  type: userAppActionTypes.DELETE_USER_FAILURE,
  payload: error,
});

//GET USER

export const getUserStart = () => ({
  type: userAppActionTypes.GET_USER_START,
  
});

export const getSelectedUserStart = (userId: string) => ({
  type: userAppActionTypes.GET_SELECTED_USER_START,
  payload: userId,
});

export const getUserSuccess = (user: any) => ({
  type: userAppActionTypes.GET_USER_SUCCESS,
  payload: user,
});

export const getSelectedUserSuccess = (user: any) => ({
  type: userAppActionTypes.GET_SELECTED_USER_SUCCESS,
  payload: user,
});

export const getUserFailure = (error: string) => ({
  type: userAppActionTypes.GET_USER_FAILURE,
  payload: error,
});
export const getSelectedUserFailure = (error: string) => ({
  type: userAppActionTypes.GET_SELECTED_USER_FAILURE,
  payload: error,
});

//GET ALL USERS

export const getAllUsersStart = () => ({
  type: userAppActionTypes.GET_ALL_USERS_START,
});

export const getAllUsersSuccess = (users: string[]) => ({
  type: userAppActionTypes.GET_ALL_USERS_SUCCESS,
  payload: users,
});

export const getAllUsersFailure = (error: string) => ({
  type: userAppActionTypes.GET_ALL_USERS_FAILURE,
  payload: error,
});

//FOLLOW USER

export const followUserStart = (userId: string) => ({
  type: userAppActionTypes.FOLLOW_USER_START,
  payload: userId,
});

export const followUserSuccess = (successMessage: string) => ({
  type: userAppActionTypes.FOLLOW_USER_SUCCESS,
  payload: successMessage,
});

export const followUserFailure = (error: string) => ({
  type: userAppActionTypes.FOLLOW_USER_FAILURE,
  payload: error,
});

// GET ALL FOLLOWERS FROM USER

export const getAllFollowersFromUserStart = (userId: string) => ({
  type: userAppActionTypes.GET_ALL_FOLLOWERS_FROM_USER_START,
  payload: userId,
});

export const getAllFollowersFromUserSuccess = (followers: string[]) => ({
  type: userAppActionTypes.GET_ALL_FOLLOWERS_FROM_USER_SUCCESS,
  payload: followers,
});

export const getAllFollowersFromUserFailure = (error: string) => ({
  type: userAppActionTypes.GET_ALL_FOLLOWERS_FROM_USER_FAILURE,
  payload: error,
});

//GET ALL FOLLOWED USERS FROM USER

export const getMyFollowersStart = (userId: string) => ({
  type: userAppActionTypes.GET_MY_FOLLOWERS_START,
  payload: userId,
});

export const getMyFollowersSuccess = (myFollowers: string[]) => ({
  type: userAppActionTypes.GET_MY_FOLLOWERS_SUCCESS,
  payload: myFollowers,
});

export const getMyFollowersFailure = (error: string) => ({
  type: userAppActionTypes.GET_MY_FOLLOWERS_FAILURE,
  payload: error,
});