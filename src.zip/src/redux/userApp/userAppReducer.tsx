import userAppActionTypes from './userAppTypes';
const initialState = {
  user: null,
  users: null,
  followersFromUser: [],
  myFollowers: [],
  successMessage: null,
  errorMessage: null,
  haveCategories : false,
  selectedUser : null,
  selectedUserId : null,
  isLogged : false,
  uniqueUserID : null,
  isLoading: false,
  
};
const userAppReducer = (state = initialState, action) => {
  const {type, payload} = action;

  switch (type) {
    case userAppActionTypes.CREATE_NEW_USER_START:
    case userAppActionTypes.SET_SELECTED_USER:
      return{
        ...state,
        errorMessage: null,
        selectedUser: payload
        // isLoading: fals,
      }
    case userAppActionTypes.LOGOUT : 
      return {
        ...state, errorMessage:null, isLoading:false, user:{}, isLogged:false
      }  
    case userAppActionTypes.LOGOUT_SUCCESS : 

      return {
        ...state, errorMessage:null , user: null, isLoading : false, isLogged : false, uniqueUserID : null
      }
    case userAppActionTypes.LOGOUT_FAILURE : 

      return {
        ...state, errorMessage:payload , isLoading : false
      }
    case userAppActionTypes.UPDATE_USER_START:
    case userAppActionTypes.DELETE_USER_START:
    case userAppActionTypes.GET_USER_START:
    case userAppActionTypes.GET_SELECTED_USER_START:
    case userAppActionTypes.GET_ALL_USERS_START:
    case userAppActionTypes.FOLLOW_USER_START:
    case userAppActionTypes.GET_ALL_FOLLOWERS_FROM_USER_START:
    case userAppActionTypes.GET_MY_FOLLOWERS_START:
      return {
        ...state,
        errorMessage: null,
        isLoading: true,
      };
    case userAppActionTypes.CREATE_NEW_USER_FAILURE:
    case userAppActionTypes.UPDATE_USER_FAILURE:
    case userAppActionTypes.DELETE_USER_FAILURE:
    case userAppActionTypes.GET_USER_FAILURE:
    case userAppActionTypes.GET_SELECTED_USER_FAILURE:
    case userAppActionTypes.GET_ALL_USERS_FAILURE:
    case userAppActionTypes.FOLLOW_USER_FAILURE:
    case userAppActionTypes.GET_ALL_FOLLOWERS_FROM_USER_FAILURE:
    case userAppActionTypes.GET_USER_SUCCESS:
      console.log('get user success ===> ', payload)
      return {
        ...state,
        isLoading: false,
        user: payload.user,
        uniqueUserID: payload.uniqueUserID,
        isLogged : true
        
      };
    case userAppActionTypes.GET_SELECTED_USER_SUCCESS:
      return {
        ...state,
        isLoading: false,
        selectedUser: payload,
      };
    case userAppActionTypes.GET_MY_FOLLOWERS_FAILURE:
      return {
        ...state,
        isLoading: false,
        errorMessage: payload,
      };

    case userAppActionTypes.CREATE_NEW_USER_SUCCESS:
    case userAppActionTypes.UPDATE_USER_SUCCESS:
      return {
        ...state,
        isLoading: false,
        user: payload,
      };

    case userAppActionTypes.UPDATE_USER_CATEGORIES_SUCCESS:
      return {
        ...state,
        isLoading: false,
        haveCategories: true,
        user: payload,
      };
    case userAppActionTypes.DELETE_USER_SUCCESS:
      return {
        ...state,
        isLoading: false,
        successMessage: payload,
      };
    case userAppActionTypes.GET_ALL_USERS_SUCCESS:
      return {
        ...state,
        isLoading: false,
        users: payload,
      };
    case userAppActionTypes.FOLLOW_USER_SUCCESS:
      return {
        ...state,
        isLoading: false,
        successMessage: payload,
      };
    case userAppActionTypes.GET_ALL_FOLLOWERS_FROM_USER_SUCCESS:
      return {
        ...state,
        isLoading: false,
        followersFromUser: payload,
      };
    case userAppActionTypes.GET_MY_FOLLOWERS_FAILURE:
      return {
        ...state,
        isLoading: false,
        myFollowers: payload,
      };
    default:
      return state;
  }
};
export default userAppReducer;
