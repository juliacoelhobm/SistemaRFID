import {put, takeLatest, all, call} from 'redux-saga/effects'
import {serverConfig} from '../../api/apiConfig';
import RfidApi from '../../api/rfidApi';
import AsyncStorage from '@react-native-async-storage/async-storage';
import userAppActionTypes from './userAppTypes';
import {loggedSuccess} from './../user/userActions';
import {putMessage} from './../messages/messagesActions'
import * as base64 from 'base-64';

import {
  createNewUserFailure,
  createNewUserStart,
  deleteUserFailure,
  deleteUserStart,
  followUserFailure,
  followUserSuccess,
  followUserStart,
  getAllFollowersFromUserFailure,
  getAllFollowersFromUserSuccess,
  getAllFollowersFromUserStart,
  getAllUsersFailure,
  getAllUsersStart,
  getMyFollowersFailure,
  getMyFollowersStart,
  getUserFailure,
  getUserSuccess,
  getUserStart,
  getSelectedUserFailure,
  getSelectedUserSuccess,
  getSelectedUserStart,
  updateUserFailure,
  updateUserStart,
  updateUserSuccess,
  updateUserCategoriesSuccess,
  updateUserCategoriesStart,
  updateUserCategoriesFailure,
  logoutSuccess,
  logoutFailure
} from './userAppActions';

import axios from 'axios'

export function* updateToken (renewToken: any) :Generator<object>{
  const rfidApi = new RfidApi(renewToken);
      const response:any = yield rfidApi.Fetch({
        method: 'post',
        url: `${serverConfig.pathUseCases.auth.authRefresh}`
      });

      if(response.data){
        yield AsyncStorage.setItem('AUTH_USER_TOKEN_KEY', response.data.token)		  
    	  yield AsyncStorage.setItem('AUTH_USER_RENEW_TOKEN_KEY', response.data.renewToken)		  
        return response.data.token
      }

}

export function* verifyToken (token: any){
  // Decodifica o token em arquivo json
  const decodeToken=()=> {
    const myToken = token
    if(! myToken ) {
      return null;
    }
    console.log('test token ===>>>', (base64.decode(myToken.split('.')[1])).toString('ascii'))
    return (base64.decode(myToken.split('.')[1])).toString('ascii');
  }

  const isExpired =(): boolean => {
    let tokenProps = decodeToken();
    if(typeof tokenProps == 'string')
      tokenProps = JSON.parse(tokenProps)
    console.log('myToken', tokenProps  )
    if(! tokenProps ) {
      return true;
    }
    const dtExpire = 1000 * tokenProps['exp'];
    console.log('dtExpire', tokenProps['exp'],dtExpire, + new Date());
    return ( (+ new Date() )> dtExpire ); 
  }

  const condicao = isExpired()

  return condicao

}

export function* getAllFollowersFromUserAsync({
  payload,
}: ReturnType<typeof getAllFollowersFromUserStart>) {
  try {

    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));

    const rfidApi = new RfidApi(tokenCognito);
    const response = yield rfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.userApp.getAllMyFollowers(payload)}`,
    });
    console.log('response : ', response);

    yield put(getAllFollowersFromUserSuccess(response.data.user));
  } catch (error) {
    yield put(getAllFollowersFromUserFailure('erro'));
  }
}

export function* getMyFollowersAsync({
  payload,
}: ReturnType<typeof getMyFollowersStart>) {
  try {
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));

    const RfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'post',
      body: {user: payload},
      url: `${serverConfig.pathUseCases.userApp.getAllMyFollowers(payload)}`,
    });
    console.log('response : ', response);

    yield put(getMyFollowersFailure('erro'));
  } catch (error) {
    yield put(getMyFollowersFailure('erro'));
  }
}

export function* followUserAsync({
  payload,
}: ReturnType<typeof followUserStart>) {
  try {
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));

    const RfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'post',
      body: {user: payload},
      url: `${serverConfig.pathUseCases.userApp.followUser}`,
    });
    console.log('response : ', response);

    yield put(followUserSuccess(response));
  } catch (error) {
    yield put(followUserFailure('erro'));
  }
}

export function* getAllUsersAsync({type}: ReturnType<typeof getAllUsersStart>) {
  try {
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));

    const RfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.userApp.getAllUsers}`,
    });
    console.log('response : ', response);

    yield put(getAllUsersFailure('erro'));
  } catch (error) {
    yield put(getAllUsersFailure('erro'));
  }
}

export function* deleteUserAsync({
  payload,
}: ReturnType<typeof deleteUserStart>) {
  try {
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));

    const RfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.userApp.getUser}`,
    });
    console.log('response : ', response);

    yield put(deleteUserFailure('erro'));
  } catch (error) {
    yield put(deleteUserFailure('erro'));
  }
}

export function* getUserAsync({}: ReturnType<typeof getUserStart>) :Generator<object>{
  try {
    
    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    console.log('token getUserAsync',token)
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    const rfidApi = new RfidApi(token);
    const response = yield rfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.userApp.getUser}`,
    });

    console.log('response getUserAsync',response)
    
    const user = response.data.data
    const uniqueUserID = response.data.data._id

    console.log('response getUserAsync user: ', user);
    // user.token = token
   
     const params = {
       user, uniqueUserID
     }
     yield put(getUserSuccess(params));

     // yield put(loggedSuccess(user));
      
  } catch (error) {
    console.log("error", error)
    yield put(getUserFailure('erro'));
  }
}

export function* getSelectedUserAsync({}: ReturnType<typeof getUserStart>) {
  try {    
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));
    const RfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.userApp.getUser}`,
    });
    console.log('response getUserAsync userApp')
    const user = response.data.user
    console.log('response getUserAsync user: ', user);
    yield put(getSelectedUserSuccess(user));
  } catch (error) {
    yield put(getSelectedUserFailure('erro'));
  }
}

export function* updateUserAsync({
  payload,
}: ReturnType<typeof updateUserStart>) {
  try {
    let data:any = payload
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));
    console.log('payload updateUserStart ', payload)
    const RfidApi = new RfidApi(tokenCognito);
    const responseS3 = yield RfidApi.Fetch({
      method: 'post',
      body: {},
      url: serverConfig.pathUseCases.blubb.postS3,
    });
    console.log('s3 ===>>>>', responseS3)
    
    const fileData = responseS3.data.fields
    console.log('s3 fileData init ===>>>>', fileData)
    console.log("url post s3" , serverConfig.s3.url)
 
    const config = {
        headers: {
                'Content-Type': 'multipart/form-data; charset=utf-8; boundary="another cool boundary";',
                'x-amz-acl' : 'public-read'
        }
    };

    let file:any = payload.file
    let responseS3File:any
    if(file){

      const form = new FormData();
    Object.keys(fileData).forEach((key) => {
        form.append(key, fileData[key]);
    });
    
    
    if(file && !file.type && file.uri){
      const list = file.uri.split('.')
      const len = list.length
      file['type'] = 'image/'+list[len-1]
    }
      
    console.log("file.type",file.type)
    if(file && file.type){
      form.append("file", file);
      form.append('Content-Type',file.type)
      console.log('form ====>> ',form)
      responseS3File = yield axios.post(serverConfig.s3.url, form, config)

    }
   
    console.log('responseS3File ===>>>>', responseS3File)
    let status = ''
    let image = ''
    let id = ''
    if(responseS3File&&responseS3File.status){
      status = responseS3File.status
      image = responseS3File.headers.location
      id = responseS3File.headers.location.split('/')[4]
      console.log('status', status)
      console.log('image', image)
      console.log('id ===> ', id)
      // return;
      if(status != '204') {
        console.log('falha no envio')
        return 
      }
     }
    console.log('Upload ok')
    delete payload.file
    console.log('payload ===================> ', payload)
    const finalObject = {}
    for (let i in payload){
      if(i!='file' && i != ''){
        const item = payload[i]
        finalObject[i] = item
      }
    }
    finalObject['picture'] = image  

    // finalObject['picture'] = [{id , path: image, contentType:file.type, name : file.fileName}]

    data = finalObject

    console.log('finalObject ==>>> ', finalObject)

    }
    
    
    const response = yield RfidApi.Fetch({
      method: 'patch',
      body: {user: data},
      url: `${serverConfig.pathUseCases.userApp.updateUser}`,
    });
    console.log('response update user: ', response);

    const user = response.data.user[0]
    console.log('user ====>>> ',user)
     yield put(putMessage("Dados atualizados com sucesso", "success"))
    yield put(updateUserSuccess(user));
  } catch (error) {
    yield put(updateUserFailure('erro'));
  }
}

export function* updateUserCategoriesAsync({
  payload,
}: ReturnType<typeof updateUserCategoriesStart>) {
  try {

    console.log("updateUserCategoriesAsync payload", payload)
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));
    console.log('tokenCognito ===>> ',tokenCognito)
    const RfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'patch',
      body: {user:{categories:payload.categories}},
      url: `${serverConfig.pathUseCases.userApp.updateUser}`,
    });
    console.log('response updateUserCategoriesAsync : ', response);

    yield put(updateUserCategoriesSuccess(response.data.user[0]));
  } catch (error) {
    console.log('error updateUserCategoriesStart',error)
    yield put(updateUserCategoriesFailure('erro'));
  }
}

export function* createNewUserAsync({
  payload,
}: ReturnType<typeof createNewUserStart>) {
  try {
    const tokenCognito = JSON.parse(yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY'));

    const RfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'post',
      body: {user: payload},
      url: `${serverConfig.pathUseCases.userApp.createNewUser}`,
    });
    console.log('response createNewUserAsync: ', response);

    yield put(createNewUserFailure('erro'));
  } catch (error) {
    yield put(createNewUserFailure('erro'));
  }
}

export function* logoutAsync(action){
  try{
    // Auth.signOut({ global: true })}
    yield put(logoutSuccess()) 

  }catch(error){
    yield put(logoutFailure(error.message)) 
  }

}

export function* onGetAllFollowersFromUserStart() {
  yield takeLatest(
    userAppActionTypes.GET_ALL_FOLLOWERS_FROM_USER_START,
    getAllFollowersFromUserAsync,
  );
}

export function* onGetMyFollowersStart() {
  yield takeLatest(
    userAppActionTypes.GET_MY_FOLLOWERS_START,
    getMyFollowersAsync,
  );
}

export function* onFollowUserStart() {
  yield takeLatest(userAppActionTypes.FOLLOW_USER_START, followUserAsync);
}

export function* onGetAllUsersStart() {
  yield takeLatest(userAppActionTypes.GET_ALL_USERS_START, getAllUsersAsync);
}

export function* onGetUserStart() {
  yield takeLatest(userAppActionTypes.GET_USER_START, getUserAsync);
}

export function* onGetSelectedUserStart() {
  yield takeLatest(userAppActionTypes.GET_SELECTED_USER_START, getSelectedUserAsync);
}

export function* onDeleteUserStart() {
  yield takeLatest(userAppActionTypes.DELETE_USER_START, deleteUserAsync);
}

export function* onUpdateUserStart() {
  yield takeLatest(userAppActionTypes.UPDATE_USER_START, updateUserAsync);
}

export function* onUpdateUserCategoriesStart() {
  yield takeLatest(userAppActionTypes.UPDATE_USER_CATEGORIES_START, updateUserCategoriesAsync);
}

export function* onCreateNewUserStart() {
  yield takeLatest(
    userAppActionTypes.CREATE_NEW_USER_START,
    createNewUserAsync,
  );
}
export function* onLogout(){
  yield takeLatest(userAppActionTypes.LOGOUT, logoutAsync)
}

export function* userAppSagas() {
  yield all([
    call(onCreateNewUserStart),
    call(onLogout),
    call(onUpdateUserStart),
    call(onDeleteUserStart),
    call(onGetUserStart),
    call(onGetSelectedUserStart),
    call(onGetAllUsersStart),
    call(onFollowUserStart),
    call(onGetMyFollowersStart),
    call(onGetAllFollowersFromUserStart),
    call(onUpdateUserCategoriesStart),
  ]);
}
