import {combineReducers} from 'redux';
import {persistReducer} from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';
import userReducer from './user/userReducer';
import productsReducer from './products/productsReducer';
import userAppReducer from './userApp/userAppReducer';
import categoriesReducer from './categories/categoriesReducer';

import messagesReducer from './messages/messagesReducer';
const persistConfig = {
  key: 'rfid',
  storage: AsyncStorage,
  whiteList: ['user','userApp','products'],
}
const rootReducer = combineReducers({
  user: userReducer,
  userApp: userAppReducer,
  messages: messagesReducer,
  products : productsReducer,
  categories : categoriesReducer,
});
export type RootState = ReturnType<typeof rootReducer>;
export const persistedReducer = persistReducer<RootState>(
  persistConfig,
  rootReducer,
);
