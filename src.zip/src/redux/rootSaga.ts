import {all,call} from 'redux-saga/effects'
import {userSagas} from './user/userSagas'
import {userAppSagas} from './userApp/userAppSagas'
import {categoriesSagas} from './categories/categoriesSagas'
import {productsSagas} from './products/productsSagas'


export default function* rootSaga(){
	yield all ([
			call(userSagas),
			call(userAppSagas),
			call(categoriesSagas),
			call(productsSagas),
		])
}