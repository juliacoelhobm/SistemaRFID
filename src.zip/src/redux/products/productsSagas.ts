import {put, takeLatest, all, call} from 'redux-saga/effects'
import {serverConfig} from '../../api/apiConfig';
import RfidApi from '../../api/rfidApi';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as base64 from 'base-64';
import {
  createProductFailure,
  createProductStart,
  deleteProductFailure,
  createProductSuccess,
  deleteProductStart,
  getAllProductsFailure,
  getAllProductsStart,
  updateProductFailure,
  updateProductStart,
  updateProductSuccess,
  getAllProductsSuccess,
  getLogsStart,
  getLogsSuccess,
  getLogsFailure,
  getProductsByCategoryStart,
  getProductsByCategorySuccess,
  getProductsByCategoryFailure,
} from './productsActions';
import productsTypes from './productsTypes';

export function* updateToken (renewToken: any) :Generator<object>{
  const rfidApi = new RfidApi(renewToken);
      const response:any = yield rfidApi.Fetch({
        method: 'post',
        url: `${serverConfig.pathUseCases.auth.authRefresh}`
      });

      if(response.data){
        yield AsyncStorage.setItem('AUTH_USER_TOKEN_KEY', response.data.token)		  
    	  yield AsyncStorage.setItem('AUTH_USER_RENEW_TOKEN_KEY', response.data.renewToken)		  
        return response.data.token
      }

}

export function* verifyToken (token: any){
  // Decodifica o token em arquivo json
  const decodeToken=()=> {
    const myToken = token
    if(! myToken ) {
      return null;
    }
    console.log('test token ===>>>', (base64.decode(myToken.split('.')[1])).toString('ascii'))
    return (base64.decode(myToken.split('.')[1])).toString('ascii');
  }

  const isExpired =(): boolean => {
    let tokenProps = decodeToken();
    if(typeof tokenProps == 'string')
      tokenProps = JSON.parse(tokenProps)
    console.log('myToken', tokenProps  )
    if(! tokenProps ) {
      return true;
    }
    const dtExpire = 1000 * tokenProps['exp'];
    console.log('dtExpire', tokenProps['exp'],dtExpire, + new Date());
    return ( (+ new Date() )> dtExpire ); 
  }

  const condicao = isExpired()

  return condicao

}

export function* createProductAsync({
  payload,
}: ReturnType<typeof createProductStart>) :Generator<object> {
  try {
    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    console.log('create product ===>>> ',payload)
    const identificacao = payload.identificacao[0]
    const rfidApiCheck = new RfidApi(token);
    
    const responseCheck:any = yield rfidApiCheck.Fetch({
      method: 'post',
      body : identificacao,
      url: `${serverConfig.pathUseCases.products.searchCode}`,
    });
    const produto_response = responseCheck?.data?.data
    console.log('responseCheck',produto_response)
    let finalResponse;
    const logToSend = {
      "tipo": payload.tipoTransacao,
      "quantidade": payload.quantidade,
      "localizacao": payload.localizacao,
      "codigo": identificacao

    }
    if(produto_response && produto_response.length){
      //UPDATE PRODUTO
      const rfidApi = new RfidApi(token);
      const qtdAtual = produto_response[0].quantidade
      const quantidade = payload.tipoTransacao == 'Entrada' ? payload.quantidade + qtdAtual : qtdAtual - payload.quantidade ;
      console.log('update quantidade ===> ', quantidade)
      const newData = {quantidade};
      console.log('logToSend update ===> ',logToSend)
      const rfidApiLog = new RfidApi(token);
      const responseLog:any = yield rfidApiLog.Fetch({
        method: 'post',
        body : logToSend,
        url: `${serverConfig.pathUseCases.products.movProd}`,
      });
      
      const finalResponseLog = responseLog.data;
      console.log('response.data log product',finalResponseLog);
      const response:any = yield rfidApi.Fetch({
        method: 'patch',
        body : newData,
        url: `${serverConfig.pathUseCases.products.updateProduto(produto_response[0]._id)}`,
      });
      
      finalResponse = response.data?.data
      
    } else{
      const rfidApi = new RfidApi(token);
      payload.quantidade = 0;
      const response:any = yield rfidApi.Fetch({
        method: 'post',
        body : payload,
        url: `${serverConfig.pathUseCases.products.createProdutos}`,
      });
      
      finalResponse = response.data.data

      console.log('logToSend update ===> ',logToSend)
      const rfidApiLog = new RfidApi(token);
      const responseLog:any = yield rfidApiLog.Fetch({
        method: 'post',
        body : logToSend,
        url: `${serverConfig.pathUseCases.products.movProd}`,
      });
      
      const finalResponseLog = responseLog.data;
      console.log('response.data log product',finalResponseLog);


    }
    
    
    console.log('response.data create/update product',finalResponse);
    
    yield put(createProductSuccess(finalResponse)); 
 
  } catch (error:any) {

    console.log('error',error)
    yield put(createProductFailure(error));
  }
}

export function* updateProductAsync({
  payload,
}: ReturnType<typeof updateProductStart>) :Generator<object> {
  try {
    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }


    const logToSend = {
      "tipo": payload.tipoTransacao,
      "quantidade": payload.qtdModify,
      "localizacao": payload.position,
      "codigo": payload.identificacao[0]
    }
    console.log('logToSend update ===>>> ',logToSend)
    
    const rfidApiLog = new RfidApi(token);
    const responseLog:any = yield rfidApiLog.Fetch({
      method: 'post',
      body : logToSend,
      url: `${serverConfig.pathUseCases.products.movProd}`,
    });
    
    const finalResponseLog = responseLog.data;
    console.log('response.data log product update',finalResponseLog);

    payload.tipoTransacao ? delete payload.tipoTransacao : ''
    payload.qtdModify ? delete payload.qtdModify : ''
    payload.localizacao ? delete payload.position : ''
    
    let finalResponse
    console.log('payload update',payload)
      //UPDATE PRODUTO
      const rfidApi = new RfidApi(token);
     
      const response:any = yield rfidApi.Fetch({
        method: 'patch',
        body : payload,
        url: `${serverConfig.pathUseCases.products.updateProduto(payload._id)}`,
      });
      
      finalResponse = response.data?.data
      
    yield put(updateProductSuccess(finalResponse)); 
  } catch (error) {
    yield put(updateProductFailure(error));
  }
}

export function* deleteProductAsync({
  payload,
}: ReturnType<typeof deleteProductStart>) {
  try {
   /*  const tokenCognito = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');

    const rfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'delete',
      body: {blubb: payload},
      url: `${serverConfig.pathUseCases.products.getAllProductsproducts.deleteProduct}`,
    });
    console.log('response : ', response);

    yield put(deleteProductFailure('erro')); */
  } catch (error) {
    yield put(deleteProductFailure('erro'));
  }
}
export function* getAllProductsAsync()  :Generator<object>{
  try {

    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    console.log('token getUserAsync',token)
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    const rfidApi = new RfidApi(token);
    const response:any = yield rfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.products.getProdutos}`,
    });

    console.log('getAllProductsSuccess  =====>>>>>>    ', response.data)
    yield put(getAllProductsSuccess(response.data.data));

  } catch (error) {
    yield put(getAllProductsFailure('erro'));
  }
}
export function* getProductsByCategoryAsync({
  payload,
}: ReturnType<typeof getProductsByCategoryStart>)  :Generator<object>{
  try {

    console.log('getProductsByCategory payload', payload)

    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    const rfidApi = new RfidApi(token);
    const response:any = yield rfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.products.getProductsByCategory(payload)}`,
    });

    console.log('getProductsByCategorySuccess  =====>>>>>>    ', response.data)
    yield put(getProductsByCategorySuccess(response.data.data));

  } catch (error) {
    yield put(getAllProductsFailure('erro'));
  }
}
export function* onGetLogsStartAsync({
  payload,
}: ReturnType<typeof getLogsStart>) :Generator<object> {

  try {

    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    console.log('token ',token)
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    const rfidApi = new RfidApi(token);
    const response:any = yield rfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.products.getLogs(payload)}`,
    });

    console.log('onGetLogsStartAsync  =====>>>>>>    ', response)
    yield put(getLogsSuccess(response.data.data));

  } catch (error) {
    yield put(getLogsFailure('erro'));
  }
}

export function* onCreateProductStart() {
  yield takeLatest(
    productsTypes.CREATE_PRODUCT_START,
    createProductAsync,
  );
}

export function* onUpdateProductStart() {
  yield takeLatest(
    productsTypes.UPDATE_PRODUCT_START,
    updateProductAsync,
  );
}

export function* onDeleteProductStart() {
  yield takeLatest(
    productsTypes.DELETE_PRODUCT_START,
    deleteProductAsync,
  );
}

export function* onGetAllProductStart() {
  yield takeLatest(
    productsTypes.GET_ALL_PRODUCT_START,
    getAllProductsAsync,
  );
}
export function* onGetProductsByCataegory() {
  yield takeLatest(
    productsTypes.GET_PRODUCTS_BY_CATEGORY_START,
    getProductsByCategoryAsync,
  );
}
export function* onGetLogsStart() {
  yield takeLatest(
    productsTypes.GET_LOGS_START,
    onGetLogsStartAsync,
  );
}

export function* productsSagas() {
  yield all([
    call(onCreateProductStart),
    call(onUpdateProductStart),
    call(onDeleteProductStart),
    call(onGetAllProductStart),
    call(onGetLogsStart),
    call(onGetProductsByCataegory),
  ]);
}
