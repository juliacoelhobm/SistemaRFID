import { AnyAction } from "redux";
import productsTypes  from "./productsTypes";

const productsInitialState = {
  products: [],
  logs: [],
  productsList: [],
  product:{},
  isLoadingProducts:false,
  mode: 'coleta', // inventario
  filterByCategory: false,
  productsByCategory: [],

};

const productsReducer = (state = productsInitialState, action: AnyAction) => {
  const { type, payload } = action;

  switch (type) {
    case productsTypes.SET_MODE:
        console.log('SET_MODE', payload)
      return {
        ...state,
        mode : payload,
      };
    case productsTypes.GET_PRODUCTS_BY_CATEGORY_START:
        console.log('GET_PRODUCTS_BY_CATEGORY', payload)
      return {
        ...state,
        isLoadingProducts : true,
      };
    case productsTypes.GET_PRODUCTS_BY_CATEGORY_SUCCESS:
        console.log('GET_PRODUCTS_BY_CATEGORY_Success', payload)
      return {
        ...state,
        isLoadingProducts : false,
        products: payload
      };
    case productsTypes.GET_PRODUCTS_BY_CATEGORY_FAILURE:
        console.log('GET_PRODUCTS_BY_CATEGORY', payload)
      return {
        ...state,
        isLoadingProducts : false,
      };
    case productsTypes.POST_PRODUCT_START:
        console.log('PRODUCT_START', payload)
      return {
        ...state,
        products : payload.barcodes,
        productsList : payload.barcodesData,
        isLoadingProducts : true,
      };
    case productsTypes.CREATE_PRODUCT_START:
        console.log('CREATE_PRODUCT_START', payload)
      return {
        ...state,
        isLoadingProducts : true,
      };
    case productsTypes.POST_SELECTED_PRODUCT_START:
        console.log('SELECTED_PRODUCT_START', payload)
      return {
        ...state,
        product : payload,
        isLoadingProducts : false,
      };
      case productsTypes.UPDATE_PRODUCT_START:
        console.log('UPDATE_PRODUCT_START', payload)
        return {
        ...state,
        product : payload,
        isLoadingProducts : true,
      };
      case productsTypes.UPDATE_PRODUCT_SUCCESS:
        console.log('UPDATE_PRODUCT_SUCCESS', payload)
        return {
        ...state,
        product : payload,
        isLoadingProducts : false,
      };
      case productsTypes.UPDATE_PRODUCT_FAILURE:
        console.log('UPDATE_PRODUCT_FAILURE', payload)
        return {
        ...state,
        
        isLoadingProducts : false,
      };
      case productsTypes.GET_ALL_PRODUCT_START:
        console.log('GET_ALL_PRODUCT_START', payload)
        return {
        ...state,  
        isLoadingProducts : true,
      };
      case productsTypes.GET_ALL_PRODUCT_SUCCESS:
        console.log('GET_ALL_PRODUCT_SUCCESS', payload)
        return {
        ...state,  
        products : payload,
        isLoadingProducts : false,
      };
      case productsTypes.GET_ALL_PRODUCT_FAILURE:
        console.log('GET_ALL_PRODUCT_FAILURE', payload)
        return {
        ...state,  
        isLoadingProducts : false,
      };
      case productsTypes.GET_LOGS_START:
        console.log('GET_LOGS_START', payload)
        return {
        ...state,  
        isLoadingProducts : true,
      };
      case productsTypes.GET_LOGS_SUCCESS:
        console.log('GET_LOGS_SUCCESS', payload)
        return {
        ...state,  
        logs : payload,
        isLoadingProducts : false,
      };
      case productsTypes.GET_LOGS_FAILURE:
        console.log('GET_LOGS_FAILURE', payload)
        return {
        ...state,  
        isLoadingProducts : false,
      };
    case productsTypes.POST_PRODUCT_SUCCESS:
        console.log('PRODUCT_SUCCESS')
        return {
            ...state, isLoadingProduct: false
            // , userDataApi : payload, userData:payload
        }
    case productsTypes.CREATE_PRODUCT_SUCCESS:
        console.log('CREATE_PRODUCT_SUCCESS')
        return {
            ...state, isLoadingProduct: false
            // , userDataApi : payload, userData:payload
        }
    default:
      return state;
  }
};

export default productsReducer;