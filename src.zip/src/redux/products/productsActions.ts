import productsTypes  from "./productsTypes";

export const createProductFailure=(data: any)=>({
  type: productsTypes.POST_PRODUCT_START,
  payload : data
});
export const  createProductStart =(data: any)=>({
  type: productsTypes.CREATE_PRODUCT_START,
  payload : data
});
export const  deleteProductFailure=(data: any)=>({
  type: productsTypes.POST_PRODUCT_START,
  payload : data
});
export const  createProductSuccess=(data: any)=>({
  type: productsTypes.CREATE_PRODUCT_SUCCESS,
  payload : data
});
export const  deleteProductStart=(data: any)=>({
  type: productsTypes.DELETE_PRODUCT_START,
  payload : data
});
export const  getLogsFailure=(data: any)=>({
  type: productsTypes.GET_LOGS_FAILURE,
  payload : data
});
export const  getLogsStart=(data: any)=>({
  type: productsTypes.GET_LOGS_START,
  payload : data
});
export const getLogsSuccess = (data:any) => ({
  type: productsTypes.GET_LOGS_SUCCESS,
  payload : data
});

export const  getAllProductsFailure=(data: any)=>({
  type: productsTypes.GET_ALL_PRODUCT_FAILURE,
  payload : data
});
export const  getAllProductsStart=()=>({
  type: productsTypes.GET_ALL_PRODUCT_START,
  
});
export const setMode = (data:any) => ({
  type: productsTypes.SET_MODE,
  payload : data
});
export const getAllProductsSuccess = (data:any) => ({
  type: productsTypes.GET_ALL_PRODUCT_SUCCESS,
  payload : data
});
export const getProductsByCategoryStart = (data:any) => ({
  type: productsTypes.GET_PRODUCTS_BY_CATEGORY_START,
  payload : data
});
export const getProductsByCategorySuccess = (data:any) => ({
  type: productsTypes.GET_PRODUCTS_BY_CATEGORY_SUCCESS,
  payload : data
});
export const getProductsByCategoryFailure = (data:any) => ({
  type: productsTypes.GET_PRODUCTS_BY_CATEGORY_FAILURE,
  payload : data
});

export const  updateProductFailure=(data: any)=>({
  type: productsTypes.POST_PRODUCT_START,
  payload : data
});
export const  updateProductStart=(data: any)=>({
  type: productsTypes.UPDATE_PRODUCT_START,
  payload: data,
});
export const  updateProductSuccess=(data: any)=>({
  type: productsTypes.UPDATE_PRODUCT_SUCCESS,
  payload: data,
});



export const postProductStart = (data : {barcodes:any, barcodesData:any}) => ({
    type: productsTypes.POST_PRODUCT_START,
    payload: data,
  });
export const postSelectedProductStart = (product:any) => ({
    type: productsTypes.POST_SELECTED_PRODUCT_START,
    payload: product,
  });
  export const postProductSuccess = () => ({
    type: productsTypes.POST_PRODUCT_SUCCESS,
  });
