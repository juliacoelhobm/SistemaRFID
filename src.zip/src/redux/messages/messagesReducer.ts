import { AnyAction } from "redux";
import { messagesTypes } from "./messagesTypes";

type globalTypes = {
  message: string | null;
  variantMessage: string | null;
};

const messagesInitialState: globalTypes = {
  message: null,
  variantMessage: null,
};

const messagesReducer = (state = messagesInitialState, action: AnyAction) => {
  const { type, payload } = action;

  switch (type) {
    case messagesTypes.PUT_MESSAGE:
      return {
        ...state,
        message: payload.message,
        variantMessage: payload.variant,
      };
    case messagesTypes.RESET_MESSAGES_REDUCER:
      return messagesInitialState;
    default:
      return state;
  }
};

export default messagesReducer;