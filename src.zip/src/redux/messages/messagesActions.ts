import { messagesTypes } from "./messagesTypes";

export const putMessage = (message: string, variant: string) => ({
  type: messagesTypes.PUT_MESSAGE,
  payload: { message, variant },
});

export const resetMessagesReducer = () => ({
  type: messagesTypes.RESET_MESSAGES_REDUCER,
});