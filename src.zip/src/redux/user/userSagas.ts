import {put, takeLatest, all, call} from 'redux-saga/effects'
import { useNavigation } from "@react-navigation/core";
import userActionTypes from './userTypes'
import {serverConfig} from '../../api/apiConfig';
import RfidApi from '../../api/rfidApi';
import axios from 'axios'
import * as base64 from 'base-64';

import AuthInterface from './../../lib/AuthInterface'

import {logoutSuccess, logoutFailure,loginSuccess,loggedSuccess, loginSuccessApi, loginFailure, loginFailureApi, signUpConfirmationStart, signUpUserCreated, signUpSuccess, signUpConfirmationFailure, signUpStartApi, signUpSuccessApi} from './userActions'
import {getUserStart} from './../userApp/userAppActions'
import { StackNavigationProp } from "@react-navigation/stack";
import { SignUpStackParamList } from "../../navigation/SignUpNavigation";
import AsyncStorage from '@react-native-async-storage/async-storage';

import {putMessage} from './../messages/messagesActions'


type signUpAsyncScreenProp = StackNavigationProp<
  SignUpStackParamList,
  "SignUpConfirmEmail"
>;
export function* signUpApiAsync(action){
	console.log("action signUpApiAsync", action);
	
	const {email,password,name,birthdate} = action.payload;
	const type = 'User'
	const categories = [];
	const tokenCognito = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY')
	console.log("tokenCognito ==>>" , tokenCognito)
	console.log("Token ==>>" , tokenCognito)
	try{
		const RfidApi = new RfidApi(null);
	    const data = {user : { name, email, password, birthdate, categories  }}
	    console.log("data api", data);
	    const response = yield RfidApi.Fetch({
	      method: 'post',
	      body:data,
	      url: `user`,
	    });
	    console.log("response api", response);
	    if(!response.data){
	    	        
	    	          yield put(putMessage("Falha ao criar usuário", 'error'))
	    	          return
	    }
	    const userData =  response.data.user;
	    console.log("response userData", userData);
	    // console.log('userJson', userJson);
	    yield put(signUpUserCreated(userData)) 
	 	// yield put(signUpSuccessApi(userData)) 

	}catch(error){
		console.log("error signUpApiAsync ", error)

	}
    
}
export function* signUpAsync(action){
	let cognitoData = {}
	// const navigation = useNavigation();
	try{
		const {email,password,name} = action.payload;
		const authInterface = new AuthInterface();
		cognitoData =  yield authInterface.signUp(email,password,name);
		console.log('retorno cognito signUpAsync ====>>> ', cognitoData)
		// if(cognito && cognito.signUpConfirmationAsync && !cognito.userConfirmed){
			// navigation.navigate("SignUpConfirmEmail")
		// }
		// return cognito;
		yield put(signUpUserCreated(cognitoData)) 
	} catch(error){
		// yield put(signUpConfirmationStart(cognitoData)) 
		cognitoData = error;
		// return error;
	}

	console.log('signUpAsync ==> ', cognitoData);

	// yield put(signUpConfirmationStart(cognitoData)) 
	
}
export function* signUpConfirmationAsync(action){
	let cognitoResponse
	try{
		const {email, code} = action.payload;
		const authInterface = new AuthInterface();
		cognitoResponse =  yield authInterface.signUpConfirmation(email,code);
		console.log('retorno cognito ====>>> ', cognitoResponse)
		// if(cognito && cognito.signUpConfirmationAsync && !cognito.userConfirmed){
			// navigation.navigate("SignUpConfirmEmail")
		// }
		// return cognito;
		yield put(signUpSuccess(cognitoResponse)) 
	} catch(error){
		yield put(signUpConfirmationFailure(error.message)) 

		// return error;
	}


	
	
}

export function* logoutAsync(action){
	try{
		// Auth.signOut({ global: true })}
		const authInterface = new AuthInterface();
		const userCognito:any =  yield authInterface.signOut();

		console.log('userCognito logout', userCognito)

		yield put(logoutSuccess()) 

	}catch(error){
		yield put(logoutFailure(error.message)) 
	}

}
export function* loginAsync(action: { payload: { email: any; password: any; }; }):Generator<object>{
	try{
		// const result = yield axios({url:url.login, method:'post', data:action.payload})
		// if(!result.data.user){
		// 	return yield put(loginFailure(result.data.message)) 
		// }
		const {email,password} = action.payload
		const type = 'User'
		const name = email.split("@")[0];
		
		const authInterface = new AuthInterface();
		/* console.log('action loginAsync email' , email);
		console.log('action loginAsync password' , password); */
		//const dataApi:any =  yield authInterface.signIn(email,password);
		let dataApi:any ;

		try{
			const rfidApi = new RfidApi(null);
			const data = {email, password }
			console.log("data api ==>>>", rfidApi);
			
			const response:any = yield rfidApi.Fetch({
				method: 'post',
			  	body:data,
			  	url: `auth/login`,
			});
			console.log("response api =====>>>", response.data);
			
		const jwtToken = response.data?.token;
		const renewToken = response.data?.renewToken;

		console.log('renewToken ========>>>>>>> ',renewToken)
		//const jsonValue = yield JSON.stringify(jwtToken);
		//console.log("jsonValue" , jsonValue);
    	const result = yield AsyncStorage.setItem('AUTH_USER_TOKEN_KEY', jwtToken)		  
    	const resultRenewToken = yield AsyncStorage.setItem('AUTH_USER_RENEW_TOKEN_KEY', renewToken)		  
    	const getResult = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY')		  
    	console.log("getResult token ======= > ", getResult)
    	
		yield put(loginSuccess(response.data)) 
			//yield put(signUpUserCreated(userData)) 
			 // yield put(signUpSuccessApi(userData)) 
	
		}catch(error){
			console.log("error loginAsync ", error)
	
		}




	}catch(error:any){
		yield put(loginFailure(error.message)) 
	}
}
export function* resendPasswordAsync(action){
	console.log(' ===>', action)
	const _onResend = async (): Promise<void> => {
    try {
      const {email} = action
      await Auth.resendSignUp(email);
    } catch (err) {
      console.log('error resend')
    }
  };
	// yield put(signUpStartApi(action.payload)) 
	yield put(getUserStart()) 
}
export function* loginSuccessAsync(action?: any){
	console.log('loginSuccessAsync ===>', action);
	// const userId = action.payload.userId
	// yield put(signUpStartApi(action.payload)) 
	yield put(putMessage("Usuário logado com sucesso", 'success'));
}
// export function* loggedSuccessAsync(action?){
// 	console.log('loggedSuccessAsync ===>', action)
// 	// const userId = action.payload.userId
// 	// yield put(signUpStartApi(action.payload)) 
// 	// yield put(getUserStart()) 
// }

function* getUser  (){
	console.log('call getUserStart')
	yield put(getUserStart()) 
}
export function* loggedSuccessStartAsync(action?){
	console.log('loginSuccessAsync ===>', action)
	// const userId = action.payload.userId
	// yield put(signUpStartApi(action.payload)) 
	// setTimeout(getUser,200)
	yield put(loggedSuccess()) 
}
export function* onLogin(){
	//yield takeLatest(userActionTypes.LOGIN_START, loginAsync)
}
export function* onLoginSuccess(){
	yield takeLatest(userActionTypes.LOGIN_SUCCESS, loginSuccessAsync)
}
export function* onLoggedSuccessStart(){
		console.log('onloggedSuccess')

	yield takeLatest(userActionTypes.LOGGED_SUCCESS_START, loggedSuccessStartAsync)
}
// export function* onLoggedSuccess(){
// 		console.log('onloggedSuccess')

// 	yield takeLatest(userActionTypes.LOGIN_SUCCESS, loggedSuccessAsync)
// }
export function* onLogout(){
	yield takeLatest(userActionTypes.LOGOUT, logoutAsync)
}
export function* onSignUpStart(){

	return yield takeLatest(userActionTypes.SIGNUP_START, signUpAsync)
}
export function* onLoginStart():any{

	return yield takeLatest(userActionTypes.LOGIN_START, loginAsync)
}
export function* onSignUpStartApi(){
	return yield takeLatest(userActionTypes.SIGNUP_START_API, signUpApiAsync)
}
export function* onSignUpConfirmationStart(){
	yield takeLatest(userActionTypes.SIGNUP_CONFIRMATION_START, signUpConfirmationAsync)
}
export function* onResendPassword(){
	yield takeLatest(userActionTypes.RESEND_PASSWORD, resendPasswordAsync)
}
export function* userSagas(){
	yield all([call(onLogin),call(onLoginStart),call(onLoginSuccess),call(onLoggedSuccessStart),call(onLogout),call(onSignUpStart),call(onSignUpConfirmationStart),call(onSignUpStartApi)])
}