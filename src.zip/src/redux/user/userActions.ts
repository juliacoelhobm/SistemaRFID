import userActionTypes from './userTypes';
export const loginStart = (credentials: { email: string; password: string; }) => ({
  type: userActionTypes.LOGIN_START,
  payload: credentials,
});
export const loggedSuccess = () => ({
  type: userActionTypes.LOGGED_SUCCESS,
});
export const loggedSuccessStart = () => ({
  type: userActionTypes.LOGGED_SUCCESS_START,
});
export const resendPassword = (credentials: any) => ({
  type: userActionTypes.RESEND_PASSWORD,
  payload: credentials,
});
export const loginStartApi = (credentials: any) => ({
  type: userActionTypes.LOGIN_START_API,
  payload: credentials,
});
export const signUpStart = (credentials: any) => ({
  type: userActionTypes.SIGNUP_START,
  payload: credentials,
});
export const signUpStartApi = (credentials: { email: string; password: string; birthdate: string; name: string; }) => ({
  type: userActionTypes.SIGNUP_START_API,
  payload: credentials,
});
export const signUpConfirmationStart = code => ({
  type: userActionTypes.SIGNUP_CONFIRMATION_START,
  payload: code,
});
export const signUpUserCreated = cognitoData => ({
  type: userActionTypes.SIGNUP_USER_CREATED,
  payload: cognitoData,
});
export const signUpUserCreatedApi = cognitoData => ({
  type: userActionTypes.SIGNUP_USER_CREATED_API,
  payload: cognitoData,
});
export const loginSuccess = (userData: { email: any; password: any; }) => ({
  type: userActionTypes.LOGIN_SUCCESS,
  payload: userData,
});
export const loginSuccessApi = userData => ({
  type: userActionTypes.LOGIN_SUCCESS_API,
  payload: userData,
});
export const signUpSuccess = userData => ({
  type: userActionTypes.SIGNUP_SUCCESS,
  payload: userData,
});
export const signUpSuccessApi = userData => ({
  type: userActionTypes.SIGNUP_SUCCESS_API,
  payload: userData,
});
export const signUpConfirmationFailure = error => ({
  type: userActionTypes.SIGNUP_CONFIRMATION_FAILURE,
  payload: error,
});

export const loginFailure = error => ({
  type: userActionTypes.LOGIN_FAILURE,
  payload: error,
});
export const loginFailureApi = error => ({
  type: userActionTypes.LOGIN_FAILURE_API,
  payload: error,
});
export const logoutFailure = error => ({
  type: userActionTypes.LOGOUT_FAILURE,
  payload: error,
});
export const logout = () => ({
  type: userActionTypes.LOGOUT,
  payload: {},
});
export const logoutSuccess = () => ({
  type: userActionTypes.LOGOUT_SUCCESS,
  payload: {},
});
