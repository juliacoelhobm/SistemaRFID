import userActionTypes from './userTypes'
const initialState = {
	userData : {}	,
	userDataApi : {}	,
	isLoading : false,
	isLogged : false,
	isConfirmedUser : false,
	isValidUser : false,
	isValidUserApi : false,
	errorMessage : null,
	cognitoData : {},
	token : '',
	categories : [],
	resendPassword: false
}
const userReducer = (state=initialState, action: { type: any; payload: any } )=>{
	const {type, payload} = action
	switch (type){
		case userActionTypes.SET_CURRENT_USER : 
			return {
				...state, errorMessage:null, currentUser:payload
			}
		case userActionTypes.LOGGED_SUCCESS : 
			console.log('LOGGED_SUCCESS')
			return {
				...state, isLogged:true, isLoading: false
				// , userDataApi : payload, userData:payload
			}
		case userActionTypes.LOGGED_SUCCESS_START : 
			console.log('LOGGED_SUCCESS_START')
			return {
				...state, isLoading: false
				// , userDataApi : payload, userData:payload
			}
		case userActionTypes.RESEND_PASSWORD : 
			return {
				...state, errorMessage:null, isLoading:true
			}
		case userActionTypes.LOGIN_START : 

			return {
				...state, errorMessage:null , isLoading : true
			}
		case userActionTypes.SIGNUP_CONFIRMATION_START : 

			return {
				...state, errorMessage:null , isLoading : true,
			}
		case userActionTypes.SIGNUP_CONFIRMATION_FAILURE : 

			return {
				...state, errorMessage:payload , isLoading : false,
			}
		case userActionTypes.SIGNUP_START : 

			return {
				...state, errorMessage:null , isLoading : true, userData : {name : payload.name , email : payload.email}
			}
		case userActionTypes.SIGNUP_START_API : 

			return {
				...state, errorMessage:null , isLoading : true, userData : {name : payload.name , email : payload.email}
			}
		case userActionTypes.SIGNUP_USER_CREATED : 

			return {
				...state, errorMessage:null , isLoading : false, userData : payload
			}
		case userActionTypes.SIGNUP_SUCCESS_API : 

			return {
				...state, errorMessage:null , isLoading : false, userDataApi : payload, isValidUserApi : true
			}
		case userActionTypes.SIGNUP_SUCCESS : 

			return {
				...state, errorMessage:null , isLoading : false, isConfirmedUser : true
			}
		
		case userActionTypes.LOGIN_SUCCESS : 
			console.log('LOGIN_SUCCESS ===>>> ',payload)
			return {
				...state, errorMessage:null,isConfirmedUser:true, isLoading:false, isLogged:true, token:payload.token
			}
		case userActionTypes.LOGOUT : 
			return {
				...state, errorMessage:null, isLoading:false, userData:{}, isLogged:false
			}	
		case userActionTypes.LOGOUT_SUCCESS : 

			return {
				...state, errorMessage:null, cognitoData:{} , isLoading : false, isConfirmedUser : false
			}
		case userActionTypes.LOGOUT_FAILURE : 

			return {
				...state, errorMessage:payload , isLoading : false, isConfirmedUser : false
			}
		case userActionTypes.LOGIN_FAILURE : 
			return {
				...state, errorMessage:payload,  isLoading:false
			}
		default : 
			return state
	}
}
export default userReducer