import {createStore, applyMiddleware} from 'redux'
import logger from 'redux-logger'
import {persistStore} from 'redux-persist'
import createSagaMiddleware from  'redux-saga'
import {persistedReducer} from './rootReducer'
import rootSaga from './rootSaga'

const sagaMiddleware = createSagaMiddleware()
const middlewares:any = [sagaMiddleware]
middlewares.push(logger)
const store = createStore(persistedReducer, applyMiddleware(...middlewares))
sagaMiddleware.run(rootSaga)
const persistor = persistStore(store)
export default {store, persistor}
