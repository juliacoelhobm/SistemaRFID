import {put, takeLatest, all, call} from 'redux-saga/effects'
import {serverConfig} from '../../api/apiConfig';
import RfidApi from '../../api/rfidApi';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as base64 from 'base-64';
import {
  createCategoryFailure,
  createCategoryStart,
  deleteCategoryFailure,
  createCategorySuccess,
  deleteCategoryStart,
  getAllCategoriesFailure,
  getAllCategoriesStart,
  updateCategoryFailure,
  updateCategoryStart,
  getAllCategoriesSuccess
} from './categoriesActions';
import categoriesActionTypes from './categoriesTypes';

export function* updateToken (renewToken: any) :Generator<object>{
  const rfidApi = new RfidApi(renewToken);
      const response:any = yield rfidApi.Fetch({
        method: 'post',
        url: `${serverConfig.pathUseCases.auth.authRefresh}`
      });

      if(response.data){
        yield AsyncStorage.setItem('AUTH_USER_TOKEN_KEY', response.data.token)		  
    	  yield AsyncStorage.setItem('AUTH_USER_RENEW_TOKEN_KEY', response.data.renewToken)		  
        return response.data.token
      }

}

export function* verifyToken (token: any){
  // Decodifica o token em arquivo json
  const decodeToken=()=> {
    const myToken = token
    if(! myToken ) {
      return null;
    }
    console.log('test token ===>>>', (base64.decode(myToken.split('.')[1])).toString('ascii'))
    return (base64.decode(myToken.split('.')[1])).toString('ascii');
  }

  const isExpired =(): boolean => {
    let tokenProps = decodeToken();
    if(typeof tokenProps == 'string')
      tokenProps = JSON.parse(tokenProps)
    console.log('myToken', tokenProps  )
    if(! tokenProps ) {
      return true;
    }
    const dtExpire = 1000 * tokenProps['exp'];
    console.log('dtExpire', tokenProps['exp'],dtExpire, + new Date());
    return ( (+ new Date() )> dtExpire ); 
  }

  const condicao = isExpired()

  return condicao

}

export function* createCategoryAsync({
  payload,
}: ReturnType<typeof createCategoryStart>) :Generator<object> {
  try {


    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    console.log('token getUserAsync',token)
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    const rfidApi = new RfidApi(token);
    const response:any = yield rfidApi.Fetch({
      method: 'post',
      body : payload,
      url: `${serverConfig.pathUseCases.categories.createCategory}`,
    });
    console.log('response.data create category',response.data)
    yield put(createCategorySuccess(response.data.data));


    /* 
    

    const rfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'post',
      body: {blubb: payload},
      url: `${serverConfig.pathUseCases.categories.getAllCategoriescategories.createCategory}`,
    });
    console.log('response : ', response);

    yield put(createCategorySuccess(response.data)); */
  } catch (error:any) {
    yield put(createCategoryFailure(error));
  }
}

export function* updateCategoryAsync({
  payload,
}: ReturnType<typeof updateCategoryStart>) {
  try {
    /* const tokenCognito = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');

    const rfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'patch',
      body: {blubb: payload},
      url: `${serverConfig.pathUseCases.categories.getAllCategoriescategories.updateCategory}`,
    });
    console.log('response : ', response);

    yield put(updateCategoryFailure('erro')); */
  } catch (error) {
    yield put(updateCategoryFailure('erro'));
  }
}

export function* deleteCategoryAsync({
  payload,
}: ReturnType<typeof deleteCategoryStart>) {
  try {
   /*  const tokenCognito = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');

    const rfidApi = new RfidApi(tokenCognito);
    const response = yield RfidApi.Fetch({
      method: 'delete',
      body: {blubb: payload},
      url: `${serverConfig.pathUseCases.categories.getAllCategoriescategories.deleteCategory}`,
    });
    console.log('response : ', response);

    yield put(deleteCategoryFailure('erro')); */
  } catch (error) {
    yield put(deleteCategoryFailure('erro'));
  }
}
export function* getAllCategoriesAsync()  :Generator<object>{
  try {
    //const tokenCognito = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');

    //const rfidApi = new RfidApi(tokenCognito);
   /*  const response = yield RfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.categories.getAllCategoriescategories.getAllCategories}`,
    });
    console.log('response categories: ', response.data.categories);

     */

    let token = yield AsyncStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken = yield AsyncStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    console.log('token getUserAsync',token)
    let vt = yield verifyToken(token);
    if(vt){
      token = yield updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    const rfidApi = new RfidApi(token);
    const response:any = yield rfidApi.Fetch({
      method: 'get',
      url: `${serverConfig.pathUseCases.categories.getAllCategories}`,
    });

    console.log('getAllCategoriesSuccess', response)

    yield put(getAllCategoriesSuccess(response.data.data));

  } catch (error) {
    yield put(getAllCategoriesFailure('erro'));
  }
}

export function* onCreateCategoryStart() {
  yield takeLatest(
    categoriesActionTypes.CREATE_CATEGORY_START,
    createCategoryAsync,
  );
}

export function* onUpdateCategoryStart() {
  yield takeLatest(
    categoriesActionTypes.UPDATE_CATEGORY_START,
    updateCategoryAsync,
  );
}

export function* onDeleteCategoryStart() {
  yield takeLatest(
    categoriesActionTypes.DELETE_CATEGORY_START,
    deleteCategoryAsync,
  );
}

export function* onGetAllCategoriesStart() {
  yield takeLatest(
    categoriesActionTypes.GET_ALL_CATEGORIES_START,
    getAllCategoriesAsync,
  );
}

export function* categoriesSagas() {
  yield all([
    call(onCreateCategoryStart),
    call(onUpdateCategoryStart),
    call(onDeleteCategoryStart),
    call(onGetAllCategoriesStart),
  ]);
}
