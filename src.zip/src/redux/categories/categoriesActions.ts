import {CategoriasDataApiType} from '../../@types/categorias/categorias';
import categoriesActionTypes from './categoriesTypes';

// CRIAR CATEGORIA

export const createCategoryStart = (category: CategoriasDataApiType) => ({
  type: categoriesActionTypes.CREATE_CATEGORY_START,
  payload: category,
});

export const createCategorySuccess = (successMessage: string) => ({
  type: categoriesActionTypes.CREATE_CATEGORY_SUCCESS,
  payload: successMessage,
});

export const createCategoryFailure = (error: string) => ({
  type: categoriesActionTypes.CREATE_CATEGORY_FAILURE,
  payload: error,
});

// LISTAR CATEGORIAS

export const getAllCategoriesStart = () => ({
  type: categoriesActionTypes.GET_ALL_CATEGORIES_START,
});

export const getAllCategoriesSuccess = (categories: CategoriasDataApiType[]) => ({
  type: categoriesActionTypes.GET_ALL_CATEGORIES_SUCCESS,
  payload: categories,
});

export const getAllCategoriesFailure = (error: string) => ({
  type: categoriesActionTypes.GET_ALL_CATEGORIES_FAILURE,
  payload: error,
});

// ATUALIZAR CATEGORIA

export const updateCategoryStart = (category: CategoriasDataApiType) => ({
  type: categoriesActionTypes.UPDATE_CATEGORY_START,
  payload: category,
});

export const updateCategorySuccess = (successMessage: string) => ({
  type: categoriesActionTypes.UPDATE_CATEGORY_SUCCESS,
  payload: successMessage,
});

export const updateCategoryFailure = (error: string) => ({
  type: categoriesActionTypes.UPDATE_CATEGORY_FAILURE,
  payload: error,
});

//DELETAR CATEGORIA

export const deleteCategoryStart = (category: CategoriasDataApiType) => ({
  type: categoriesActionTypes.DELETE_CATEGORY_START,
  payload: category,
});

export const deleteCategorySuccess = (successMessage: string) => ({
  type: categoriesActionTypes.DELETE_CATEGORY_SUCCESS,
  payload: successMessage,
});

export const deleteCategoryFailure = (error: string) => ({
  type: categoriesActionTypes.DELETE_CATEGORY_FAILURE,
  payload: error,
});
