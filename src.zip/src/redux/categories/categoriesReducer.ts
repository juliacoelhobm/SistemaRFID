import categoriesActionTypes from './categoriesTypes';
const initialState = {
  categories: [],
  isLoading: false,
  successMessage: null,
  errorMessage: null,
  selectedCaterory: {}
};
const categoriesReducer = (state = initialState, action: { type: any; payload: any; }) => {
  const {type, payload} = action;

  switch (type) {
    case categoriesActionTypes.CREATE_CATEGORY_START:
      return {
        ...state,
        isLoading: true,
      }
    case categoriesActionTypes.UPDATE_CATEGORY_START:
    case categoriesActionTypes.DELETE_CATEGORY_START:
    case categoriesActionTypes.GET_ALL_CATEGORIES_START:
      return {
        ...state,
        errorMessage: null,
        isLoading: true,
      };
    case categoriesActionTypes.CREATE_CATEGORY_FAILURE:
    case categoriesActionTypes.UPDATE_CATEGORY_FAILURE:
    case categoriesActionTypes.DELETE_CATEGORY_FAILURE:
    case categoriesActionTypes.GET_ALL_CATEGORIES_FAILURE:
      return {
        ...state,
        isLoading: false,
        errorMessage: payload,
      };
    case categoriesActionTypes.CREATE_CATEGORY_SUCCESS:
      console.log('CREATE_CATEGORY_SUCCESS payload',payload)
      return {
        ...state,
        isLoading: false,
        //categories: state.categories.push(payload),
      };
    case categoriesActionTypes.UPDATE_CATEGORY_SUCCESS:
      return{
        ...state,
        errorMessage: null,
        isLoading: false,
        successMessage: payload,
      }
    case categoriesActionTypes.DELETE_CATEGORY_SUCCESS:
    case categoriesActionTypes.GET_ALL_CATEGORIES_SUCCESS:
    console.log('payload GET_ALL_CATEGORIES_SUCCESS ===>', payload)
      return {
        ...state,
        errorMessage: null,
        isLoading: false,
        categories: payload,
      };

    default:
      return state;
  }
};
export default categoriesReducer;
