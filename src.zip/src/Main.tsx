import { StyleSheet, Text, View, ActivityIndicator } from 'react-native';
import {useEffect} from 'react'
import { useDispatch } from 'react-redux';
import React from 'react';
import { connect } from 'react-redux';
import {RootState} from './redux/rootReducer'
import WithSpinner from './components/with-spinner/WithSpinner'
// import Greetings from './views/greetings/Greetings'
import LoginNavigation from './navigation/loginNavigation/LoginNavigation'
import CategoriesNavigation from './navigation/categoriesNavigation/CategoriesNavigation'
import MainNavigation from './navigation/mainNavigation/MainNavigation'
import AuthNavigation from './navigation/authNavigation/AuthNavigation'
// import MainNavigation from './navigation/mainNavigation/MainNavigation'

export interface mainProps{
  userData : any,
  isLoading : boolean,
  isLogged : boolean,
  userToken : string,
  isConfirmedUser : boolean

}

const Main = ({userData, isLoading, isLogged, userToken, isConfirmedUser }:mainProps)=>{
	  // useEffect(()=>{
	  //   dispatch (loginStart(credentials))
	  // },[])
    // console.log('userData ===>>> ', userData)
    // const signIn = async (user) => {
      
    //     userToken = user.signInUserSession.accessToken.jwtToken
    // }
    // console.log("Main ========> " , haveCategories)
  	return (
  		<View style={{ flex: 1}}>
            {
              isLogged ?  <MainNavigation />: <LoginNavigation isLogged={isLogged}  /> 
            }
      </View>
  		)
  }
const mapStateToProps = (state : RootState)=>(
  {
    userData: state.user.userData ,
    isLoading: state.user.isLoading ,
    isLogged : state.user.isLogged,
    isConfirmedUser : state.user.isConfirmedUser,
    userToken : state.user.userToken,
    haveCategories : state.userApp.haveCategories,
  }
)

export default connect(mapStateToProps)(Main)



