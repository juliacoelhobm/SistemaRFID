// import from 'aws-amplify';
import authValidator from './../validation/authValidator'
import { Linking } from 'expo';
import * as WebBrowser from 'expo-web-browser';

class AuthInterface{

	constructor(){


	}

	async signUpFacebook (){

	}
	async signUpGoogle (){

	}
  async signOut (){
    return console.log('call signOut')
   /*  return await Auth.signOut(); */
  }

	async signIn (username, password){
			console.log(username, password)
			/* return await Auth.signIn(username, password); */
	}

	async signUpConfirmation ( username, confirmationCode) {
		try{
			
		
		} catch(error){
		
		}

	}
	async signUp (email, password, name, age?) {
    	console.log('signUp AuthInterface' , email, password, name, age);
      // setInvalidMessage(null);
      try{

      	const AuthValidator = new authValidator();
      	const auth = AuthValidator.validatePassword(password);
      	if(!auth.status){
      		console.log("entrou no throw do authInterface", auth.message)
      		throw Error (auth.message);
      	}
      const data ={};
	   /* await Auth.signUp({
        username: email,
        password,
        attributes: {
          email, // optional
          name,
        },
        validationData: [], // optional
      }) */
	   console.log('data final Auth cognito ====>>> ' , data);
      return data
       
   }catch(e){
   	console.log('error ===>>> ', e)
   	return e
      // setInvalidMessage('Password must be equal and have greater lenght than 6.');
   }
    }
  };


export default AuthInterface;