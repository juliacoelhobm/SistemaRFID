import validator from 'validator'
class authValidator {
	validateEmail(email){
		return validator.isEmail(email) ? {status:true} : {status:false,message:'Senha precisa ter no mínimo 8 caracteres'};
	}
	validatePassword(password){
		let message = '';
		try{
			if(!validator.isLength(password,{min:8,max:undefined})){
				message = 'Senha precisa ter no mínimo 8 caracteres'
			}if(validator.isLowercase(password)){
				message = 'Senha precisa ter pelo menos 1 caractere maiúsculo'
			}
			if(validator.isUppercase(password)){
				message = 'Senha precisa ter pelo menos 1 caractere minúsculo'
			}
		}catch(e){
			console.log('error validator: ' , e)
		}

		// isStrongPassword(str [, options])	
		// { minLength: 8, minLowercase: 1, minUppercase: 1, minNumbers: 1, minSymbols: 1, returnScore: false, pointsPerUnique: 1, pointsPerRepeat: 0.5, pointsForContainingLower: 10, pointsForContainingUpper: 10, pointsForContainingNumber: 10, pointsForContainingSymbol: 10 }
		// if(password.){
		// 	message = 'Senha precisa ter no mínimo 8 caracteres'
		// }
		console.log("message: ", message);
		return message ? {status:false, message}  : {status:true}

	}
}
export default authValidator;