export const serverConfig = {
  dev: {
    host: 'rfid',
    url: 'http://192.168.0.4:3000/',
    //url: 'http://200.146.196.137:3000/',
  }
  ,s3: {
    host: 's3',
    url: 'https://s3.amazonaws.com/rfid-backend-967497861764-us-east-1-media',
  },
  production: {
    host: 'rfid',
    url: 'https://api.rfid.com.br/',
  },
  pathUseCases: {
    auth: {
      authLogin: 'auth/login',
      authRefresh: 'auth/refresh',
    },
    sales: {salesPayment: 'sales/payments'},
    products: {
      createProdutos : 'produtos',
      insertCode : 'produtos/rfid/add', //POST Inserindo código de barras ao produto.
      updateCode: 'produtos/rfid/update',//POST Altera código de barras ao produto.
      deleteCode: 'produtos/rfid/remove',//POST Remove código de barras ao produto.
      searchCode: 'produtos/rfid/find',//POST Pesquisa o produto por codigo de barras.
      getProdutos: 'produtos',//GET Listar todos os produtos.
      findProduto: 'produtos/{id}',//GET Listar um produto pelo id.
      updateProduto:(produtoId: string) => `produtos/${produtoId}`, //PATCH Atualiza PRODUTO
      deleteProduto:(produtoId: string) => `produtos/${produtoId}`, //DELETE Exclui o produto.
      getLogs:(produtoId: string) => `movprod/${produtoId}`, //get logs do produto.
      getProductsByCategory:(produtoId: string) => `categorias/produtos/${produtoId}`, //get produto por categoria.
      movProd: 'movprod' //POST
    },
    categories: {
      getAllCategories: 'categorias',
      createCategory: 'categorias',
      updateCategory: (categoriaId: string) => `categorias/${categoriaId}`,
      deleteCategory: (categoriaId: string) => `categorias/${categoriaId}`,
    },
    
    userApp: {
      createNewUser: 'users',
      // updateUser: (userId: string) => `users/${userId}`,
      // deleteUser: (userId: string) => `users/${userId}`,
      // getUser: (userId) => `users/${userId}`,
      updateUser: 'user',
      deleteUser: 'user', 
      getUser: 'usuarios/who',
      // getAllUsers: 'users',
      followUser: `follow`,
      getAllFollowersFromUser: (userId: string) =>
        `users/${userId}/followers`,
      getAllMyFollowers: (userId: string) => `users/${userId}/following`,
    },
  },
};
