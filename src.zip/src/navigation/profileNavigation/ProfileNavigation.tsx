import {StyleSheet, Text, View,Image,TouchableOpacity} from 'react-native';
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import UserConfigNavigation from './../userConfigNavigation/UserConfigNavigation';
import Profile from './../../views/profile/Profile'
import {IconButton} from 'react-native-paper'

import IconSettings from './../../assets/png/icone_settings_65x60px.png';

type Props = {};

const ProfileStack = createNativeStackNavigator();

//icone_settings_65x60px
const ProfileNavigation = (props: Props) => {
  return (
    <ProfileStack.Navigator screenOptions={
    	{headerShown:true}}>
      <ProfileStack.Screen name="userProfile" options={{headerShown: true,header: (props) => (
    		<View style={{backgroundColor:'white'}}>
    			<TouchableOpacity onPress={()=>{
    				props.navigation.navigate('UserConfigNavigation')
    			}} style={{position:'absolute', top:5, margin:10, right:15,width:35,height:35}}>
	          		<Image resizeMode='contain' source={IconSettings} style={{position:'absolute',width:35,height:35}} />	
	          	</TouchableOpacity>
    			<IconButton
	            icon={'arrow-left'}
	            color={'#08153f'}
	            size={34}
	            onPress={() => props.navigation.goBack()}
	            style={{ margin: 10 }}
	          />

    		</View>)}}>
        {({navigation}) => <Profile />}
      </ProfileStack.Screen>
      <ProfileStack.Screen name="UserConfigNavigation" options={{headerShown: true, title:'Perfil do usuário'}} component={UserConfigNavigation} />

    </ProfileStack.Navigator>
  );
};

export default ProfileNavigation;

const styles = StyleSheet.create({});
