import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import Main from './../../../Main'
// import Greetings from './../../views/greetings/Greetings'

import MenuNavigation from '../menuNavigation/MenuNavigation'
const Stack = createNativeStackNavigator();
const MainNavigation = ()=>
	<Stack.Navigator screenOptions={{headerShown:false}}>
        <Stack.Screen name="Menu" component={MenuNavigation} />
        {
        	//aq vai as outras navegacoes do
        }
      </Stack.Navigator>
export default MainNavigation