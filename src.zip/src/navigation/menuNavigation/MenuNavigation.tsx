import React from 'react'
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {createDrawerNavigator} from '@react-navigation/drawer'
import { Badge, ListItem, Icon,Button } from '@rneui/themed'
import {
  Platform,
  Image,
  Text,
  TouchableHighlight,
} from 'react-native';

// import Main from './../../../Main'
// import Menu from './../../views/menu/Menu'
//import Map from './../../views/map/map'
import ProfileNavigation from './../profileNavigation/ProfileNavigation'
import BltConnect from './../../views/bltConnect/Connect'
import Camera from './../../views/camera/Camera'
import Categories from './../../views/categories/Categories'
import Qrcode from '../../views/qrcode/Qrcode'
import Products from '../../views/products/Products'
import Home from '../../views/home/Home'
import Logs from '../../views/logs/Logs'
import Transfer from '../../views/transfer/Transfer'
import ProductDetails from '../../views/productDetails/ProductDetails'
import ProductEdit from '../../views/productEdit/ProductEdit'
import ProductLocation from '../../views/productLocation/ProductLocation'
import Intro from '../../views/intro/Intro'
import Map from '../../views/map/Map'
import Greetings from './../../views/greetings/Greetings'
/* import SignIn from './../../views/authentication/SignIn'
import SignUp from './../../views/authentication/SignUp' */
import CustomDrawer from './../../components/customDrawer/CustomDrawer'

const Drawer = createDrawerNavigator()
const MenuNavigation = ()=>
	<Drawer.Navigator drawerContent={()=><CustomDrawer/>}>

        {/*<Drawer.Screen name="Blubb" initiaRouteName component={Map} />*/}
       
        
        <Drawer.Screen name="Home" component={Home} options={({ navigation }) => ({
          presentation: 'modal',
          headerShown:true,
          unmountOnBlur: true
        })}
        />
        <Drawer.Screen name="Intro" component={Intro} options={({ navigation }) => ({
          presentation: 'modal',
          headerShown:true,
          unmountOnBlur: true
        })}
        />
        <Drawer.Screen name="Categorias" component={Categories} options={({ navigation }) => ({
          presentation: 'modal',
          headerShown:true,
          unmountOnBlur: true
        })}
        listeners={({navigation}) => ({blur: () => navigation.setParams({screen: undefined})}) }
        />
        <Drawer.Screen name="Connect" component={BltConnect} options={({ navigation }) => ({
          presentation: 'modal',
          headerShown:true,
          unmountOnBlur: true
        })}
        listeners={({navigation}) => ({blur: () => navigation.setParams({screen: undefined})}) }
        />

        <Drawer.Screen name="Camera" component={Camera}
        	options={({ navigation }) => ({
	          presentation: 'modal',
	          headerShown:false,
	          unmountOnBlur: true
	        })}
         />

        <Drawer.Screen name="Logs" component={Logs}
        	options={({ navigation }) => ({
	          presentation: 'modal',
	          headerShown:true,
	          unmountOnBlur: true
	        })}
         />

        <Drawer.Screen name="Map" component={Map}
                  options={({ navigation }) => ({
                    presentation: 'modal',
                    title: 'Mapa de localização',
                    headerShown:true,
                    unmountOnBlur: true
                  })}
                />


        <Drawer.Screen name="Qrcode" component={Qrcode}
        	options={({ navigation }) => ({
	          presentation: 'modal',
	          headerShown:false,
	          unmountOnBlur: true
	        })}
         />
        <Drawer.Screen name="Products" component={Products}
        	options={({ navigation }) => ({
	          presentation: 'modal',
	          headerShown:true,
	          unmountOnBlur: true
	        })}
         />

        <Drawer.Screen name="ProductDetails" component={ProductDetails}
        	options={({ navigation }) => ({
	          presentation: 'modal',
            title: 'Detalhes do item',
	          headerShown:true,
	          unmountOnBlur: true,
            drawerType : 'slide',
            
            drawerIcon: (config) => (
              <Icon style={{
                alignSelf: "center",
                position: "absolute",
                right: 5,
              }}
                size={23}
                name={ 'edit'}>

                </Icon>)
           
	        })}
         />

        <Drawer.Screen name="ProductEdit" component={ProductEdit}
        	options={({ navigation }) => ({
	          presentation: 'modal',
            title: 'Editar item',
	          headerShown:true,
	          unmountOnBlur: true
	        })}
         />
        
       
        
        <Drawer.Screen name="Profile" component={ProfileNavigation}
        	options={({ navigation }) => ({
	          presentation: 'modal',
	          headerShown:false,
	          unmountOnBlur: true
	        })}
         />
        <Drawer.Screen name="Importar" component={Transfer}
        	options={({ navigation }) => ({
	          presentation: 'modal',
	          headerShown:false,
	          unmountOnBlur: true
	        })}
         />
        <Drawer.Screen name="Location" component={ProductLocation}
        	options={({ navigation }) => ({
	          presentation: 'modal',
	          headerShown:false,
	          unmountOnBlur: true
	        })}
         />
         
       {/*  <Drawer.Screen name="SignIn" component={SignIn} />
        <Drawer.Screen name="SignUp" component={SignUp} /> */}
    </Drawer.Navigator>
export default MenuNavigation