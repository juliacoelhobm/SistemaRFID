import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import WelcomeScreen from './../../views/authentication/Welcome';
import SignInScreen from './../../views/authentication/SignIn';
import SignUpScreen from './../../views/authentication/SignUp';
import ForgetPasswordScreen from './../../views/authentication/ForgetPassword';
import Confirmation from './../../views/authentication/Confirmation';

const AuthStack = createStackNavigator();
const AuthModalStack = createStackNavigator();

const AuthNavigation = ({ signIn }) => (
  <AuthModalStack.Navigator mode="modal" headerMode="none">
    <AuthModalStack.Screen name="AuthPages">
      {() => (
        <AuthStack.Navigator>
          <AuthStack.Screen options={{ headerShown: false }} name="Welcome" component={WelcomeScreen} />
          <AuthStack.Screen name="SignUp" component={SignUpScreen} />
          <AuthStack.Screen name="SignIn" initialRouteName="SignIn">
            {({ navigation }) => <SignInScreen signIn={signIn} navigation={navigation} />}
          </AuthStack.Screen>
          <AuthStack.Screen
            name="ForgetPassword"
            component={ForgetPasswordScreen}
          />
        </AuthStack.Navigator>
      )}
    </AuthModalStack.Screen>
    <AuthModalStack.Screen options={{ headerShown: false }} name="Confirmation" component={Confirmation} />
  </AuthModalStack.Navigator>
);

export default AuthNavigation;
