import React, { useState } from "react";
import { View, Text, StyleSheet } from "react-native";
// import { createStackNavigator } from "@react-navigation/stack";

import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useDispatch } from 'react-redux';

// import SignUp from "./../views/";
import SignUpEmail from "../../views/signUp/SignUpEmail";
import SignUpName from "../../views/signUp/SignUpName";
import SignUpPassword from "../../views/signUp/SignUpPassword";
import SignUpHowOld from "../../views/signUp/SignUpHowOld";
import SignUpConfirmEmail from "../../views/signUp/SignUpConfirmEmail";

import Greetings from "../../views/greetings/Greetings";
import {loginStart} from "../../redux/user/userActions";
import {signUpStart} from "../../redux/user/userActions";
import {signUpStartApi} from "../../redux/user/userActions";
import {signUpConfirmationStart} from "../../redux/user/userActions";

export type SignUpStackParamList = {
	SignUpName: undefined;
	SignUpEmail: undefined;
	SignUpPassword: undefined;
	SignUpHowOld: undefined;
};

const SignUpStack = createNativeStackNavigator<SignUpStackParamList>();

interface Props {}

const SignUpNavigation = (props: Props) => {
	const [email, setEmail] = useState("");
	const [name, setName] = useState("");
	const [password, setPassword] = useState("");
	const [birthdate, setBirthdate] = useState<string>("");
	const dispatch = useDispatch()
	// setName(email.split('@')[0]);
	const signUp = async () => {
		const credentials = {
			email,
			password,
			birthdate,
			name
		};
		console.log("função de sign up" ,credentials);

		return dispatch(signUpStartApi(credentials))
		// return dispatch(signUpStart(credentials))
	};
	const signUpConfirmation = () => {
		const credentials = {
			email,
			password,
			birthdate,
			name
		};
		// console.log("função de signUpConfirmation" ,credentials);

		dispatch(signUpConfirmationStart(credentials))
	};

	return (
		<SignUpStack.Navigator
			screenOptions={{
				headerTitle: "Criar conta",
				headerTitleAlign: "center",
				headerStyle: {
					elevation: 0,
					shadowOpacity: 0,
				},
			}}
		>
			<SignUpStack.Screen name="Greetings" initialRouteName="Greetings" 
			options={({ navigation }) => ({
          presentation: 'modal',
          headerShown: false, title:'Blubb',
          unmountOnBlur: true
        })}
        listeners={({navigation}) => ({blur: () => navigation.setParams({screen: undefined})}) }

			>
				{(props) => <Greetings navigation={props.navigation} />}
			</SignUpStack.Screen>
		
			<SignUpStack.Screen name="SignUpName" options={{ headerShown: true, title:'Entrar' }}>
				{/*{(props) => <SignUpName email={email} setEmail={setEmail} />}*/}
				{(props) => <SignUpName name={name} setName={setName} />}
			</SignUpStack.Screen>
			<SignUpStack.Screen name="SignUpEmail" options={{ headerShown: true, title:'Entrar' }}>
				{/*{(props) => <SignUpEmail email={email} setEmail={setEmail} />}*/}
				{(props) => <SignUpEmail email={email} setEmail={setEmail} />}
			</SignUpStack.Screen>
			<SignUpStack.Screen name="SignUpPassword" options={{ headerShown: true, title:'Entrar' }}>
				{() => <SignUpPassword password={password} setPassword={setPassword} />}
			</SignUpStack.Screen>
			<SignUpStack.Screen name="SignUpHowOld" options={{ headerShown: true , title : 'Entrar'}}>
				{() => <SignUpHowOld birthdate={birthdate} setBirthdate={setBirthdate} signUp={signUp} />}
			</SignUpStack.Screen>
			<SignUpStack.Screen name="SignUpConfirmEmail" options={{ headerShown: true , title:"Confirmação de E-mail"}}>
				{() => <SignUpConfirmEmail />}
			</SignUpStack.Screen>
			{/*<SignUpStack.Screen name="SignUpBlubbTopics" options={{ headerShown: true , title:"Preferências"}}>
				{() => <SignUpBlubbTopics />}
			</SignUpStack.Screen>*/}
		</SignUpStack.Navigator>
	);
};

export default SignUpNavigation;