import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import UserConfig from '../../views/userConfig/UserConfig';
import InviteFriends from '../../views/userConfig/InviteFriends';
import VirtualWallet from '../../views/userConfig/VirtualWallet';
import Account from '../../views/Account/Account';
import Notifications from '../../views/userConfig/Notifications';
import Privacy from '../../views/userConfig/Privacy';
import Security from '../../views/userConfig/Security';
import Adsense from '../../views/userConfig/Adsense';
import Help from '../../views/userConfig/Help';
import About from '../../views/userConfig/About';
import EditProfile from '../../views/userConfig/EditProfile';
import AccountNavigation from '../accountNavigation/AccountNavigation';

type Props = {};

const UserConfigStack = createNativeStackNavigator();

const UserConfigNavigation = (props: Props) => {
  return (
    <UserConfigStack.Navigator screenOptions={{headerShown: false}}>
      <UserConfigStack.Screen name="UserConfig">
        {({navigation}) => <UserConfig navigation={navigation} />}
      </UserConfigStack.Screen>
      <UserConfigStack.Screen name="EditProfile" component={EditProfile} />
      {/* <UserConfigStack.Screen name="InviteFriends" component={InviteFriends} />
      <UserConfigStack.Screen name="VirtualWallet" component={VirtualWallet} /> */}
      <UserConfigStack.Screen name="Account" component={Account} />
      <UserConfigStack.Screen name="Notifications" component={Notifications} />
      <UserConfigStack.Screen name="Privacy" component={Privacy} />
      <UserConfigStack.Screen name="Security" component={Security} />
      {/* <UserConfigStack.Screen name="Adsense" component={Adsense} /> */}
      <UserConfigStack.Screen name="Help" component={Help} />
      <UserConfigStack.Screen name="About" component={About} />
    </UserConfigStack.Navigator>
  );
};

export default UserConfigNavigation;

const styles = StyleSheet.create({});
