import React, { useState } from "react";
import { View, Text, StyleSheet } from "react-native";
// import { createStackNavigator } from "@react-navigation/stack";

import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useDispatch } from 'react-redux';

// import Categories from "./../views/";
import Categories from "../../views/categories/Categories";
import BlubbLanding from "../../views/blubbLanding/BlubbLanding";
import CategoriesContainer from "../../views/categories/CategoriesContainer";

import {signUpConfirmationStart} from "../../redux/user/userActions";


const CategoriesStack = createNativeStackNavigator();

interface Props {}

const CategoriesNavigation = (props: Props) => {
	
	const [age, setAge] = useState<string>("");
	const dispatch = useDispatch()
	

	return (
		<CategoriesStack.Navigator
			screenOptions={{
				headerTitle: "Criar conta",
				headerTitleAlign: "center",
				headerStyle: {
					elevation: 0,
					shadowOpacity: 0,
				},
			}}
		>
			<CategoriesStack.Screen name="blubbLanding" initiaRouteName component={BlubbLanding} 
				 options={({ navigation }) => ({
		          presentation: 'modal',
		          headerShown:false,
		          unmountOnBlur: true
		        })}
			/>

			<CategoriesStack.Screen name="Categories" options={({ navigation }) => ({
		          presentation: 'modal',
		          headerShown:false,
		          unmountOnBlur: true
		        })}
			>
				{/*{(props) => <CategoriesEmail email={email} setEmail={setEmail} />}*/}
				{(props) => <CategoriesContainer  />}
			</CategoriesStack.Screen>
			
			
		</CategoriesStack.Navigator>
	);
};

export default CategoriesNavigation;