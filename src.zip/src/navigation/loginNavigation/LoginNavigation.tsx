import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import Login from './../../views/login/Login'


import MainNavigation from './../../navigation/mainNavigation/MainNavigation';
import Login from './../../views/login/Login';
import ForgetPassword from './../../views/authentication/ForgetPassword';
import SignUpNavigation from './../signUpNavigation/SignUpNavigation';
import {RootState} from './../../redux/rootReducer'
import { Button, useTheme } from "react-native-paper";

const Stack = createNativeStackNavigator()
const LoginNavigation = ({ isLogged })=>{
	const {colors} = useTheme();
	return (
			  <Stack.Navigator>
		      {/*  <Stack.Screen name="Welcome" component={WelcomeScreen} />*/}
		        {/*<Stack.Screen options={{ headerShown: false }} name="SignIn"  initialRouteName="SignIn">
		        	{()=>isLogged ? <MainNavigation />: <SignUpNavigation/> }
		        </Stack.Screen>*/}
          		<Stack.Screen options={{ headerShown: false }}  name="SignUpNavigation" component={SignUpNavigation} initialRouteName="SignUpNavigation" />
          		<Stack.Screen name="SignIn" options={{ headerShadowVisible:false,  headerShown: true, title:'Entrar', headerTitleAlign: 'center',
          		 headerStyle: { backgroundColor: colors.background,fontWeight: 'bold'
          }, }}>
            		{({ navigation }) => <Login />}
          		</Stack.Screen>
	            <Stack.Screen
	             name="ForgetPassword"
	             component={ForgetPassword}
	            />
		      </Stack.Navigator>
		)
}

const mapStateToProps = (state:RootState)=>({
	isLogged : state.user.isLogged
})
export default LoginNavigation