import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import UserConfig from '../../views/userConfig/UserConfig';
import InviteFriends from '../../views/userConfig/InviteFriends';
import VirtualWallet from '../../views/userConfig/VirtualWallet';
import Account from '../../views/Account/Account';
import Notifications from '../../views/userConfig/Notifications';
import Privacy from '../../views/userConfig/Privacy';
import Security from '../../views/userConfig/Security';
import Adsense from '../../views/userConfig/Adsense';
import Help from '../../views/userConfig/Help';
import About from '../../views/userConfig/About';
import EditProfile from '../../views/userConfig/EditProfile';

type Props = {};

const AccountStack = createNativeStackNavigator();

const AccountNavigation = (props: Props) => {
  return (
    <AccountStack.Navigator
      screenOptions={{headerShown: false}}
      initialRouteName="Account">
      <AccountStack.Screen name="Account">
        {({navigation}) => <Account navigation={navigation} />}
      </AccountStack.Screen>
      <AccountStack.Screen name="PersonalInfo" component={EditProfile} />

      <AccountStack.Screen name="PaymentMethods" component={InviteFriends} />
      <AccountStack.Screen name="Activity" component={VirtualWallet} />
      <AccountStack.Screen name="AccountStatus" component={Account} />
      {/*<AccountStack.Screen name="Language" component={Notifications} />*/}
      <AccountStack.Screen name="DataUsage" component={Privacy} />
      <AccountStack.Screen name="Themes" component={Security} />
    </AccountStack.Navigator>
  );
};

export default AccountNavigation;

const styles = StyleSheet.create({});
