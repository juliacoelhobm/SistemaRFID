import React from 'react'
import {View, Text, StyleSheet} from 'react-native'
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import {useTheme} from 'react-native-paper'

interface btnSocialLoginInterface {
	Provider:string
	Icon:string
} 
const BtnSocialLogin = ({Provider, Icon}:btnSocialLoginInterface)=> {
	
	return (
<View style={styles.container}> 
<FontAwesome name={Icon} size={36} color='#c6c6c6' style={styles.icon} />
	
<Text style={styles.title}>
 Continuar com {Provider}
</Text> 
</View>)
}


export default BtnSocialLogin


const styles = StyleSheet.create({
	container : {
		flexDirection : 'row',
		justifyContent : 'flex-start',
		alignItems : 'center',
		width : '95%'
		, borderWidth: 1
		, borderColor : '#c6c6c6'
		, borderRadius : 32
		,marginVertical : 10
		,height : 50

	}
	,title : {
		color : '#c6c6c6',
		fontSize : 14,
		paddingLeft : 15
	}
	,icon:{
		paddingLeft : 15
	}
	
})