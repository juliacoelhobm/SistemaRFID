import React from 'react'
import {Drawer} from 'react-native-paper'
import {useDispatch} from 'react-redux'

import {useNavigation} from '@react-navigation/native'
import {logout} from './../../redux/user/userActions'


const CustomDrawer = () => {

	const navigation = useNavigation()
	const dispatch = useDispatch()
	const [active, setActive] = React.useState('');

	return(
		<Drawer.Section>
			<Drawer.Item label='Home' 
			active={active === 'Home'}
			
			onPress={()=>{navigation.navigate('Home'),setActive('Home')}} 
			
			/>
			<Drawer.Item label='Intro' 
			active={active === 'Intro'}
			
			onPress={()=>{navigation.navigate('Intro'),setActive('Intro')}} 
			
			/>
			<Drawer.Item label='Camera' 
			active={active === 'Camera'}
			
			onPress={()=>{navigation.navigate('Camera'),setActive('Camera')}} 
			
			/>
			
			<Drawer.Item label='Categorias' 
			active={active === 'Categorias'}
			
			onPress={()=>{navigation.navigate('Categorias'),setActive('Categorias')}} 
			
			/>
			<Drawer.Item label='Connect' 
			active={active === 'Connect'}
			
			onPress={()=>{navigation.navigate('Connect'),setActive('Connect')}} 
			
			/>
			<Drawer.Item label='Mapa' 
			active={active === 'Mapa'}
			
			onPress={()=>{navigation.navigate('Map'),setActive('Mapa')}} 
			
			/>
			<Drawer.Item label='Qrcode' 
			active={active === 'Qrcode'}
			
			onPress={()=>{navigation.navigate('Qrcode'),setActive('Qrcode')}} 
			
			/>
			<Drawer.Item label='Products' 
			active={active === 'Products'}			
			onPress={()=>{navigation.navigate('Products'),setActive('Products')}} 
			/>
			<Drawer.Item label='Location' 
			active={active === 'Location'}			
			onPress={()=>{navigation.navigate('Location'),setActive('Location')}} 
			/>
			{/*<Drawer.Item label='SignIn' onPress={()=>navigation.navigate('SignIn')} />*/}
		{/*{	<Drawer.Item label='SignUp' onPress={()=>navigation.navigate('SignUp')} />*/}
			<Drawer.Item label='Profile' onPress={()=>navigation.navigate('Profile')} />
			<Drawer.Item label='Importar' onPress={()=>navigation.navigate('Importar')} />
			<Drawer.Item label='Sair' onPress={()=>dispatch(logout())} />
		</ Drawer.Section>

		)

}
export default CustomDrawer
