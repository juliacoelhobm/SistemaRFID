import React from "react";
import {
	Image,
	StyleSheet,
	Text,
	TouchableHighlight,
	View,
} from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import { SvgUri, SvgCssUri } from "react-native-svg";
import GradientCircle from "./../../assets/svg/Bolha_selection_pink_380x380px";
import Adventure from "./../../assets/png/Adventure.png"

//import RingSvg from "../../assets/SVG/gradient_ring_copiar.svg";
interface CategoryProps {
	image?: string;
	subject?: string;
	selected?: boolean;
}

const Category = ({ image, subject, selected = false }: CategoryProps) => {
	console.log("selected", selected)
	return (
		<View
			style={styles.container}
			
		>
		<Text style={styles.subject}>{subject}</Text>
			<>
				{
					selected ? (
						<>
							
							<Image style={styles.image} source={require("./../../assets/png/Adventure.png")} />
							<Image style={styles.imageCapa}  source={require("./../../assets/png/bolha_selection_pink_380x380px.png")} />
							{/*<Image style={styles.image}  source={require("./../../assets/png/Adventure.png")} />*/}
							{/*<GradientCircle  width={100} height={100} fillOpacity={.8} />*/}
							

							
						</>
					) : <Image style={styles.image} source={require("./../../assets/png/Adventure.png")} />
					
				}

				
			</>
		</View>
	);
};

export default Category;
const styles = StyleSheet.create({
	container: {
		width: 100,
		height: 100,
		margin: 5,
		// borderRadius: 60,
		// elevation:10
	},
	
	imageCapa: {
		width: 100,
		height: 100,
		// elevation : 2
		
	},
	image: {
		width: 100,
		height: 100,
		borderWidth: 2,
		borderRadius: 60,
		// borderColor:'red',
		position : 'absolute'
	},
	subject: {
		position: "absolute",
		top: 45,
		flexWrap: "wrap",
		alignSelf: "center",
		color: "snow",
	},
});
