import React, { ReactNode } from "react";
import {
	StyleSheet,
	View,
	Dimensions,
	KeyboardAvoidingView,
} from "react-native";
import { FAB } from "react-native-paper";
import Modal from "react-native-modal";

interface Props {}

interface ModalWrapperProps {
	children: ReactNode;
	showModal: boolean;
	setShowModal: (bol: boolean) => void;
}

const ModalWrapper = ({
	children,
	showModal,
	setShowModal,
}: ModalWrapperProps) => {
	const { width, height } = Dimensions.get("window");
	return (
		<KeyboardAvoidingView behavior={"height"}>
			<Modal
				isVisible={showModal}
				onBackdropPress={() => setShowModal(false)}
				//onSwipeComplete={() => setShowModal(false)}
				//swipeDirection="left"
				useNativeDriver={true}
				animationIn="zoomInDown"
				animationInTiming={700}
				useNativeDriverForBackdrop={true}
				statusBarTranslucent={true}
			>
				<View style={[styles.modalContainer, { backgroundColor: "#ffff" }]}>
					<View style={[styles.modalContent]}>{children}</View>
					<FAB
						style={[
							styles.fab,
							{ right: width / 3, backgroundColor: "purple" },
						]}
						icon="close"
						onPress={() => setShowModal(false)}
					/>
				</View>
			</Modal>
		</KeyboardAvoidingView>
	);
};

export default ModalWrapper;
const styles = StyleSheet.create({
	modalContainer: {
		flex: 1,
		borderRadius: 32,
		justifyContent: "flex-start",
		alignItems: "center",
	},
	modalContent: {
		margin: 0,
	},
	fab: {
		position: "absolute",
		margin: 20,
		bottom: 0,
	},
});
