import { Platform, StyleSheet, Text, View } from "react-native";
import React, { useEffect, useRef } from "react";
import { connect, useDispatch } from "react-redux";
// import DropdownAlert from 'react-native-dropdownalert';
import { default as Container } from 'react-native-dropdownalert';
import { RootState } from "./../../redux/rootReducer";
import {resetMessagesReducer} from "./../../redux/messages/messagesActions"

type DropdownVariantTypes = "info" | "warn" | "error" | "success"

interface DropdownAlertComponentProps {
  message:string;
  variant: DropdownVariantTypes;
};

const DropdownAlertComponent = ({message,variant}: DropdownAlertComponentProps) => {
  const dispatch = useDispatch();
  let dropDownAlertRef : any = useRef(null);
  useEffect(() => {
    if(message && variant){
      // disparo do componente de mensagens
      console.log("variant",variant)
      dropDownAlertRef.alertWithType(variant,message);
    }
  },[message,variant]);

  return (
  		 <Container 
    closeInterval={2000} 
    tapToCloseEnabled={true}
    onClose = { ()  => dispatch(resetMessagesReducer())}
        onCancel = { ()  => dispatch(resetMessagesReducer())}
        ref={(ref) => {
          if (ref) {
            dropDownAlertRef = ref;
          }
        }}
        containerStyle={ Platform.OS === 'android' ? styles.contentAndroid : styles.contentIOS}
        titleNumOfLines={1}
        messageNumOfLines={0}
        isInteraction={false}
        zIndex={9999}
      />
  	)
};

const mapStateToToProps = (state : RootState) => ({
  message : state.messages.message,
  variant : state.messages.variantMessage
})


export default connect(mapStateToToProps)(DropdownAlertComponent);


const styles = StyleSheet.create({
  contentAndroid: {
    height: 50,
    backgroundColor: 'red',
    paddingLeft: 20,
    alignItems: 'center',
  },
  contentIOS: {
    backgroundColor: 'red',
    paddingLeft: 20,
    alignItems: 'center',
  },
});