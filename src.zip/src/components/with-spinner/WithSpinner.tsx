


import React from 'react'
import {ActivityIndicator, View} from 'react-native' 
import {Spinner} from './spinner'


const WithSpinner = (WrappedComponent:any)=>
	({ isLoading, ...otherProps}:any)=>
	     (isLoading ? <Spinner />: <WrappedComponent {...otherProps} />)
	
	
export default WithSpinner;
