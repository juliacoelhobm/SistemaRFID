export const TOOGLE_DRAWER = 'TOOGLE_DRAWER';

export const toggleDrawerStart =  ()=> {
    return ({ type: TOOGLE_DRAWER});
}