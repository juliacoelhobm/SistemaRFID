
import * as api from '../../api';
import RfidApi from '../../api/rfidApi';
import {serverConfig} from '../../api/apiConfig';
import * as base64 from 'base-64';
import axios from 'axios';
// Defina o tipo de ação
//
export const FETCH_EMPRESAS_SUCCESS = 'FETCH_EMPRESAS_SUCCESS';
export const FETCH_EMPRESA_BY_ID = 'FETCH_EMPRESA_BY_ID';
export const FETCH_EMPRESA_BY_ID_SUCCESS = 'FETCH_EMPRESA_BY_ID_SUCCESS';
export const CREATE_EMPRESA_SUCCESS = 'CREATE_EMPRESA_SUCCESS';
export const UPDATE_EMPRESA_SUCCESS = 'UPDATE_EMPRESA_SUCCESS';
export const UPDATE_EMPRESA_START = 'UPDATE_EMPRESA_START';
export const DELETE_EMPRESA = 'DELETE_EMPRESA';
export const GET_IMAGES_EMPRESA = 'GET_IMAGES_EMPRESA';
export const GET_IMAGES_EMPRESA_SUCCESS = 'GET_IMAGES_EMPRESA_SUCCESS';
export const GET_IMAGES_EMPRESA_FAILURE = 'GET_IMAGES_EMPRESA_FAILURE';
export const SET_IMAGE_EMPRESA_PROFILE_SUCCESS = 'SET_IMAGE_EMPRESA_PROFILE_SUCCESS';


export const updateToken = async (renewToken: any)=> {
  const rfidApi = new RfidApi(renewToken);
      const response:any = await rfidApi.Fetch({
        method: 'post',
        url: `${serverConfig.pathUseCases.auth.authRefresh}`
      });

      if(response.data){
        localStorage.setItem('AUTH_USER_TOKEN_KEY', response.data.token)		  
    	  localStorage.setItem('AUTH_USER_RENEW_TOKEN_KEY', response.data.renewToken)		  
        return response.data.token
      }

}

export function* verifyToken (token: any){
  // Decodifica o token em arquivo json
  const decodeToken=()=> {
    const myToken = token
    if(! myToken ) {
      return null;
    }
    console.log('test token ===>>>', (base64.decode(myToken.split('.')[1])).toString())
    return (base64.decode(myToken.split('.')[1])).toString();
  }

  const isExpired =(): boolean => {
    let tokenProps:any = decodeToken();
    if(typeof tokenProps == 'string')
      tokenProps = JSON.parse(tokenProps)
    console.log('myToken', tokenProps  )
    if(! tokenProps ) {
      return true;
    }
    const dtExpire = 1000 * tokenProps['exp'];
    console.log('dtExpire', tokenProps['exp'],dtExpire, + new Date());
    return ( (+ new Date() )> dtExpire ); 
  }

  const condicao = isExpired()

  return condicao

}

export const setImageEmpresaProfile = (image: any) => async (dispatch: (arg0: { type: string; payload: any; }) => void) => {
  //const produto = await api.getProdutoById(id);
  dispatch({ type: SET_IMAGE_EMPRESA_PROFILE_SUCCESS, payload : image });
}


export const getImagesByEmpresa = (payload: any) => async (dispatch: (arg0: { type: string; payload: any; }) => void) => {
  try {
    dispatch({ type: GET_IMAGES_EMPRESA, payload: null });
    let token:any =  localStorage.getItem('AUTH_USER_TOKEN_KEY');
    const renewToken =  localStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
    
    console.log('token getUserAsync',token)
    let vt = verifyToken(token);
    if(vt){
      token = await updateToken(renewToken)
      console.log('refreshToken ', token)
    }

    const params:any = {referencia : 'empresa' , idReferencia: payload}

    const rfidApi = new RfidApi(token);
    const response:any = await rfidApi.Fetch({
      method: 'post',
      body: params,
      url: `${serverConfig.pathUseCases.empresas.getImages}`,
    });

    console.log('getImagesByProductStart  =====>>>>>>    ', response.data)
    dispatch({ type: GET_IMAGES_EMPRESA_SUCCESS, payload: response.data.data });
    //await put(getImagesByProductSuccess(response.data.data));

  } catch (error) {
    dispatch({ type: GET_IMAGES_EMPRESA_FAILURE, payload: error });
  }
}



export const fetchEmpresas = () => async (dispatch: (arg0: { type: string; payload: any; }) => void) => {
  let token:any =  localStorage.getItem('AUTH_USER_TOKEN_KEY');
  console.log('fetchEmpresas token',token)
  const renewToken =  localStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
  let vt = verifyToken(token);
  if(vt){
    token = await updateToken(renewToken)
    console.log('refreshToken ', token)
  }
  const rfidApi = new RfidApi(token);
  const response: any = await rfidApi.Fetch({
    method: 'get',
    body: {},
    url: serverConfig.pathUseCases.empresas.getEmpresas,
  });
  console.log('response ==> ',response.data)
  dispatch({ type: FETCH_EMPRESAS_SUCCESS, payload: response.data.data });
}

export const deleteEmpresa = (empresaId:any) => async (dispatch: (arg0: { type: string; payload: any; }) => void) => {
  let token:any =  localStorage.getItem('AUTH_USER_TOKEN_KEY');

  console.log('deleteEmpresa token',token)
  const renewToken =  localStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
  
  let vt = verifyToken(token);
  if(vt){
    token = await updateToken(renewToken)
    console.log('refreshToken ', token)
  }
  
    const rfidApi = new RfidApi(token);


  //     const response: any = await rfidApi.Fetch({
  //       method: 'get',
  //       body: {},
  //       url: serverConfig.pathUseCases.empresas.getEmpresas,
  //     });
  // //const empresas = await api.getEmpresas();
  // console.log('response ==> ',response.data)
  // dispatch({ type: FETCH_EMPRESAS_SUCCESS, payload: response.data.data });
}

export const fetchEmpresaById = (id: any) => async (dispatch: (arg0: { type: string; payload: any; }) => void) => {
  dispatch({ type: FETCH_EMPRESA_BY_ID, payload: null });
  let token:any =  localStorage.getItem('AUTH_USER_TOKEN_KEY');
  console.log('fetchEmpresas token',token)
  const renewToken =  localStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
  let vt = verifyToken(token);
  if(vt){
    token = await updateToken(renewToken)
    console.log('refreshToken ', token)
  }
  
  const rfidApi = new RfidApi(token);
  const response: any = await rfidApi.Fetch({
    method: 'get',
    url: serverConfig.pathUseCases.empresas.getEmpresaById(id),
  });
  console.log('response get empresa ==> ',response)
  dispatch({ type: FETCH_EMPRESA_BY_ID_SUCCESS, payload: response.data.data });
}

export const createEmpresa = (empresa: any) => async (dispatch: (arg0: { type: string; payload: any; }) => void) => {
  
  let token:any =  localStorage.getItem('AUTH_USER_TOKEN_KEY');
  console.log('fetchEmpresas token',token)
  const renewToken =  localStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
  let vt = verifyToken(token);
  if(vt){
    token = await updateToken(renewToken)
    console.log('refreshToken ', token)
  }
  console.log('empresa',empresa)
  const rfidApi = new RfidApi(token);
  const response: any = await rfidApi.Fetch({
    method: 'post',
    body: empresa,
    url: serverConfig.pathUseCases.empresas.createEmpresa,
  });
  console.log('response create empresa ==> ',response)
  dispatch({ type: CREATE_EMPRESA_SUCCESS, payload: response.data.data });
}


export const uploadImage = async(data: any, file:any, token:any)=> {
  var axiosResponse
  const fileData = data;
  console.log('fileData init ===>>>>', fileData)
  console.log('fileData init ===>>>>', token)
    const config = {
        headers: {
          //Accept: '*/*',
          'Authorization':'Bearer ' + token,
          'Content-Type': 'multipart/form-data; charset=utf-8; boundary="another cool boundary";',
        }
    };
      const form = new FormData();
      //form.append('data', JSON.stringify(data));
       Object.keys(fileData).forEach((key) => {
        console.log(key)
          form.append(key, fileData[key]);
      }); 
    
    
      if(file && !file.type && file.uri){
        const list = file.uri.split('.')
        const len = list.length
        file['type'] = 'image/'+list[len-1]
      }
      if(!file.name)
        file['name'] = file.fileName;

      console.log("file.type",file)
      if(file && file.type){
        form.append("arquivo", file);
        //form.append('Content-Type',file.type)
        console.log('form 1 ====>> ',form)
        
          let endPoint = `${serverConfig.dev.url}${serverConfig.pathUseCases.produtos.uploadImage}`
          console.log('endPoint',endPoint)
          console.log('config',config)
          try {
            axiosResponse = await axios.request({
              url: endPoint,
              method: 'post',
              data: form,
              headers: config.headers
              // withCredentials: true,
            });
            
            
          } catch (error) {
            axiosResponse = error;
            console.log('error api : ', axiosResponse);
          }
          console.log('api response upload : ', axiosResponse);
      }
      return axiosResponse;
}




export const updateEmpresa = (empresa: any) => async (dispatch: (arg0: { type: string; payload: any; }) => void) => {
  dispatch({ type: UPDATE_EMPRESA_START, payload : null });
  let token:any =  localStorage.getItem('AUTH_USER_TOKEN_KEY');
  console.log('fetchEmpresas token',token)
  const renewToken =  localStorage.getItem('AUTH_USER_RENEW_TOKEN_KEY');
  let vt = verifyToken(token);
  if(vt){
    token = await updateToken(renewToken)
    console.log('refreshToken ', token)
  }
  console.log('empresa',empresa)


  if(empresa.file){
    console.log('has file *****************')
    const dataToSend = 
      {
        "referencia": "empresa",
        "idReferencia": empresa._id,
        "titulo": "imagem",
        "descricao": "profile_empresa",
        "contador": empresa.contador||1
      }

      delete empresa.contador
      //console.log('has file *****************', dataToSend )
      //console.log('has file *****************', empresa.file )
      try{
          const sendFile = await uploadImage(dataToSend, empresa.file, token);
      } catch(err){
        console.log('erro sendfile ===>>> ',err)

      }
      
    delete empresa.file
  }





  const rfidApi = new RfidApi(token);
  const response: any = await rfidApi.Fetch({
    method: 'patch',
    body: empresa,
    url: `${serverConfig.pathUseCases.empresas.updateEmpresa(empresa._id)}`,
    
  });
  console.log('response edit empresa ==> ',response)
  fetchEmpresas()
  dispatch({ type: UPDATE_EMPRESA_SUCCESS, payload : null });
}



// E assim por diante para as outras ações...
