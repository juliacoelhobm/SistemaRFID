import React from 'react';
import './Sidebar.css';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      {/* Conteúdo da barra lateral */}
    </aside>
  );
};

export default Sidebar;
