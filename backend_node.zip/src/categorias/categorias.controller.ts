import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UseGuards,
} from '@nestjs/common';
import { CategoriasService } from './categorias.service';
import { CreateCategoriaDto } from './dto/create-categoria.dto';
import { UpdateCategoriaDto } from './dto/update-categoria.dto';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { User } from 'src/shared/decorators/user.decorator';
import { UserEntity } from 'src/shared/entities/user.entity';

@Controller('categorias')
@ApiTags('CRUD de Categorias')
@UseInterceptors(new DataformInterceptor())
@UseGuards(AuthGuard('jwt'))
export class CategoriasController {
  constructor(private readonly categoriasService: CategoriasService) {}

  @Post()
  @ApiOperation({ summary: 'Inserindo categorias' })
  create(
    @Body() createCategoriaDto: CreateCategoriaDto,
    @User() user: UserEntity,
  ): Promise<CreateCategoriaDto> {
    createCategoriaDto.empresa = user.empresa;
    return this.categoriasService.create(createCategoriaDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar todas as categorias.' })
  @ApiResponse({ status: 200, description: 'Sucesso na consulta' })
  findAll(@User() user: UserEntity): Promise<any> {
    return this.categoriasService.findAll(user.empresa);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Listar uma categoria pelo id.' })
  findOne(@Param('id') id: string) {
    return this.categoriasService.findOne(id);
  }

  @Get('/produtos/:id')
  @ApiOperation({ summary: 'Listar produtos pertencentes a uma categoria.' })
  findProductOne(@Param('id') id: string, @User() user: UserEntity) {
    return this.categoriasService.findProductOne({
      categoria: id,
      empresa: user.empresa,
    });
  }

  @Get('/inventarios/:id')
  @ApiOperation({ summary: 'Listar inventarios pertencentes a uma categoria.' })
  findInventarios(@Param('id') id: string, @User() user: UserEntity) {
    return this.categoriasService.findInventarios({
      categoria: id,
      empresa: user.empresa,
    });
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualiza categoria' })
  async update(
    @Param('id') id: string,
    @Body() updateCategoriaDto: UpdateCategoriaDto,
  ) {
    return await this.categoriasService.update(id, updateCategoriaDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Exclui o registro mas mantem no banco de dados' })
  remove(@Param('id') id: string) {
    return this.categoriasService.remove(id);
  }
}
