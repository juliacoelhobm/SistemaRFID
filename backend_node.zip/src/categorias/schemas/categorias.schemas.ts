import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Empresas } from 'src/empresas/schemas/empresas.schema';
import { Usuarios } from 'src/usuarios/schemas/usuarios.schemas';

export type CategoriasDocument = Categorias & Document;

@Schema({ timestamps: true, collection: 'categorias' })
export class Categorias {
  @Prop({ type: Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: Types.ObjectId, ref: () => Usuarios })
  usuario: Usuarios;

  @Prop({ required: true })
  nome: string;
}

export const CategoriasSchema = SchemaFactory.createForClass(Categorias);
