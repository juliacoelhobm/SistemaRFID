import { Module } from '@nestjs/common';
import { CategoriasService } from './categorias.service';
import { CategoriasController } from './categorias.controller';
import { CategoriasSchema } from './schemas/categorias.schemas';
import { MongooseModule } from '@nestjs/mongoose';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { ProdutosModule } from 'src/produtos/produtos.module';
import { InventarioModule } from 'src/inventario/inventario.module';
import { UsuariosSchema, UsuariosDocument } from 'src/usuarios/schemas/usuarios.schemas';
import { UsuariosModule } from 'src/usuarios/usuarios.module';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Categorias', schema: CategoriasSchema },
      { name: 'Usuarios', schema: UsuariosSchema },
      { name: 'UsuariosDocument', schema: UsuariosSchema },
    ]),
    UsuariosModule,
    ProdutosModule,
    InventarioModule,
  ],
  controllers: [CategoriasController],
  providers: [CategoriasService, ToolsService],
  exports: [CategoriasService],
})
export class CategoriasModule {}
