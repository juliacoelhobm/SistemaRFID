import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEmail,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class CreateCategoriaDto {
  @ApiProperty({
    description: 'Nome da categoria',
    minLength: 5,
    maxLength: 255,
  })
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @MinLength(1, { message: ValidatorMessage.MinLength })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  nome: string;

  @ApiProperty()
  empresa: string;

  @ApiProperty()
  usuario: string;
}
