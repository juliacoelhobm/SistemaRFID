import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Categorias } from './schemas/categorias.schemas';
import { CreateCategoriaDto } from './dto/create-categoria.dto';
import { UpdateCategoriaDto } from './dto/update-categoria.dto';
import { ProdutosService } from 'src/produtos/produtos.service';
import { InventarioService } from 'src/inventario/inventario.service';
import { Usuarios, UsuariosDocument } from './../usuarios/schemas/usuarios.schemas';

@Injectable()
export class CategoriasService {
  constructor(
    @InjectModel(Usuarios.name) private usuariosModel: Model<UsuariosDocument>,
    @InjectModel('Categorias')
    private readonly categoriasModel: Model<Categorias>,
    private readonly produtosService: ProdutosService,
    private readonly inventarioService: InventarioService,
  ) {}

  async create(createCategoriaDto: CreateCategoriaDto): Promise<any> {
    try {
      const nome:any = await this.categoriasModel.findOne({ nome: createCategoriaDto.nome, empresa:createCategoriaDto.empresa });
      console.log('nome categoria',nome)
      if(nome){
        throw new Error("Nome da categoria já existe")
      }
      const created = new this.categoriasModel(createCategoriaDto);

      return await created.save();
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }
  }

  async findAll(empresa: string): Promise<any> {
    return await this.categoriasModel.find({ empresa }).populate('usuario','',this.usuariosModel).exec();
  }

  async findOne(id: string) {
    try {
      //.lean() para plain object
      return await this.categoriasModel.findById(id).exec();
    } catch {
      return null;
    }
  }

  async findProductOne({ categoria, empresa }) {
    try {
      return this.produtosService.findByCategory(empresa, categoria);
    } catch {
      return null;
    }
  }
  async findInventarios({ categoria, empresa }) {
    try {
      return this.inventarioService.findByCategory(empresa, categoria);
    } catch {
      return null;
    }
  }

  async update(id: string, updateCategoriaDto: UpdateCategoriaDto) {
    await this.categoriasModel
      .updateOne({ _id: id }, updateCategoriaDto)
      .exec();
    return await this.findOne(id);
  }

  async remove(id: string): Promise<any> {
    // throw new ForbiddenException('Não pode remover');
    return await this.categoriasModel.deleteOne({ _id: id }).exec();
  }
}
