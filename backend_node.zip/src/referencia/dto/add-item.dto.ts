import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';


import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class AddItem {
  @ApiProperty({
    name: 'referenciaId',
    description: 'id da referencia',
  })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  referenciaId: string;

  @ApiProperty({
    name: 'produtoId',
    description: 'id do produto',
  })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  produtoId: string;
}
