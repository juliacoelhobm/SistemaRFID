import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MaxLength, MinLength } from 'class-validator';

import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

class Identificacao {
  @ApiProperty({ type: String })
  tipo: string;
  @ApiProperty({ type: String })
  codigo: string;
}

export class CreateReferenciaDto {
  @ApiProperty({
    description: 'Nome da referencia',
    minLength: 3,
    maxLength: 255,
  })
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @MinLength(3, { message: ValidatorMessage.MinLength })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  nome: string;

  @ApiProperty()
  empresa: string;

  @ApiProperty()
  quantidade: number;

  @ApiProperty()
  minimo: number;

  /* @ApiProperty()
  categoria: string; */

  @ApiProperty()
  venda: number;

  @ApiProperty()
  compra: number;

 /*  @ApiProperty({
    description: 'Tipo do codigo e codigo.',
    isArray: true,
    type: Identificacao,
  })
  identificacao: Identificacao[]; */

  @ApiProperty()
  ativo: boolean;

  @ApiProperty()
  descricao: string;

  @ApiProperty()
  usuario: string;
}
