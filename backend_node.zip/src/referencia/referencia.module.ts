import { Module, forwardRef } from '@nestjs/common';
import { ReferenciaService } from './referencia.service';
import { ReferenciaController } from './referencia.controller';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { MongooseModule } from '@nestjs/mongoose';
import { ReferenciaSchema } from './schemas/referencia.schema';
import { UsuariosSchema, UsuariosDocument } from 'src/usuarios/schemas/usuarios.schemas';
import { ProdutosSchema, ProdutosDocument } from 'src/produtos/schemas/produtos.schema';
import { UsuariosModule } from 'src/usuarios/usuarios.module';
import { EmpresasModule } from 'src/empresas/empresas.module';
import { ProdutosModule } from 'src/produtos/produtos.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Referencia', schema: ReferenciaSchema },
      { name: 'Usuarios', schema: UsuariosSchema },
      { name: 'UsuariosDocument', schema: UsuariosSchema },
      { name: 'Produtos', schema: ProdutosSchema },
      { name: 'ProdutosDocument', schema: ProdutosSchema }
    ]),
    UsuariosModule,
    EmpresasModule,
    //ProdutosModule,
    forwardRef(() => ProdutosModule)
  ],
  controllers: [ReferenciaController],
  providers: [ReferenciaService, ToolsService],
  exports: [ReferenciaService],
})
export class ReferenciaModule {}
