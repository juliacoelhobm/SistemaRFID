import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Categorias } from 'src/categorias/schemas/categorias.schemas';
import { Empresas } from 'src/empresas/schemas/empresas.schema';
import { Usuarios } from 'src/usuarios/schemas/usuarios.schemas';
import { Produtos as Products } from 'src/produtos/schemas/produtos.schema';

export type ReferenciaDocument = Referencia & Document;

@Schema({ timestamps: true, collection: 'referencia' })
export class Referencia {
  @Prop({ required: true })
  nome: string;

  @Prop({ type: Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: Types.ObjectId, ref: () => Usuarios })
  usuario: Usuarios;

  @Prop({ type: Types.ObjectId, ref:  Products.name })
  itens: [Products];

  @Prop()
  quantidade: number;

  @Prop()
  minimo: number;

  @Prop()
  venda: number;

  @Prop()
  compra: number;

  @Prop()
  ativo: boolean;

  @Prop({ required: false })
  descricao: string;
}
export const ReferenciaSchema = SchemaFactory.createForClass(Referencia);
