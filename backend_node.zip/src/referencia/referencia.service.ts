import {
  BadRequestException,
  ForbiddenException,
  HttpException,
  HttpStatus,
  Injectable,
  NotAcceptableException,
} from '@nestjs/common';
import { CreateReferenciaDto } from './dto/create-referencia.dto';
import { UpdateReferenciaDto } from './dto/update-referencia.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Referencia } from './schemas/referencia.schema';
import { Produtos, ProdutosDocument } from './../produtos/schemas/produtos.schema';

/* import { AddRfid } from './dto/add-rfid.dto';
import { RemoveRfid } from './dto/remove-rfid.dto';
import { FindRfid } from './dto/find-rfid.dto'; */

@Injectable()
export class ReferenciaService {
 
  constructor(
    @InjectModel(Produtos.name) private produtosModel: Model<ProdutosDocument>,
    @InjectModel('Referencia')
    private readonly referenciaModel: Model<Referencia>,
  ) {}

  async create(createReferenciaDto: CreateReferenciaDto): Promise<any> {
    try {
      const createdReferencia = new this.referenciaModel(createReferenciaDto);
      return await createdReferencia.save();
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }
  }
//empresa, ativo: true 
  async findAll(empresa: string): Promise<any> {
    console.log('empresa',empresa)
    return await this.referenciaModel.find({empresa: empresa })
    .populate('itens','',this.produtosModel)
    .exec();
  }

  async findOne(id: string) {
    try {
      //.lean() para plain object
      return await this.referenciaModel.findById(id).exec();
    } catch {
      return null;
    }
  }

  async update(id: string, updateReferenciaDto: UpdateReferenciaDto) {
    await this.referenciaModel.updateOne({ _id: id }, updateReferenciaDto).exec();
    return await this.findOne(id);
  }

  async addProd(data: any):Promise<any> {
    return await this.referenciaModel.updateOne(
      { _id: data.referenciaId },
      {$addToSet: 
        {"itens" :data.produtoId}}
      //{ $push: { itens: data.produtoId } }
   );
  }
  async removeProd(data: any):Promise<any> {
    return await this.referenciaModel.updateOne(
      { _id: data.referenciaId },   
      {$pullAll: {
        "itens": data.produtoId,
    },}
   );
  }

  async remove(id: string):Promise<any> {
    //throw new ForbiddenException('Não pode remover');
    return await this.referenciaModel.deleteOne({_id:id}).exec();
  }

  

  addOwner(refId: string, itemId: string) {
    return this.referenciaModel.findByIdAndUpdate(
      refId,
      { $addToSet: { owners: itemId } },
      { new: true },
    );
  }
  removeOwner(refId: string, itemId: string) {
    return this.referenciaModel.findByIdAndUpdate(
      refId,
      { $pull: { owners: itemId } },
      { new: true },
    );
  }
  async getOwners(refId: string) {
    const referencia = await this.referenciaModel.findById(refId).populate('produtos');
    return referencia.itens;
  }

  //adiciona rfid em um produto existente
 /*  async addRfid(rfid: AddRfid) {
    const produto = await this.findOne(rfid.id);
    const resp = produto.identificacao.filter((el) => el.tipo == rfid.tipo);
    if (resp.length) {
      throw new HttpException('Tipo já cadastrado!', HttpStatus.FOUND);
    }

    produto.identificacao.push({
      tipo: rfid.tipo,
      codigo: rfid.codigo,
    });

    produto.save();

    return produto;
  }

  //atualiza rfid em um produto existente
  async updateRfid(rfid: AddRfid) {
    const produto = await this.findOne(rfid.id);
    let resp = produto.identificacao.filter((el) => el.tipo == rfid.tipo);
    if (!resp.length) {
      throw new HttpException('Tipo não cadastrado!', HttpStatus.NOT_FOUND);
    }

    resp = produto.identificacao.filter((el) => el.tipo != rfid.tipo);
    produto.identificacao = resp;

    produto.identificacao.push({
      tipo: rfid.tipo,
      codigo: rfid.codigo,
    });

    produto.save();

    return produto;
  }

  // remove um rfid existente em um produto
  async removeRfid(rfid: RemoveRfid) {
    const produto = await this.findOne(rfid.id);
    let resp = produto.identificacao.filter((el) => el.tipo == rfid.tipo);
    if (!resp.length) {
      throw new HttpException('Tipo não cadastrado!', HttpStatus.NOT_FOUND);
    }

    resp = produto.identificacao.filter((el) => el.tipo != rfid.tipo);
    produto.identificacao = resp;

    produto.save();

    return produto;
  }

  // Pesquisa um produto por RFID
  async findRfid(rfid: FindRfid) {
    const pesquisar = {
      'identificacao.tipo': rfid.tipo,
      'identificacao.codigo': rfid.codigo,
    };
    try {
      return await this.referenciaModel.find(pesquisar).exec();
    } catch (error) {
      return null;
    }
  } */

  async updateEstoque(id: string, valor: number) {
    try {
      return await this.referenciaModel.findByIdAndUpdate(
        id,
        {
          $inc: { quantidade: valor },
        },
        { new: true, upsert: true },
      );
    } catch (e) {
      throw new NotAcceptableException('Erro ao atualizar o estoque!');
    }
  }

  async findByCategory(empresa: string, categoria: string) {
    const pesquisar = {
      empresa,
      categoria,
    };

    try {
      return await this.referenciaModel
        .find(pesquisar)
        .sort({ nome: 1 })
        .lean()
        .exec();
    } catch (error) {
      return null;
    }
  }
}
