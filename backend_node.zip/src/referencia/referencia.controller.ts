import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UseGuards,
  UploadedFile,
} from '@nestjs/common';
import { ReferenciaService } from './referencia.service';
import { CreateReferenciaDto } from './dto/create-referencia.dto';
import { UpdateReferenciaDto } from './dto/update-referencia.dto';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { AddItem } from './dto/add-item.dto';
//import { RemoveRfid } from './dto/remove-rfid.dto';
//import { FindRfid } from './dto/find-rfid.dto'; */
import { User } from 'src/shared/decorators/user.decorator';
import { UserEntity } from 'src/shared/entities/user.entity';
// import { FileInterceptor } from '@nestjs/platform-express';

@Controller('referencia')
@ApiTags('CRUD dos referencia.')
@UseInterceptors(new DataformInterceptor())
@UseGuards(AuthGuard('jwt'))
export class ReferenciaController {
  constructor(
    private readonly referenciaService: ReferenciaService,
    private readonly toolsService: ToolsService,
  ) {}

  
/*
  @Post('/rfid/update')
  @ApiOperation({ summary: 'Altera código de barras ao produto.' })
  rfidUpdate(@Body() rfid: AddRfid) {
    return this.referenciaService.updateRfid(rfid);
  }

  @Post('/rfid/remove')
  @ApiOperation({ summary: 'Remove código de barras ao produto.' })
  rfidRemove(@Body() rfid: RemoveRfid) {
    return this.referenciaService.removeRfid(rfid);
  }

  @Post('/rfid/find')
  @ApiOperation({ summary: 'Pesquisa o produto por codigo de barras.' })
  rfidFind(@Body() rfid: FindRfid) {
    return this.referenciaService.findRfid(rfid);
  } */

  @Post('/item/add')
  @ApiOperation({ summary: 'Inserindo item em uma referencia.' })
  addProd(@Body() data: AddItem) {
    return this.referenciaService.addProd(data);
  }
  @Post('/item/remove')
  @ApiOperation({ summary: 'removendo item em uma referencia.' })
  removeProd(@Body() data: AddItem) {
    return this.referenciaService.removeProd(data);
  }

  @Post()
  @ApiOperation({ summary: 'Inserindo referencia.' })
  create(
    @Body() createReferenciaDto: CreateReferenciaDto,
    @User() user: UserEntity,
  ): Promise<CreateReferenciaDto> {
    createReferenciaDto.empresa = user.empresa;
    createReferenciaDto.ativo = this.toolsService.convertToBoolean(
      createReferenciaDto.ativo,
    );
    return this.referenciaService.create(createReferenciaDto);
  }

  @ApiOperation({ summary: 'Listar todos as referencia.' })
  @ApiResponse({ status: 200, description: 'Sucesso na consulta' })
  @Get()
  findAll(@User() user: UserEntity): Promise<any> {
    return this.referenciaService.findAll(user.empresa);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Listar uma referencia pelo id.' })
  findOne(@Param('id') id: string) {
    return this.referenciaService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualiza referencia' })
  update(@Param('id') id: string, @Body() updateReferenciaDto: UpdateReferenciaDto) {
    return this.referenciaService.update(id, updateReferenciaDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Exclui o produto.' })
  remove(@Param('id') id: string) {
    return this.referenciaService.remove(id);
  }

  /*
  @Post('/upload/:id')
  @UseInterceptors(FileInterceptor('imagem'))
  @ApiOperation({ summary: 'Adiciona imagem no produto.' })
  uploadFile(@Param('id') id: string, @UploadedFile() imagem: Express.Multer.File) {
    console.log('id', id);
    console.log('imagem', imagem);
  }
  */
}
