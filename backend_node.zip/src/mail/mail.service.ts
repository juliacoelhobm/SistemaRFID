import { MailerService } from '@nestjs-modules/mailer';
import { Injectable } from '@nestjs/common';
import { CreateUsuarioDto } from './../usuarios/dto/create-usuario.dto';

@Injectable()
export class MailService {
  constructor(private mailerService: MailerService) {}

  async sendUserConfirmation(user: CreateUsuarioDto, token: string) {
    const url = `http://plataforma.greentag.com.br/auth/confirm?token=${token}`;

    const sendEmail = await this.mailerService.sendMail({
      to: user.email,
      // from: '"Support Team" <support@example.com>', // override default from
      subject: 'Bem-vindo a Plataforma Greentag! Confirme seu Email',
      template: './confirmation', // `.hbs` extension is appended automatically
      context: { // ✏️ filling curly brackets with content
        name: user.nome,
        email: user.email,
        password : user.password,
        url,
      },
    });
    console.log("sendEmail",sendEmail)
  }
}
