import { Injectable } from '@nestjs/common';
import { Usuarios } from 'src/usuarios/schemas/usuarios.schemas';
import { UsuariosService } from 'src/usuarios/usuarios.service';
import { compareSync } from 'bcrypt';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(
    private readonly usuariosService: UsuariosService,
    private readonly jwtService: JwtService,
  ) {}

  async login(user: any) {
    const payload = {
      sub: user._id,
      email: user.email,
      empresa: user.empresa,
    };
    return {
      token: this.jwtService.sign(payload),
      renewToken: this.jwtService.sign(payload, {
        expiresIn: process.env.JWT_REFRESH,
      }),
    };
  }
  async validateUser(email: string, password: string) {
    let user: Usuarios | any;
    try {
      user = await this.usuariosService.findByEmail(email);
    } catch (error) {
      return null;
    }
    console.log('user ==>>> ',user)
    if (!user) return null;

    const senhaValida = compareSync(password, user.password);
    if (!senhaValida) return null;

    delete user.password;
    delete user.createdAt;
    delete user.updatedAt;
    return user;
  }

  async refresh(user: any) {
    const payload = {
      sub: user.id,
      email: user.email,
      empresa: user.empresa,
    };
    return {
      token: this.jwtService.sign(payload),
      renewToken: this.jwtService.sign(payload, {
        expiresIn: process.env.JWT_REFRESH,
      }),
    };
  }
}
