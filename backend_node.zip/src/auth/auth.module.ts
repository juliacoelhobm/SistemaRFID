import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { UsuariosModule } from 'src/usuarios/usuarios.module';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { LocalStrategy } from 'src/shared/strategies/local.strategy';
import { ConfigModule } from '@nestjs/config';
import { JwtStrategy } from 'src/shared/strategies/jwt.strategy';
import { MailModule } from 'src/mail/mail.module';
@Module({
  imports: [
    ConfigModule.forRoot(),
    UsuariosModule,
    MailModule,
    PassportModule,
    JwtModule.register({
      privateKey: process.env.JWT_SECRET_KEY,
      signOptions: {
        expiresIn: process.env.JWT_EXPIRES,
      },
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService, LocalStrategy, JwtStrategy],
})
export class AuthModule {}

// para gerar uma chave privada randomicamente
// openssl rand -base64 32
