import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UseGuards,
  UploadedFile,
} from '@nestjs/common';
import { InventarioService } from './inventario.service';
import { CreateInventarioDto } from './dto/create-inventario.dto';
import { UpdateInventarioDto } from './dto/update-inventario.dto';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ToolsService } from 'src/shared/services/tools/tools.service';

import { User } from 'src/shared/decorators/user.decorator';
import { UserEntity } from 'src/shared/entities/user.entity';
//import { Types } from 'mongoose';
import { ConsultarInventarios } from './dto/consultar-inventarios.dto';
//import { ObjectId } from 'typeorm/driver/mongodb/bson.typings';
import { ObjectID  } from "bson";

// import { FileInterceptor } from '@nestjs/platform-express';

@Controller('inventario')
@ApiTags('CRUD dos inventario.')
@UseInterceptors(new DataformInterceptor())
@UseGuards(AuthGuard('jwt'))
export class InventarioController {
  constructor(
    private readonly inventarioService: InventarioService,
    private readonly toolsService: ToolsService,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Inserindo inventario.' })
  create(
    @Body() createInventarioDto: CreateInventarioDto,
    @User() user: UserEntity,
  ): Promise<CreateInventarioDto> {
    createInventarioDto.empresa = user.empresa;
    createInventarioDto.usuario = user.id;
    console.log('createInventarioDto ==>>> ',createInventarioDto)
    createInventarioDto.ativo = this.toolsService.convertToBoolean(
      createInventarioDto.ativo,
    );
    console.log('createInventarioDto' , createInventarioDto)
    return this.inventarioService.create(createInventarioDto);
  }
  @ApiOperation({ summary: 'Listar todos os inventario.' })
  @ApiResponse({ status: 200, description: 'Sucesso na consulta' })
  @Get()
  findAll(@User() user: UserEntity): Promise<any> {
    return this.inventarioService.findAll(user.empresa);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Listar um produto pelo id.' })
  findOne(@Param('id') id: string) {
    return this.inventarioService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualiza produto' })
  update(@Param('id') id: string, @Body() updateInventarioDto: UpdateInventarioDto) {
    return this.inventarioService.update(id, updateInventarioDto);
  }


  @Delete(':id')
  @ApiOperation({ summary: 'Exclui o inventario.' })
  delete(@Param('id') id: string) {
    return this.inventarioService.remove(id);
  }

  @Post('/contador')
  @ApiOperation({ summary: 'Listar numero de produtos por categoria.' })
  contador(@User() user: UserEntity) {
    console.log('chamou o contador')
    const empresaId = new ObjectID(user.empresa)
    //const empresaId = user.empresa
    return this.inventarioService.contador(empresaId);
  }

  @Post('consultar')
  @ApiOperation({
    summary: 'Lista inventarios por referencia, idReferencia, categoria, usuario, date.',
  })
  @UseInterceptors(new DataformInterceptor())
  @UseGuards(AuthGuard('jwt'))
  async consultar(@Body() body: ConsultarInventarios, @User() user: UserEntity) {
    const corpo: any = {};
    if (body.categoria) {
      corpo.categoria = body.categoria;
    }
    if (body.produto) {
      corpo["conteudo.productsByCategory._id"]  =  body.produto
    }
    if (body.usuario) {
      console.log('usuario',body.usuario)
      //mongoose.Types.ObjectId(id)
      try{
        const obj = new ObjectID(body.usuario)
        corpo["usuario"] =  obj;
      }
      catch(error){
        console.log(error)

      }
      
      
    }
    if (body.startDate && body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        $lt: body.endDate,
      }
      
    }
    if (body.startDate && !body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        //$lt: body.endDate,
      }
    }
    if (!body.startDate && body.endDate) {
      corpo.createdAt = {
        //$gte: body.startDate,
        $lt: body.endDate,
      }
    }
    corpo.empresa = user.empresa;

    return await this.inventarioService.consultarInventarios(corpo);
  }




  /*
  @Post('/upload/:id')
  @UseInterceptors(FileInterceptor('imagem'))
  @ApiOperation({ summary: 'Adiciona imagem no produto.' })
  uploadFile(@Param('id') id: string, @UploadedFile() imagem: Express.Multer.File) {
    console.log('id', id);
    console.log('imagem', imagem);
  }
  */
}