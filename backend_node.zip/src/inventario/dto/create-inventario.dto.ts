import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEmail,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class CreateInventarioDto {
  
  @ApiProperty()
  @IsBoolean({ message: ValidatorMessage.IsBoolean })
  ativo: boolean;

  @ApiProperty()
  observacao?: string;

  @ApiProperty()
  empresa: string;

  @ApiProperty()
  usuario: string;

  @ApiProperty()
  categoria: string;

  @ApiProperty()
  conteudo: JSON;

  createdAt: Date;
  updatedAt: Date;
}
