import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';

import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class ConsultarInventarios {
  
  
  @ApiProperty()
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  empresa: string;

  @ApiProperty()
  @IsOptional()
  categoria: string;

  @ApiProperty()
  @IsOptional()
  usuario: string;

  @ApiProperty()
  @IsOptional()
  produto: string;

  @ApiProperty()
  @IsOptional()
  startDate: string;

  @ApiProperty()
  @IsOptional()
  endDate: string;
}
