import {
  BadRequestException,
  ForbiddenException,
  HttpException,
  HttpStatus,
  Injectable,
  NotAcceptableException,
} from '@nestjs/common';
import { CreateInventarioDto } from './dto/create-inventario.dto';
import { UpdateInventarioDto } from './dto/update-inventario.dto';
import { InjectModel } from '@nestjs/mongoose';
import { FilterQuery, Model } from 'mongoose';
import { Inventario } from './schemas/inventario.schemas';
import { Usuarios, UsuariosDocument } from './../usuarios/schemas/usuarios.schemas';
import { UserEntity } from 'src/shared/entities/user.entity';

@Injectable()
export class InventarioService {
  constructor(
    @InjectModel(Usuarios.name) private usuariosModel: Model<UsuariosDocument>,
    @InjectModel('Inventario')

    private readonly inventarioModel: Model<Inventario>,
  ) {}

  async create(
      createInventarioDto: CreateInventarioDto,
      //user: UserEntity,
    ): Promise<any> {
    try {
      const createdInventario = new this.inventarioModel(createInventarioDto);
      console.log('createdInventario', createdInventario)
      
      return await createdInventario.save();
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }
  }

  async findAll(empresa: string): Promise<any> {
    return await this.inventarioModel.find({ empresa, ativo: true }).populate('usuario','',this.usuariosModel).exec();
  }

  async findOne(id: string) {
    try {
      //.lean() para plain object
      return await this.inventarioModel.findById(id).exec();
    } catch {
      return null;
    }
  }

  async update(id: string, updateInventarioDto: UpdateInventarioDto) {
    await this.inventarioModel.updateOne({ _id: id }, updateInventarioDto).exec();
    return await this.findOne(id);
  }

  async remove(id: string): Promise<any> {
    //throw new ForbiddenException('Não pode remover');
    return await this.inventarioModel.deleteOne({_id:id}).exec();
  }

  async findByCategory(empresa: string, categoria: string) {
    const pesquisar = {
      empresa,
      categoria,
    };

    try {
      return await this.inventarioModel
        .find(pesquisar)
        .sort({ createdAt: 1 })
        .populate('usuario','',this.usuariosModel)
        .lean()
        .exec();
    } catch (error) {
      return null;
    }
  }

  async contador(empresaId:any) : Promise<any> {
    var lista : any;
    var lista_prog : any;
    var initialDate = new Date('2020-01-01')
    var total = await this.inventarioModel.find({ empresa: empresaId}).count()
    console.log('empresaId',empresaId)
    var match_stage = {
        $match: { 
            empresa: empresaId
        }
    }
    
    var group_stage = {
        $group: {
            // _id: "$conteudo.productsByCategory.nome",
            _id: "$categoria",
            count: { $sum: 1 }
        }
    }
    
    var pipeline = [ match_stage, group_stage ]
    console.log(pipeline)
    try { 
      //.lean() para plain object
      lista = await this.inventarioModel.aggregate(pipeline)
    } catch(error) {
      console.log('error', error)
      
    }
    console.log('lista',lista)

    var match_stage_prog = {
        $match: { 
            empresa: empresaId
        }
    }
    
    var group_stage_prog = {
        $group: {
          _id: "$categoria",
          "completos": {
              "$sum": { "$cond": [
                  { "$eq": [ "$conteudo.progress", 1 ] },
                  1,
                  0
              ]}
          },
          "totalCount": { "$sum": 1 }
      }}
        /* $group: {
            _id: "$conteudo.progress",
            //_id: "$categoria",
            total: { $sum: 1 },
            completes: { $sum : {"$cond": [
              { "$eq": [ "$conteudo.progress", "1" ] },
              1,
              0
          ]}}
        } */
    
    
    var pipeline_prog = [ match_stage_prog, group_stage_prog ]
    console.log(pipeline_prog)
    try { 
      //.lean() para plain object
      lista_prog = await this.inventarioModel.aggregate(pipeline_prog)
    } catch(error) {
      console.log('error', error)
      
    }
    console.log('lista_prog',lista_prog)
    return {lista,lista_prog, total};
  }


  async consultarInventarios(dt: FilterQuery<Inventario>) {
    console.log('compare', dt)
    return await this.inventarioModel.find(dt).populate('usuario','',this.usuariosModel).exec();
  }
}
