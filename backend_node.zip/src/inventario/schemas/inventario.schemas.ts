import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types, Schema as MongoSchema } from 'mongoose';
import { Empresas } from 'src/empresas/schemas/empresas.schema';
import { Usuarios } from 'src/usuarios/schemas/usuarios.schemas';
import { Categorias } from 'src/categorias/schemas/categorias.schemas';

export type InventarioDocument = Inventario & Document;

@Schema({ timestamps: true, collection: 'inventario' })
export class Inventario {
  @Prop({ type: MongoSchema.Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: MongoSchema.Types.ObjectId, ref: () => Usuarios })
  usuario: Usuarios;

  @Prop({ type: Types.ObjectId, ref: () => Categorias })
  categoria: string;

  @Prop()
  observacao: string;

  @Prop({ type: Boolean, default: true })
  ativo: boolean;

  @Prop({ type: JSON })
  conteudo: JSON;
}

export const InventarioSchema = SchemaFactory.createForClass(Inventario);
