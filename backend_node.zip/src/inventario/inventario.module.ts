import { Module } from '@nestjs/common';
import { InventarioService } from './inventario.service';
import { InventarioController } from './inventario.controller';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { MongooseModule } from '@nestjs/mongoose';
import { InventarioSchema } from './schemas/inventario.schemas';
import { UsuariosSchema, UsuariosDocument } from 'src/usuarios/schemas/usuarios.schemas';
import { UsuariosModule } from 'src/usuarios/usuarios.module';
import { EmpresasModule } from 'src/empresas/empresas.module';
@Module({
  
  imports: [
    MongooseModule.forFeature([
      { name: 'Inventario', schema: InventarioSchema },
      { name: 'Usuarios', schema: UsuariosSchema },
      { name: 'UsuariosDocument', schema: UsuariosSchema },
      
    ]),
    UsuariosModule,
    EmpresasModule
  ],
  controllers: [InventarioController],
  providers: [InventarioService, ToolsService],
  exports: [InventarioService],
})
export class InventarioModule {}
