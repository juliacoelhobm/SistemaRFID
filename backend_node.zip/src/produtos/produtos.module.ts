import { Module, forwardRef } from '@nestjs/common';
import { ProdutosService } from './produtos.service';
import { ProdutosController } from './produtos.controller';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { MongooseModule } from '@nestjs/mongoose';
import { ProdutosSchema } from './schemas/produtos.schema';
import { UsuariosSchema, UsuariosDocument } from 'src/usuarios/schemas/usuarios.schemas';
import { ReferenciaSchema, ReferenciaDocument } from 'src/referencia/schemas/referencia.schema';
import { UsuariosModule } from 'src/usuarios/usuarios.module';
import { EmpresasModule } from 'src/empresas/empresas.module';
import { ReferenciaModule } from 'src/referencia/referencia.module';

@Module({
  imports: [
    MongooseModule.forFeature([
    { name: 'Produtos', schema: ProdutosSchema },
    { name: 'Referencia', schema: ReferenciaSchema },
    { name: 'ReferenciaDocument', schema: ReferenciaSchema },
    { name: 'Usuarios', schema: UsuariosSchema },
    { name: 'UsuariosDocument', schema: UsuariosSchema },
  ]),
  UsuariosModule,
  EmpresasModule,
  //ReferenciaModule
  forwardRef(() => ReferenciaModule)
  ],
  controllers: [ProdutosController],
  providers: [ProdutosService, ToolsService],
  exports: [ProdutosService],
})
export class ProdutosModule {}
