import {
  BadRequestException,
  ForbiddenException,
  HttpException,
  HttpStatus,
  Injectable,
  NotAcceptableException,
} from '@nestjs/common';
import { CreateProdutoDto } from './dto/create-produto.dto';
import { UpdateProdutoDto } from './dto/update-produto.dto';
import { InjectModel } from '@nestjs/mongoose';
import { FilterQuery, Model } from 'mongoose';
import { Produtos } from './schemas/produtos.schema';
import { AddRfid } from './dto/add-rfid.dto';
import { RemoveRfid } from './dto/remove-rfid.dto';
import { FindRfid } from './dto/find-rfid.dto';

import { Usuarios, UsuariosDocument } from './../usuarios/schemas/usuarios.schemas';
import { Referencia, ReferenciaDocument } from 'src/referencia/schemas/referencia.schema';

@Injectable()
export class ProdutosService {
  constructor(
    @InjectModel(Usuarios.name) private usuariosModel: Model<UsuariosDocument>,
    @InjectModel(Referencia.name) private referenciaModel: Model<ReferenciaDocument>,
    @InjectModel(Referencia.name) private refModel: Model<Referencia>,
    @InjectModel('Produtos')
    private readonly produtosModel: Model<Produtos>,
    
  ) {}

  async create(createProdutoDto: CreateProdutoDto): Promise<any> {
    try {
      const createdProdutos = new this.produtosModel(createProdutoDto);
      const produto = await createdProdutos.save();
      console.log('produto ',produto)
      const referenciaId = createProdutoDto.referencia
      if(referenciaId){
       // const referenciaExistente = await this.referenciaModel.findById(referenciaId).exec();
        const referenciaUpdate = await this.refModel.updateOne(
          { _id: referenciaId },
          { $push: { itens: produto._id } }
       );
      }
      return produto
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }
  }

  async findAll(empresa: string): Promise<any> {
    return await this.produtosModel.find({ empresa, ativo: true })
    .populate('usuario','',this.usuariosModel)
    .populate('referencia','',this.referenciaModel)
    .exec();
  }

  async findOne(id: string) {
    try {
      //.lean() para plain object
      return await this.produtosModel.findById(id).exec();
    } catch {
      return null;
    }
  }


  async contador(empresaId:any) : Promise<any> {
    var lista : any;
    var initialDate = new Date('2020-01-01')
    //console.log('initialDate',initialDate)
    var match_stage = {
        $match: { 
            ativo: true, empresa: empresaId
        }
    }
    
    var group_stage = {
        $group: {
            _id: "$categoria",
            count: { $sum: 1 }
        }
    }
    
    var pipeline = [ match_stage, group_stage ]
    console.log(pipeline)
    try { 
      //.lean() para plain object
      lista = await this.produtosModel.aggregate(pipeline)
    } catch(error) {
      console.log('error', error)
      
    }
    console.log('lista',lista)
    return lista;
  }

  async update(id: string, updateProdutoDto: UpdateProdutoDto) {
    const referenciaId = updateProdutoDto.referencia
    console.log('referenciaId',referenciaId)
      if(referenciaId){
       // const referenciaExistente = await this.referenciaModel.findById(referenciaId).exec();
       const referenciaAtual = (await this.produtosModel.findOne({_id:id})).referencia
       console.log('referenciaAtual',referenciaAtual)
       if(referenciaAtual){
        await this.refModel.updateOne(
          { _id: referenciaAtual },   
            {$pullAll: {
              "itens": [id],
            },}
        ); 
        
       
       }
       const referenciaUpdate = await this.refModel.updateOne(
        { _id: referenciaId },
        { $push: { itens: id } }
      );
       console.log('referenciaUpdate', referenciaUpdate)
       
      }
    await this.produtosModel.updateOne({ _id: id }, updateProdutoDto).exec();
    return await this.findOne(id);
  }

  async updateMany(data:any) :Promise<any> {

    console.log('updateMany',data)
    const referenciaId = data.referenciaId

      if(referenciaId){
       // const referenciaExistente = await this.referenciaModel.findById(referenciaId).exec();
       
       await this.refModel.updateOne(
        { _id: data.referenciaId },   
        {$pullAll: {
          "itens": data.produtosId,
      },}
       ); 
      
      }
      const result = await this.produtosModel.updateMany({ _id: data.produtosId }, data.params).exec();
      return result
    //await this.findOne(id);
  }

  async remove(id: string) : Promise<any>{
    //throw new ForbiddenException('Não pode remover');
    
      // const referenciaExistente = await this.referenciaModel.findById(referenciaId).exec();
      const referenciaAtual = (await this.produtosModel.findOne({_id:id})).referencia
      await this.refModel.updateOne(
       { _id: referenciaAtual },   
       { $pullAll: {
         "itens": [id],
          },
        }
      ); 
    return await this.produtosModel.deleteOne({_id:id}).exec();
  }

  //adiciona rfid em um produto existente
  async addRfid(rfid: AddRfid) {
    const produto = await this.findOne(rfid.id);
    const resp = produto.identificacao.filter((el) => el.tipo == rfid.tipo);
    if (resp.length) {
      throw new HttpException('Tipo já cadastrado!', HttpStatus.FOUND);
    }

    produto.identificacao.push({
      tipo: rfid.tipo,
      codigo: rfid.codigo,
    });

    produto.save();

    return produto;
  }

  //atualiza rfid em um produto existente
  async updateRfid(rfid: AddRfid) {
    const produto = await this.findOne(rfid.id);
    let resp = produto.identificacao.filter((el) => el.tipo == rfid.tipo);
    if (!resp.length) {
      throw new HttpException('Tipo não cadastrado!', HttpStatus.NOT_FOUND);
    }

    resp = produto.identificacao.filter((el) => el.tipo != rfid.tipo);
    produto.identificacao = resp;

    produto.identificacao.push({
      tipo: rfid.tipo,
      codigo: rfid.codigo,
    });

    produto.save();

    return produto;
  }

  // remove um rfid existente em um produto
  async removeRfid(rfid: RemoveRfid) {
    const produto = await this.findOne(rfid.id);
    let resp = produto.identificacao.filter((el) => el.tipo == rfid.tipo);
    if (!resp.length) {
      throw new HttpException('Tipo não cadastrado!', HttpStatus.NOT_FOUND);
    }

    resp = produto.identificacao.filter((el) => el.tipo != rfid.tipo);
    produto.identificacao = resp;

    produto.save();

    return produto;
  }

  // Pesquisa um produto por RFID
  async findRfid(rfid: FindRfid) {
    const pesquisar = {
      //'identificacao.tipo': rfid.tipo,
      'identificacao.codigo': rfid.codigo,
    };
    try {
      return await this.produtosModel.find(pesquisar).exec();
    } catch (error) {
      return null;
    }
  }
  async findManyRfid(list: any) {
    const pesquisar = {
      //'identificacao.tipo': rfid.tipo,
      'identificacao.codigo': {$in : list},
    };
    try {
      return await this.produtosModel.find(pesquisar).exec();
    } catch (error) {
      return null;
    }
  }

  async updateEstoque(id: string, valor: number) {
    try {
      return await this.produtosModel.findByIdAndUpdate(
        id,
        {
          $inc: { quantidade: valor },
        },
        { new: true, upsert: true },
      );
    } catch (e) {
      throw new NotAcceptableException('Erro ao atualizar o estoque!');
    }
  }

  async findByCategory(empresa: string, categoria: string) {
    const pesquisar = {
      empresa,
      categoria,
    };

    try {
      return await this.produtosModel
        .find(pesquisar)
        .sort({ nome: 1 })
        .lean()
        .exec();
    } catch (error) {
      return null;
    }
  }
  async consultar(dt: FilterQuery<Produtos>) {
    console.log('compare', dt)
    return await this.produtosModel.find(dt)
    .populate('usuario','',this.usuariosModel)
    .populate('referencia','',this.referenciaModel)
    .exec();
  }
}
