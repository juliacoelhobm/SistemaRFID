import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';
import { TiposCodigosRfid } from 'src/shared/enums/tiposcodigosrfid.enum';

import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class AddRfid {
  @ApiProperty({
    name: 'id',
    description: 'id do produto',
  })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  id: string;

  @ApiProperty({
    name: 'tipo',
    enum: TiposCodigosRfid,
  })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  @IsEnum(TiposCodigosRfid, { message: ValidatorMessage.IsEnum })
  tipo: TiposCodigosRfid;

  @ApiProperty()
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  codigo: string;
}
