import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Categorias } from 'src/categorias/schemas/categorias.schemas';
import { Empresas } from 'src/empresas/schemas/empresas.schema';
import { Usuarios } from 'src/usuarios/schemas/usuarios.schemas';
import { Referencia } from 'src/referencia/schemas/referencia.schema';

export type ProdutosDocument = Produtos & Document;

@Schema({ timestamps: true, collection: 'produtos' })
export class Produtos {
  @Prop({ required: true })
  nome: string;

  @Prop({ type: Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: Types.ObjectId, ref: () => Usuarios })
  usuario: Usuarios;

  @Prop()
  referencia: string;

  @Prop()
  quantidade: number;

  @Prop()
  minimo: number;

  @Prop({ type: Types.ObjectId, ref: () => Categorias })
  categoria: string;

  @Prop()
  venda: number;

  @Prop()
  compra: number;

  @Prop({ type: Types.Array})
  identificacao: Identificacao[];

  @Prop()
  ativo: boolean;

  @Prop({ required: false })
  descricao: string;
}
//-----
class Identificacao {
  @Prop({ type: String, required: true, uppercase: true })
  tipo: string;
  @Prop({ required: true })
  codigo: string;
}

export const ProdutosSchema = SchemaFactory.createForClass(Produtos);
