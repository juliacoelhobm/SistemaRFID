import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UseGuards,
  UploadedFile,
} from '@nestjs/common';
import { ProdutosService } from './produtos.service';
import { CreateProdutoDto } from './dto/create-produto.dto';
import { UpdateProdutoDto } from './dto/update-produto.dto';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { AddRfid } from './dto/add-rfid.dto';
import { RemoveRfid } from './dto/remove-rfid.dto';
import { FindRfid } from './dto/find-rfid.dto';
import { User } from 'src/shared/decorators/user.decorator';
import { UserEntity } from 'src/shared/entities/user.entity';
import { ConsultarProduto } from './dto/consultar-produto.dto';
//import { ObjectId } from 'typeorm/driver/mongodb/bson.typings';
import { ObjectID  } from "bson";
// import { FileInterceptor } from '@nestjs/platform-express';

@Controller('produtos')
@ApiTags('CRUD dos produtos.')
@UseInterceptors(new DataformInterceptor())
@UseGuards(AuthGuard('jwt'))
export class ProdutosController {
  constructor(
    private readonly produtosService: ProdutosService,
    private readonly toolsService: ToolsService,
  ) {}

  @Post('/rfid/add')
  @ApiOperation({ summary: 'Inserindo código de barras ao produto.' })
  rfidAdd(@Body() rfid: AddRfid) {
    return this.produtosService.addRfid(rfid);
  }

  @Post('/rfid/update')
  @ApiOperation({ summary: 'Altera código de barras ao produto.' })
  rfidUpdate(@Body() rfid: AddRfid) {
    return this.produtosService.updateRfid(rfid);
  }

  @Post('/rfid/remove')
  @ApiOperation({ summary: 'Remove código de barras ao produto.' })
  rfidRemove(@Body() rfid: RemoveRfid) {
    return this.produtosService.removeRfid(rfid);
  }

  @Post('/rfid/find')
  @ApiOperation({ summary: 'Pesquisa o produto por codigo de barras.' })
  rfidFind(@Body() rfid: FindRfid) {
    return this.produtosService.findRfid(rfid);
  }
  @Post('/rfid/findmany')
  @ApiOperation({ summary: 'Pesquisa os produtos por codigo de barras.' })
  findManyRfid(@Body() idendificacao: any) {
    console.log('idendificacao',idendificacao)
    return this.produtosService.findManyRfid(idendificacao);
  }

  @Post()
  @ApiOperation({ summary: 'Inserindo produtos.' })
  create(
    @Body() createProdutoDto: CreateProdutoDto,
    @User() user: UserEntity,
  ): Promise<CreateProdutoDto> {
    createProdutoDto.empresa = user.empresa;
    createProdutoDto.usuario = user.id;

    createProdutoDto.ativo = this.toolsService.convertToBoolean(
      createProdutoDto.ativo,
    );
    return this.produtosService.create(createProdutoDto);
  }

  @ApiOperation({ summary: 'Listar todos os produtos.' })
  @ApiResponse({ status: 200, description: 'Sucesso na consulta' })
  @Get()
  findAll(@User() user: UserEntity): Promise<any> {
    return this.produtosService.findAll(user.empresa);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Listar um produto pelo id.' })
  findOne(@Param('id') id: string) {
    return this.produtosService.findOne(id);
  }

  

  @Patch(':id')
  @ApiOperation({ summary: 'Atualiza produto' })
  update(@Param('id') id: string, @Body() updateProdutoDto: UpdateProdutoDto) {
    return this.produtosService.update(id, updateProdutoDto);
  }

  @Patch()
  @ApiOperation({ summary: 'Atualiza produto' })
  updateMany( @Body() data: any) {
    return this.produtosService.updateMany(data);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Exclui o produto.' })
  remove(@Param('id') id: string) {
    return this.produtosService.remove(id);
  }


  @Post('/contador')
  @ApiOperation({ summary: 'Listar numero de produtos por categoria.' })
  contador(@User() user: UserEntity) {
    console.log('chamou o contador')
    //const empresaId = new ObjectID(user.empresa)
    const empresaId = user.empresa
    return this.produtosService.contador(empresaId);
  }

  @Post('consultar')
  @ApiOperation({
    summary: 'Lista produtos por referencia, idReferencia, categoria, usuario, date.',
  })
  @UseInterceptors(new DataformInterceptor())
  @UseGuards(AuthGuard('jwt'))
  async consultar(@Body() body: ConsultarProduto, @User() user: UserEntity) {
    const corpo: any = {};
    if (body.categoria) {
      corpo.categoria = body.categoria;
    }
    
    if (body.usuario) {
      console.log('usuario',body.usuario)
      //mongoose.Types.ObjectId(id)
      try{
        const obj = new ObjectID(body.usuario)
        corpo["usuario"] =  obj;
      }
      catch(error){
        console.log(error)

      }
      
      
    }
    if (body.startDate && body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        $lt: body.endDate,
      }
      
    }
    if (body.startDate && !body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        //$lt: body.endDate,
      }
    }
    if (!body.startDate && body.endDate) {
      corpo.createdAt = {
        //$gte: body.startDate,
        $lt: body.endDate,
      }
    }
    corpo.empresa = user.empresa;

    return await this.produtosService.consultar(corpo);
  }

  /*
  @Post('/upload/:id')
  @UseInterceptors(FileInterceptor('imagem'))
  @ApiOperation({ summary: 'Adiciona imagem no produto.' })
  uploadFile(@Param('id') id: string, @UploadedFile() imagem: Express.Multer.File) {
    console.log('id', id);
    console.log('imagem', imagem);
  }
  */
}
