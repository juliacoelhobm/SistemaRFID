import { Module } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { NotificationsController } from './notifications.controller';
import { NotificacoesSchema } from './schemas/notificacoes.schemas';
import { NotificacoesTokensSchema,  } from './schemas/notificacoesTokens.schemas';
import { MongooseModule } from '@nestjs/mongoose';
@Module({
  
  imports: [
    MongooseModule.forFeature([
      { name: 'Notificacoes', schema: NotificacoesSchema },
      { name: 'NotificacoesTokens', schema: NotificacoesTokensSchema}]),
  ],
  controllers: [NotificationsController],
  providers: [NotificationsService],
  exports: [NotificationsService]
})

export class NotificationsModule {}

