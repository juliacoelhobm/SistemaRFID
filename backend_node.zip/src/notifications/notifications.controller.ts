import { Controller, Get, Post, Body, Patch, Param, Delete, Put, UseInterceptors,
  UseGuards,
  UploadedFile, } from '@nestjs/common';

import { NotificationsService } from './notifications.service';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { UpdateNotificationDto } from './dto/update-notification.dto';

import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { User } from 'src/shared/decorators/user.decorator';
import { UserEntity } from 'src/shared/entities/user.entity';
// import { FileInterceptor } from '@nestjs/platform-express';

@Controller('notificacoes')
@ApiTags('CRUD das notificações.')
@UseInterceptors(new DataformInterceptor())
@UseGuards(AuthGuard('jwt'))


export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Post('/sendpush')
  sendpush(
        @Body() createNotificationDto: CreateNotificationDto,
        @User() user: UserEntity,
      ) {
    return this.notificationsService.sendPush(user,createNotificationDto.title,createNotificationDto.body);
  }
  @Post()
  create(@Body() createNotificationDto: CreateNotificationDto) {
    return {}//this.notificationsService.create(createNotificationDto);
  }
  @Get()
  findAll() {
    return this.notificationsService.getNotifications();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    //return this.notificationsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateNotificationDto: UpdateNotificationDto) {
    //return this.notificationsService.update(+id, updateNotificationDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Exclui a notificacao.' })
  // @ts-ignore
  remove(@Param('id') id: string) {
    return this.notificationsService.remove(id);
  }

  
}
