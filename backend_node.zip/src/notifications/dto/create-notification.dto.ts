
import { ApiProperty } from '@nestjs/swagger';

import {
  IsBoolean,
  IsEmail,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';


class NotificacoesTokens {
    @ApiProperty({ type: String })
    tipo: string;
    @ApiProperty({ type: String })
    codigo: string;
  }
  export class NotificationDto {
    notification_token: string;
    device_type: string;
  }
export class CreateNotificationDto  {
  /* @ApiProperty({
    description: 'Nome da notificacao',
    minLength: 5,
    maxLength: 255,
  })
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @MinLength(5, { message: ValidatorMessage.MinLength })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  nome: string; */

  @ApiProperty()
  empresa: string;

  @ApiProperty()
  title: string;

  @ApiProperty()
  body: string;

  @ApiProperty({
    description: 'Token e dados do usuario para envio das mensagens',
    isArray: true,
    type: NotificacoesTokens,
  })
  notificacoesTokens: NotificacoesTokens[];

  @ApiProperty()
  created_by: string;

  @ApiProperty()
  status: string;

}