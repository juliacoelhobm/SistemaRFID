import { Injectable, BadRequestException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Notificacoes } from './schemas/notificacoes.schemas';
import { Repository } from 'typeorm';
import * as firebase from 'firebase-admin';
import * as path from 'path';
import { NotificacoesTokens } from './schemas/notificacoesTokens.schemas';
import { NotificationDto } from './dto/create-notification.dto';
import { UpdateNotificationDto } from './dto/update-notification.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
firebase.initializeApp({
  credential: firebase.credential.cert(
    path.join(__dirname, '..', '..', 'firebase-adminsdk.json'),
  ),
});



@Injectable()
export class NotificationsService {
  constructor(
    
    
    //private readonly toolsService: ToolsService,
    @InjectModel('Notificacoes') private readonly notificacoesRepo: Model<Notificacoes>,
    @InjectModel('NotificacoesTokens') private readonly notificacoesTokensRepo: Model<NotificacoesTokens>,
    //@InjectRepository(NotificacoesTokens) private readonly notificacoesTokensRepo: Repository<NotificacoesTokens>,
  ) {}


//@ts-ignore
  async remove(id: string) : Promise<any>{
    //throw new ForbiddenException('Não pode remover');
    return this.notificacoesRepo.deleteOne({_id:id}).exec();// deleteOne()
  }  

  acceptPushNotification = async (
    usuario: any,
    notification_dto: NotificationDto ,
  ): Promise<NotificacoesTokens> => {
    console.log(usuario)
    console.log('notification_dto ==>',notification_dto)
    let update = await this.notificacoesTokensRepo.updateMany(
      { usuario : usuario._id },
      {"$set":{"status": "INACTIVE"}}

    );
    //
    console.log(update)
    try {
      const createNotificationDto = {
        usuario: usuario._id,
        device_type: notification_dto.device_type,
        notification_token: notification_dto.notification_token,
        status: 'ACTIVE',
      }
      const createdNotificacoesTokens = new this.notificacoesTokensRepo(createNotificationDto);
      return await createdNotificacoesTokens.save();
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }
    // save to db
   /*  const notification_token = await this.notificacoesTokensRepo.save({
      usuario: usuario,
      device_type: notification_dto.device_type,
      notification_token: notification_dto.notification_token,
      status: 'ACTIVE',
    });
    return notification_token; */
  };

  disablePushNotification = async (
    usuario: any,
    update_dto: UpdateNotificationDto,
  ): Promise<void> => {
    try {
      await this.notificacoesTokensRepo.update(
        { usuario:usuario, device_type: update_dto.device_type },
        {
          status: 'INACTIVE',
        },
      );
    } catch (error) {
      return error;
    }
  };

  getNotifications = async (): Promise<any> => {
    console.log('get notifications')
    return await this.notificacoesRepo.find();
  };
  getTokens = async (): Promise<any> => {
    console.log('get tokens')
    const tokens = await this.notificacoesTokensRepo.find(
      {status:'ACTIVE'}
      ).exec();
      console.log('tokens',tokens)
    return tokens
  };

  sendPush = async (usuario: any, title: string, body: string): Promise<void> => {
    try {
      const notification = await this.notificacoesTokensRepo.findOne({
        status: 'ACTIVE' 
      });
      if (notification) {

        console.log('notification ==> ',notification)
        try {
          const createNotificationDto = {
            notificacoesTokens: [notification._id],
            title,
            body,
            status: 'ACTIVE',
            created_by: 'Greentag',
          }
          const createdNotificacoes = new this.notificacoesRepo(createNotificationDto);
          await createdNotificacoes.save();
        } catch (error) {
          throw new BadRequestException({
            statusCode: 400,
            message: error.message,
            error: 'Conflict',
            keyValue: error.keyValue,
            keyPattern: error.keyPattern,
            mongoCode: error.code,
          });
        }
        const nt = notification.notification_token.replace(" ","")
        console.log('notification_token',nt)
        await firebase
          .messaging()
          .send({
            notification: { title, body },
            token: nt,
            android: { priority: 'high' },
          })
          .catch((error: any) => {
            console.error(error);
          });
      }
    } catch (error) {
      return error;
    }
  };
}