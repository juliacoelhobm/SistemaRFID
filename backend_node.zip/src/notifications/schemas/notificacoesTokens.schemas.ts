import { Usuarios } from 'src/usuarios/schemas/usuarios.schemas';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Empresas } from 'src/empresas/schemas/empresas.schema';

export type NotificacoesTokensDocument = NotificacoesTokens & Document;

@Schema({ timestamps: true, collection: 'notificacoesTokens' })
export class NotificacoesTokens {
  @Prop({ type: Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: Types.ObjectId, ref: () => Usuarios })
  usuario: Usuarios;

  /* @Prop({ required: true })
  nome: string; */

  @Prop({ required: true })
  device_type: string;

  @Prop({ required: true })
  notification_token: string;
  
  @Prop({ required: true, default:'true' })
  status: string;
}


export const NotificacoesTokensSchema = SchemaFactory.createForClass(NotificacoesTokens);