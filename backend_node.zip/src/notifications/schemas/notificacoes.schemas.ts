import { NotificacoesTokens } from './notificacoesTokens.schemas';
import { Empresas } from './../../empresas/schemas/empresas.schema';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
export type NotificacoesDocument = Notificacoes & Document;

@Schema({ timestamps: true, collection: 'notificacoes' })
export class Notificacoes {
  @Prop({ type: Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: [{ type: Types.ObjectId, ref: 'NotificacoesTokens' }] })
  notificacoesTokens: NotificacoesTokens[];

  @Prop({ required: true })
  title: string;

  @Prop()
  body: string;

  @Prop()
  created_by: string;

  @Prop({
    default: 'ACTIVE',
  })
  status: string;
}
export const NotificacoesSchema = SchemaFactory.createForClass(Notificacoes);