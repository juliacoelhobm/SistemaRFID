import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UseGuards,
  NotFoundException,
} from '@nestjs/common';
import { UsuariosService } from './usuarios.service';
import { NotificationsService } from './../notifications/notifications.service';
import { CreateUsuarioDto } from './dto/create-usuario.dto';
import { UpdateUsuarioDto } from './dto/update-usuario.dto';
import { UpdateNotificationDto } from './../notifications/dto/update-notification.dto';
import { NotificationDto } from './../notifications/dto/create-notification.dto';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { AuthGuard } from '@nestjs/passport';
import { User } from 'src/shared/decorators/user.decorator';
import { UserEntity } from 'src/shared/entities/user.entity';
import { ObjectID  } from "bson";
import { ConsultarUsuario } from './dto/consultar-usuario.dto';

interface iPassword {
  password: string;
  confirmPassword: string;
}

@ApiTags('CRUD de usuarios')
@UseInterceptors(new DataformInterceptor())
@Controller('usuarios')
@UseGuards(AuthGuard('jwt'))
export class UsuariosController {
  constructor(
    private readonly usuariosService: UsuariosService,
    private readonly notificationsService: NotificationsService,
    private readonly toolsService: ToolsService,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Inserindo usuário.' })
  create(@Body() createUsuarioDto: CreateUsuarioDto) {
    createUsuarioDto.ativo = this.toolsService.convertToBoolean(
      createUsuarioDto.ativo,
    );

    createUsuarioDto.permissoes = this.toolsService.convertJson(
      createUsuarioDto.permissoes,
    );

    return this.usuariosService.create(createUsuarioDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar todas os usuarios.' })
  @ApiResponse({ status: 200, description: 'Sucesso na consulta' })
  findAll() {
    return this.usuariosService.findAll();
  }

  @Get('/who')
  @ApiOperation({ summary: 'Lista o usuário logado.' })
  who(@User() user: UserEntity) {
    if (!user?.id) throw new NotFoundException('ID não encontrado!');
    return this.usuariosService.findOne(user.id);
  }

  @Get('/gettokens')
  @ApiOperation({ summary: 'Lista os tokens ativos.' })
  gettokens() {
    console.log('call getTokens ====>>>> ')
    return this.notificationsService.getTokens();
  }


  @Get(':id')
  @ApiOperation({ summary: 'Listar um usuario pelo id.' })
  findOne(@Param('id') id: string) {
    return this.usuariosService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualiza usuario' })
  update(@Param('id') id: string, @Body() updateUsuarioDto: UpdateUsuarioDto) {
    return this.usuariosService.update(id, updateUsuarioDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Exclui o registro mas mantem no banco de dados' })
  remove(@Param('id') id: string) {
    return this.usuariosService.remove(id);
  }

  @Post('/pwd/:id')
  @ApiOperation({ summary: 'Alterar senhas.' })
  updatePwd(@Param('id') id: string, @Body() dtPassword: iPassword) {
    return this.usuariosService.updatePassword(id, dtPassword);
  }

  @Put(':user_id/push/enable')
  async enablePush(
    @Body() update_dto: NotificationDto,
    @Param('id') user_id: number,
  ) {
    return await this.usuariosService.enablePush(user_id, update_dto);
  }

  @Put(':user_id/push/disable')
  async disablePush(
    @Param('id') user_id: number,
    @Body() update_dto: UpdateNotificationDto,
  ) {
    return await this.usuariosService.disablePush(user_id, update_dto);
  }

  @Get('push/notifications')
  async fetchPusNotifications() {
    return await this.notificationsService.getNotifications();
  }


  @Post('consultar')
  @ApiOperation({
    summary: 'Lista inventarios por referencia, idReferencia, categoria, usuario, date.',
  })
  @UseInterceptors(new DataformInterceptor())
  @UseGuards(AuthGuard('jwt'))
  async consultar(@Body() body: ConsultarUsuario, @User() user: UserEntity) {
    const corpo: any = {};
    
    
    if (body.usuario) {
      console.log('usuario',body.usuario)
      //mongoose.Types.ObjectId(id)
      try{
        const obj = new ObjectID(body.usuario) 
        const id = body.usuario
        corpo["usuario"] =  obj || id;
      }
      catch(error){
        console.log(error)

      }
      
      
    }
    if (body.startDate && body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        $lt: body.endDate,
      }
      
    }
    if (body.startDate && !body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        //$lt: body.endDate,
      }
    }
    if (!body.startDate && body.endDate) {
      corpo.createdAt = {
        //$gte: body.startDate,
        $lt: body.endDate,
      }
    }
    //corpo.empresa = user.empresa;

    return await this.usuariosService.consultar(corpo);
  }
  


}
