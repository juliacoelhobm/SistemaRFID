import { Module } from '@nestjs/common';
import { UsuariosService } from './usuarios.service';
import { UsuariosController } from './usuarios.controller';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { NotificationsService } from 'src/notifications/notifications.service';
import { EmpresasModule } from 'src/empresas/empresas.module';

import { NotificationsModule } from 'src/notifications/notifications.module';
import { MongooseModule } from '@nestjs/mongoose';
import { UsuariosSchema } from './schemas/usuarios.schemas';
import { NotificacoesSchema } from 'src/notifications/schemas/notificacoes.schemas';
import { NotificacoesTokensSchema,  } from 'src/notifications/schemas/notificacoesTokens.schemas';
import { MailModule } from 'src/mail/mail.module';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Usuarios', schema: UsuariosSchema },
      { name: 'Notificacoes', schema: NotificacoesSchema },
      { name: 'NotificacoesTokens', schema: NotificacoesTokensSchema}
    ]),
    EmpresasModule,
    NotificationsModule,
    MailModule
  ],
  controllers: [UsuariosController],
  providers: [UsuariosService, ToolsService, NotificationsService],
  exports: [UsuariosService],
})
export class UsuariosModule {}
