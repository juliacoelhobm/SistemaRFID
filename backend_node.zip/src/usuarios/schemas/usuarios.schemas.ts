import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongoSchema } from 'mongoose';
import { Empresas } from 'src/empresas/schemas/empresas.schema';
import { Usuarios as User } from 'src/usuarios/schemas/usuarios.schemas';

export type UsuariosDocument = Usuarios & Document;

@Schema({ timestamps: true, collection: 'usuarios' })
export class Usuarios {
  static nome(nome: any): (target: typeof import("src/inventario/inventario.service").InventarioService, propertyKey: undefined, parameterIndex: 0) => void {
    throw new Error('Method not implemented.');
  }
  @Prop({ type: MongoSchema.Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: MongoSchema.Types.ObjectId, ref: () => User })
  usuario: User;

  @Prop({ required: true })
  nome: string;

  @Prop({
    required: true,
    index: true,
    unique: true,
  })
  email: string;

  @Prop()
  password: string;

  @Prop({ type: Boolean, default: true })
  ativo: boolean;

  @Prop({ type: JSON })
  permissoes: JSON;
}

export const UsuariosSchema = SchemaFactory.createForClass(Usuarios);
