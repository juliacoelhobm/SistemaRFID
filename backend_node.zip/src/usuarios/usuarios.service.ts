import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotAcceptableException,
} from '@nestjs/common';
import { CreateUsuarioDto } from './dto/create-usuario.dto';
import { UpdateUsuarioDto } from './dto/update-usuario.dto';
import { EmpresasService } from 'src/empresas/empresas.service';
import { NotificationsService } from 'src/notifications/notifications.service';
import { InjectModel } from '@nestjs/mongoose';
import { FilterQuery, Model } from 'mongoose';
import { Usuarios } from './schemas/usuarios.schemas';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { NotificationDto } from 'src/notifications/dto/create-notification.dto';
import { UpdateNotificationDto } from 'src/notifications/dto/update-notification.dto';
import { MailService } from './../mail/mail.service';
@Injectable()
export class UsuariosService {
  constructor(
    @InjectModel('Usuarios') private readonly usuariosModel: Model<Usuarios>,
    private readonly empresasService: EmpresasService,
    private readonly notificationsService: NotificationsService,
    private readonly toolsService: ToolsService,
    private mailService: MailService
  ) {}

  async create(createUsuarioDto: CreateUsuarioDto) {
    if (createUsuarioDto.password != createUsuarioDto.confirmPassword) {
      throw new NotAcceptableException('Senhas diferentes!');
    }
    const empresa = await this.empresasService.findOne(
      createUsuarioDto.empresa,
    );
    if (!empresa) {
      throw new NotAcceptableException('Empresa não existe!');
    }
    createUsuarioDto.password = await this.toolsService.encrypt(
      createUsuarioDto.password,
    );
    try {
      const token = Math.floor(1000 + Math.random() * 9000).toString();
      const createdUsuario = new this.usuariosModel(createUsuarioDto);
      
      const newUser = await createdUsuario.save();
      const mail = await this.mailService.sendUserConfirmation(createUsuarioDto, token);
      console.log('mail ==>>', mail)
      return newUser;
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }
  }

  async findAll() {
    return await this.usuariosModel.find().exec();
  }

  async findOne(id: string) {
    try {
      return await this.usuariosModel
        .findById(id)
        .select({
          empresa: 1,
          nome: 1,
          email: 1,
          permissoes: 1,
          ativo: 1,
        })
        .exec();
    } catch {
      return null;
    }
  }

  async findByEmail(email: string) {
    try {
      return await this.usuariosModel.findOne({ email }).lean().exec();
    } catch {
      return null;
    }
  }

  async update(id: string, updateUsuarioDto: UpdateUsuarioDto) {
    if (updateUsuarioDto.empresa) {
      const empresa = await this.empresasService.findOne(
        updateUsuarioDto.empresa,
      );
      if (!empresa) {
        throw new NotAcceptableException('Empresa não existe!');
      }
    }
    if(updateUsuarioDto.password){
      this.updatePassword(id,updateUsuarioDto)
    }
    await this.usuariosModel.updateOne({ _id: id }, updateUsuarioDto).exec();
    return await this.findOne(id);
  }

  async remove(id: string) : Promise<any>{
    //throw new ForbiddenException('Não pode remover');
     return await this.usuariosModel.deleteOne({_id:id}).exec();
  }

  async updatePassword(id: string, dt:any) {
    if (dt.password != dt.confirmPassword) {
      throw new NotAcceptableException('Senhas diferentes!');
    }
    if (dt.password.length < 5) {
      throw new NotAcceptableException('Senhas muito pequena!');
    }
    const dado = { password: null };
    dado.password = await this.toolsService.encrypt(dt.password);
    await this.usuariosModel.updateOne({ _id: id }, dado);
    return true;
  }

  async verifyPassword(id: string, pwd: string) {
    const usuario = await this.usuariosModel
      .findById(id)
      .select({ password: 1 })
      .lean()
      .exec();
    if (!usuario) return false;
    return await this.toolsService.compareEncypt(pwd, usuario.password);
  }

  enablePush = async (
    user_id: number,
    update_dto: NotificationDto,
  ): Promise<any> => {
    const user = await this.usuariosModel.findOne({
      where: { _id: user_id },
    });
    return await this.notificationsService.acceptPushNotification(
      user,
      update_dto,
    );
  };

  disablePush = async (
    user_id: number,
    update_dto: UpdateNotificationDto,
  ): Promise<void> => {
    const user = await this.usuariosModel.findOne({
      where: { _id: user_id },
    });
    await this.notificationsService.disablePushNotification(user, update_dto);
  };

  getPushNotifications = async (): Promise<any> => {
    return await this.notificationsService.getNotifications();
  };
  async consultar(dt: FilterQuery<Usuarios>) {
    console.log('compare', dt)
    
    return await this.usuariosModel.find(dt).populate('usuario','',this.usuariosModel).exec();
  }
}
