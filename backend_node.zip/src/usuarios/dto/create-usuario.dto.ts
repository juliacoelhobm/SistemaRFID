import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEmail,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class CreateUsuarioDto {
  @ApiProperty({
    description: 'Nome do usuário',
    minLength: 5,
    maxLength: 255,
  })
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @MinLength(5, { message: ValidatorMessage.MinLength })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  nome: string;

  @ApiProperty()
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  empresa: string;

  @ApiProperty({
    description: 'email do usuário',
  })
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @IsEmail({ message: ValidatorMessage.IsEmail })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  email: string;

  @ApiProperty()
  @IsBoolean({ message: ValidatorMessage.IsBoolean })
  ativo: boolean;

  @ApiProperty()
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @MinLength(5, { message: ValidatorMessage.MinLength })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  password: string;

  @ApiProperty()
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @MinLength(5, { message: ValidatorMessage.MinLength })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  confirmPassword: string;

  @ApiProperty()
  permissoes: JSON;

  @ApiProperty()
  usuario: string;

  createdAt: Date;
  updatedAt: Date;
}
