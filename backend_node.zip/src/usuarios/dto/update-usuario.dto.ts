import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEmail,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class UpdateUsuarioDto {
  @ApiProperty({
    description: 'Nome do usuário',
    minLength: 5,
    maxLength: 255,
  })
  @IsString({ message: ValidatorMessage.IsString })
  @IsOptional()
  nome: string;

  @ApiProperty()
  @IsOptional()
  empresa: string;

  @ApiProperty()
  @IsOptional()
  password: string;

  @ApiProperty({
    description: 'email do usuário',
  })
  @IsOptional()
  email: string;

  @ApiProperty()
  @IsBoolean({ message: ValidatorMessage.IsBoolean })
  @IsOptional()
  ativo: boolean;

  @ApiProperty()
  @IsOptional()
  permissoes: JSON;
}
