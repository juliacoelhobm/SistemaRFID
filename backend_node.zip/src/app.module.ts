import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

import { MongooseModule } from '@nestjs/mongoose';
import { AuthModule } from './auth/auth.module';
import { EmpresasModule } from './empresas/empresas.module';
import { UsuariosModule } from './usuarios/usuarios.module';
import { ProdutosModule } from './produtos/produtos.module';
import { MovimentacaoProdutosModule } from './movimentacao-produtos/movimentacao-produtos.module';
import { CategoriasModule } from './categorias/categorias.module';
import { ReferenciaModule } from './referencia/referencia.module';
import { InventarioModule } from './inventario/inventario.module';
import { InfluxdbModule } from './shared/services/influxdb/influxdb.module';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { LoggingInterceptor } from './shared/interceptors/logger.interceptor';
import { ImagensModule } from './imagens/imagens.module';
import { EventsModule } from './events/events.module';

import { NotificationsModule } from './notifications/notifications.module';
import { MailModule } from './mail/mail.module';


@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    MongooseModule.forRoot(process.env.MONGODB_URI),
    EmpresasModule,
    UsuariosModule,
    AuthModule,
    ReferenciaModule,
    ProdutosModule,
    MovimentacaoProdutosModule,
    CategoriasModule,
    InfluxdbModule,
    ImagensModule,
    EventsModule,
    NotificationsModule,
    InventarioModule,
    MailModule,
  ],
  controllers: [],
  providers: [{ provide: APP_INTERCEPTOR, useClass: LoggingInterceptor }],
})
export class AppModule {}
