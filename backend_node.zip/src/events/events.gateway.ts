import { MessagePattern, Payload, Ctx } from '@nestjs/microservices';
import {
    MessageBody,
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer,
    WsResponse,
  } from '@nestjs/websockets';
  import { from, Observable } from 'rxjs';
  import { map } from 'rxjs/operators';
  import { Server } from 'socket.io';

  
  @WebSocketGateway({
    cors: {
      origin: '*',
    },
  })
  export class EventsGateway {
    @WebSocketServer()
    server: Server;
  
    @SubscribeMessage('events')
    findAll(@MessageBody() data: any): Observable<WsResponse<number>> {
      return from([1, 2, 3,4]).pipe(map(item => ({ event: 'events', data: item })));
    }

   
    @SubscribeMessage('sendMessage')
    async sendMessage(@MessageBody() data: any, @Ctx() client: Server){
        console.log('sendMessage', data)
        this.server.emit('receiveMessage', data);
    }
    @SubscribeMessage('userPosition')
    async userPosition(@MessageBody() data: any, @Ctx() client: Server){
        console.log('userPosition', data)
        this.server.emit('receiveUpdatePosition', data);
    }

  
    @SubscribeMessage('identity')
    async identity(@MessageBody() data: number): Promise<number> {
      return data;
    }
  }