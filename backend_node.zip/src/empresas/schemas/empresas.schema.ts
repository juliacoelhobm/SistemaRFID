import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type EmpresasDocument = Empresas & Document;

@Schema({ timestamps: true, collection: 'empresas' })
export class Empresas {
  @Prop({ required: true })
  nome: string;

  @Prop({
    required: true,
    index: true,
    unique: true,
  })
  email: string;

  @Prop()
  telefone: string;

  @Prop()
  cnpj: string;

  @Prop()
  ativo: boolean;

  @Prop()
  inicioAtividades: Date;

  @Prop()
  finalAtividades: Date;

  @Prop()
  site?: string;

  @Prop()
  observacao: string;

  @Prop({ type: JSON })
  endereco: JSON;

  // @Prop()
  // @Field(() => Date, { description: 'Created At' })
  // createdAt?: Date;

  // @Prop()
  // @Field(() => Date, { description: 'Updated At' })
  // updatedAt?: Date;
}

export const EmpresasSchema = SchemaFactory.createForClass(Empresas);
