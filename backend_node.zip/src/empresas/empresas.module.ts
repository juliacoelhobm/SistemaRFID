import { Module } from '@nestjs/common';
import { EmpresasService } from './empresas.service';
import { EmpresasController } from './empresas.controller';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { MongooseModule } from '@nestjs/mongoose';
import { EmpresasSchema } from './schemas/empresas.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Empresas', schema: EmpresasSchema }]),
  ],
  controllers: [EmpresasController],
  providers: [EmpresasService, ToolsService],
  exports: [EmpresasService],
})
export class EmpresasModule {}
