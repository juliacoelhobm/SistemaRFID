import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEmail,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class CreateEmpresaDto {
  @ApiProperty({
    description: 'Nome da empresa',
    minLength: 5,
    maxLength: 255,
  })
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @MinLength(5, { message: ValidatorMessage.MinLength })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  nome: string;

  @ApiProperty({
    description: 'email da empresa',
  })
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(255, { message: ValidatorMessage.MaxLength })
  @IsEmail({ message: ValidatorMessage.IsEmail })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  email: string;

  @ApiProperty({
    description: 'Número do telefone (99)99999-9999',
  })
  @IsString({ message: ValidatorMessage.IsString })
  telefone: string;

  @ApiProperty()
  @IsString({ message: ValidatorMessage.IsString })
  @MaxLength(18, { message: ValidatorMessage.MaxLength })
  cnpj?: string;

  @ApiProperty()
  @IsBoolean({ message: ValidatorMessage.IsBoolean })
  ativo: boolean;

  @ApiProperty()
  inicioAtividades?: Date;

  @ApiProperty()
  finalAtividades?: Date;

  @ApiProperty()
  observacao?: string;

  @ApiProperty()
  site?: string;

  @ApiProperty()
  endereco: JSON;

  @ApiProperty()
  usuario: string;

  createdAt: Date;
  updatedAt: Date;
}
