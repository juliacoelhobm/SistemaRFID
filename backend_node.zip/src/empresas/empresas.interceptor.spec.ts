import { EmpresasInterceptor } from './empresas.interceptor';

describe('EmpresasInterceptor', () => {
  it('should be defined', () => {
    expect(new EmpresasInterceptor()).toBeDefined();
  });
});
