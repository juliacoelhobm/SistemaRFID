import {
  BadRequestException,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Empresas } from './schemas/empresas.schema';
import { CreateEmpresaDto } from './dto/create-empresa.dto';
import { UpdateEmpresaDto } from './dto/update-empresa.dto';

@Injectable()
export class EmpresasService {
  constructor(
    @InjectModel('Empresas') private readonly empresasModel: Model<Empresas>,
  ) {}

  async create(createEmpresaDto: CreateEmpresaDto): Promise<any> {
    try {
      const createdEmpresa = new this.empresasModel(createEmpresaDto);
      return await createdEmpresa.save();
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }
  }

  async findAll(): Promise<any> {
    return await this.empresasModel.find().exec();
  }

  async findOne(id: string) {
    try {
      //.lean() para plain object
      return await this.empresasModel.findById(id).exec();
    } catch {
      return null;
    }
  }

  async update(id: string, updateEmpresaDto: UpdateEmpresaDto) {
    await this.empresasModel.updateOne({ _id: id }, updateEmpresaDto).exec();
    return await this.findOne(id);
  }

  async remove(id: string) {
    throw new ForbiddenException('Não pode remover');
    // return await this.empresasModel.deleteOne({_id:id}).exec();
  }
}
