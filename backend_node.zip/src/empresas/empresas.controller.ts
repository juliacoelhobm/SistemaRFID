import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UseGuards,
} from '@nestjs/common';
import { EmpresasService } from './empresas.service';
import { CreateEmpresaDto } from './dto/create-empresa.dto';
import { UpdateEmpresaDto } from './dto/update-empresa.dto';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { ToolsService } from 'src/shared/services/tools/tools.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('CRUD de empresas')
@Controller('empresas')
@UseInterceptors(new DataformInterceptor())
@UseGuards(AuthGuard('jwt'))
export class EmpresasController {
  constructor(
    private readonly empresasService: EmpresasService,
    private readonly toolsService: ToolsService,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Inserindo empresas' })
  create(
    @Body() createEmpresaDto: CreateEmpresaDto,
  ): Promise<CreateEmpresaDto> {
    createEmpresaDto.ativo = this.toolsService.convertToBoolean(
      createEmpresaDto.ativo,
    );

    createEmpresaDto.endereco = this.toolsService.convertJson(
      createEmpresaDto.endereco,
    );

    return this.empresasService.create(createEmpresaDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar todas as empresas.' })
  @ApiResponse({ status: 200, description: 'Sucesso na consulta' })
  findAll(): Promise<any> {
    return this.empresasService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Listar uma empresa pelo id.' })
  findOne(@Param('id') id: string) {
    return this.empresasService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualiza empresa' })
  async update(
    @Param('id') id: string,
    @Body() updateEmpresaDto: UpdateEmpresaDto,
  ) {
    return await this.empresasService.update(id, updateEmpresaDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Exclui o registro.' })
  // @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id') id: string) {
    return this.empresasService.remove(id);
  }
}
