import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';

import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class ConsultarImagem {
  @ApiProperty()
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  referencia: string;

  @ApiProperty()
  @IsOptional()
  idReferencia: string;

  @ApiProperty()
  @IsOptional()
  contador: string;

  @ApiProperty()
  @IsOptional()
  empresa: string;
}
