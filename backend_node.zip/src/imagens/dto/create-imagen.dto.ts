import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import validatorMessages from 'src/shared/lang/pt-br/validator.messages';

export class CreateImagenDto {
  @ApiProperty({ type: String })
  @IsNotEmpty({ message: validatorMessages.IsNotEmpty })
  @IsString({ message: validatorMessages.IsString })
  referencia: string;

  @ApiProperty({ type: String })
  @IsNotEmpty({ message: validatorMessages.IsNotEmpty })
  @IsString({ message: validatorMessages.IsString })
  idReferencia: string;

  @ApiProperty({ type: String })
  @IsOptional()
  titulo: string;

  @ApiProperty({ type: String })
  @IsOptional()
  empresa: string;

  @ApiProperty({ type: String })
  @IsOptional()
  descricao: string;

  @ApiProperty({ type: Number })
  @IsNotEmpty({ message: validatorMessages.IsNotEmpty })
  @IsString({ message: validatorMessages.IsString })
  contador: string;
}
