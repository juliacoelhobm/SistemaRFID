import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type ImagensDocument = Imagens & Document;

@Schema({ timestamps: true, collection: 'imagens' })
export class Imagens {
  @Prop({ required: true })
  referencia: string; // produto por exemplo

  @Prop({ required: true })
  idReferencia: string; // id do produto por exemplo

  @Prop({ required: true })
  tipo: string;

  @Prop({ required: true })
  caminho: string;

  @Prop({ required: true })
  nome: string;

  @Prop({ required: true })
  extensao: string;

  @Prop({ required: false })
  titulo: string;

  @Prop({ required: false })
  descricao: string;

  @Prop({ required: true })
  tamanho: number;

  @Prop({ required: true })
  usuario: string;

  @Prop({ required: true })
  empresa: string;

  @Prop({ required: true })
  contador: number;
}

export const ImagensSchema = SchemaFactory.createForClass(Imagens);
