import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreateImagenDto } from './dto/create-imagen.dto';
// import { UpdateImagenDto } from './dto/update-imagen.dto';
import { Imagens } from './schemas/imagens.schemas';
import { writeFileSync } from 'fs';
import { join } from 'path';
import { UserEntity } from 'src/shared/entities/user.entity';

@Injectable()
export class ImagensService {
  constructor(
    @InjectModel('Imagens')
    private readonly imagemModel: Model<Imagens>,
  ) {}

  async salvarArquivo(createImagenDto: CreateImagenDto, arquivo: Express.Multer.File, user: UserEntity) {
    const existeRepetido = {
      referencia: createImagenDto.referencia,
      idReferencia: createImagenDto.idReferencia,
      contador: +createImagenDto.contador,
    };

    console.log('arquivo',arquivo)

    const existe = await this.consultarImagens(existeRepetido);
    if (existe.length) {
      console.log('imagem ja existe')
      throw new BadRequestException('este arquivo já existe.');
    }

    const arqNome = arquivo.originalname.split('.');
    const dado: any = {};
    dado.referencia = createImagenDto.referencia;
    dado.idReferencia = createImagenDto.idReferencia;
    dado.tipo = arquivo.mimetype;
    dado.caminho = process.env.ARQUIVOS || '';
    dado.extensao = arqNome.pop();
    dado.nome = arqNome.join('.');
    dado.tamanho = arquivo.size;
    dado.titulo = createImagenDto?.titulo || '';
    dado.descricao = createImagenDto?.descricao || '';
    dado.usuario = user.id;
    dado.empresa = createImagenDto.empresa || user.empresa;
    dado.contador = +createImagenDto.contador;
    let retornoSave: any = {};
    try {
      const createdImage = new this.imagemModel(dado);
      retornoSave = await createdImage.save();
      console.log('image retornoSave',retornoSave)
    } catch (error) {
      throw new BadRequestException({
        statusCode: 400,
        message: error.message,
        error: 'Conflict',
        keyValue: error.keyValue,
        keyPattern: error.keyPattern,
        mongoCode: error.code,
      });
    }

    writeFileSync(
      join(dado.caminho, retornoSave._id.toString()),
      arquivo.buffer,
    );
    console.log('retornoSave', retornoSave)
    return retornoSave;
  }

  async consultarImagens(dt:any) {
    return await this.imagemModel.find(dt);
  }

  async lerImagemExibindo(id: string) {
    return await this.imagemModel.findById(id).lean();
  }

  async remove(id: string) : Promise<any>{
    //throw new ForbiddenException('Não pode remover');
    return await this.imagemModel.deleteOne({_id:id}).exec();
  }
}
