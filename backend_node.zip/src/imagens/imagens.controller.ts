import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  UseInterceptors,
  UseGuards,
  UploadedFile,
  BadRequestException,
  Res,
  Delete,
} from '@nestjs/common';
import { ImagensService } from './imagens.service';
import { CreateImagenDto } from './dto/create-imagen.dto';
// import { UpdateImagenDto } from './dto/update-imagen.dto';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { FileInterceptor } from '@nestjs/platform-express';
import { UserEntity } from 'src/shared/entities/user.entity';
import { User } from 'src/shared/decorators/user.decorator';
import { ConsultarImagem } from './dto/consultar-imagem.dto';
import { Response } from 'express';
import { readFileSync } from 'fs';

@Controller('imagens')
@ApiTags('CRUD para imagens.')
export class ImagensController {
  constructor(private readonly imagensService: ImagensService) {}

  @Post()
  @ApiOperation({ summary: 'Inserindo imagem.' })
  @UseInterceptors(FileInterceptor('arquivo'))
  @UseInterceptors(new DataformInterceptor())
  @UseGuards(AuthGuard('jwt'))
  create(
    @Body() createImagenDto: CreateImagenDto,
    @UploadedFile() arquivo: Express.Multer.File,
    @User() user: UserEntity,
  ) {
    console.log('arquivo', arquivo)
    if (!arquivo) {
      console.log('nao tem arquivo')
      throw new BadRequestException('arquivo não pode estar vazio');
    }
    return this.imagensService.salvarArquivo(createImagenDto, arquivo, user);
  }

  @Post('consultar')
  @ApiOperation({
    summary: 'Lista dados da imagem por referencia, idReferencia, contador.',
  })
  @UseInterceptors(new DataformInterceptor())
  @UseGuards(AuthGuard('jwt'))
  async consultar(@Body() body: ConsultarImagem, @User() user: UserEntity) {
    const corpo: any = {};
    if (body.referencia) {
      corpo.referencia = body.referencia;
    }
    if (body.idReferencia) {
      corpo.idReferencia = body.idReferencia;
    }
    if (body.contador) {
      corpo.contador = body.contador;
    }
    if (body.empresa) {
      corpo.empresa = body.empresa;
    } else{
      corpo.empresa = user.empresa;
    }
    

    return await this.imagensService.consultarImagens(corpo);
  }

  @Get('imagem/:id')
  @ApiOperation({
    summary:
      'Apresenta a imagem no formato designado pelo navegador, sem precisar de senhas.',
  })
  async lerImagem(@Param('id') id: string, @Res() response: Response) {
    const retorno: any = await this.imagensService.lerImagemExibindo(id);
    if (!retorno) {
      return null;
    }
    response.set({
      'Content-Type': retorno.tipo,
      'Content-Length': retorno.tamanho,
    });
    response.send(readFileSync(`${retorno.caminho}/${retorno._id}`));
  }
  
  @Delete(':id')
  @ApiOperation({ summary: 'Exclui o produto.' })
  remove(@Param('id') id: string) {
    return this.imagensService.remove(id);
  }
}
