import { Module } from '@nestjs/common';
import { ImagensService } from './imagens.service';
import { ImagensController } from './imagens.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ImagensSchema } from './schemas/imagens.schemas';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Imagens', schema: ImagensSchema }]),
  ],
  controllers: [ImagensController],
  providers: [ImagensService],
  exports: [ImagensService],
})
export class ImagensModule {}
