import {
  Controller,
  Get,
  Post,
  Body,
  UseInterceptors,
  UseGuards,
  Param,
} from '@nestjs/common';
import { MovimentacaoProdutosService } from './movimentacao-produtos.service';
import { CreateMovimentacaoProdutoDto } from './dto/create-movimentacao-produto.dto';
// import { UpdateMovimentacaoProdutoDto } from './dto/update-movimentacao-produto.dto';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { DataformInterceptor } from 'src/shared/interceptors/data.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { User } from 'src/shared/decorators/user.decorator';
import { UserEntity } from 'src/shared/entities/user.entity';
import { ObjectID  } from "bson";
import { ConsultarMovimentacaoProduto } from './dto/consultar-movimentacao-produto.dto';

@ApiTags('CRUD de movimentação de produtos.')
@Controller('movprod')
@UseInterceptors(new DataformInterceptor())
@UseGuards(AuthGuard('jwt'))
export class MovimentacaoProdutosController {
  constructor(
    private readonly movimentacaoProdutosService: MovimentacaoProdutosService,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Inserindo produtos.' })
  create(
    @Body() createMovimentacaoProdutoDto: CreateMovimentacaoProdutoDto,
    @User() user: UserEntity,
  ) {
    return this.movimentacaoProdutosService.create(
      createMovimentacaoProdutoDto,
      user,
    );
  }

  /*
  @Get()
  findAll() {
    return this.movimentacaoProdutosService.findAll();
  }
  */

  @Get(':id')
  @ApiOperation({ summary: 'Pesquisando produtos.' })
  findOne(@Param('id') id: string) {
    return this.movimentacaoProdutosService.findOne(id);
  }

  @Post('/consultar/tipo')
  @ApiOperation({
    summary: 'Lista inventarios por tipo agregado a data',
  })
  async consultarTipo(@Body() body: ConsultarMovimentacaoProduto, @User() user: UserEntity) {
    return await this.movimentacaoProdutosService.consultarTipo(user.empresa);
  }

  @Post('consultar')
  @ApiOperation({
    summary: 'Lista inventarios por referencia, idReferencia, categoria, usuario, date.',
  })
  @UseInterceptors(new DataformInterceptor())
  @UseGuards(AuthGuard('jwt'))
  async consultar(@Body() body: ConsultarMovimentacaoProduto, @User() user: UserEntity) {
    const corpo: any = {};
    
    if (body.produto) {
      corpo.produto = body.produto
    }
    if (body.usuario) {
      console.log('usuario',body.usuario)
      //mongoose.Types.ObjectId(id)
      try{
        const obj = new ObjectID(body.usuario) 
        const id = body.usuario
        console.log(obj)
        console.log(id)
        
        const condicao = [{usuario:obj}, {usuario:id}]
        corpo["$or"] = condicao
        // corpo["usuario"] =  id || obj;
      }
      catch(error){
        console.log(error)

      }
      
      
    }
    if (body.startDate && body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        $lt: body.endDate,
      }
      
    }
    if (body.startDate && !body.endDate) {
      corpo.createdAt = {
        $gte: body.startDate,
        //$lt: body.endDate,
      }
    }
    if (!body.startDate && body.endDate) {
      corpo.createdAt = {
        //$gte: body.startDate,
        $lt: body.endDate,
      }
    }
    //corpo.empresa = user.empresa;

    return await this.movimentacaoProdutosService.consultar(corpo);
  }

  /*
  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() updateMovimentacaoProdutoDto: UpdateMovimentacaoProdutoDto,
  ) {
    return this.movimentacaoProdutosService.update(
      +id,
      updateMovimentacaoProdutoDto,
    );
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.movimentacaoProdutosService.remove(+id);
  }

  */
}
