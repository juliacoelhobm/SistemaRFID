import { PartialType } from '@nestjs/swagger';
import { CreateMovimentacaoProdutoDto } from './create-movimentacao-produto.dto';

export class UpdateMovimentacaoProdutoDto extends PartialType(CreateMovimentacaoProdutoDto) {}
