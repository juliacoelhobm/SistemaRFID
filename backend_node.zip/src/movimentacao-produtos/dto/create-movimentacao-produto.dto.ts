import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsNumber } from 'class-validator';
import { EntradaSaida } from 'src/shared/enums/entradasaida.enum';
import { TiposCodigosRfid } from 'src/shared/enums/tiposcodigosrfid.enum';
import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

class Codigo {
  @ApiProperty({
    name: 'tipo',
    enum: TiposCodigosRfid,
  })
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  @IsEnum(TiposCodigosRfid, { message: ValidatorMessage.IsEnum })
  tipo: TiposCodigosRfid;

  @ApiProperty({ type: String })
  codigo: string;
}

export class CreateMovimentacaoProdutoDto {
  @ApiProperty({
    description: 'Tipo do codigo de barras e codigo de barras.',
    type: Codigo,
  })
  codigo: Codigo;

  @ApiProperty({ name: 'tipo', enum: EntradaSaida })
  tipo: EntradaSaida;

  @ApiProperty()
  @IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  @IsNumber()
  quantidade: number;

  /*
  @ApiProperty()
  @IsNumber()
  EstoqueAnterior: number;

  @ApiProperty()
  @IsNumber()
  EstoqueAtual: number;
*/

  @ApiProperty()
  empresa: string;

  @ApiProperty()
  localizacao: JSON;
  /*
  @ApiProperty()
  usuario: string;
  */

  @ApiProperty({
    description: 'Dados complementares a pesquisa de produtos.',
    type: JSON,
  })
  dadosAdicionais: JSON;

  @ApiProperty({
    description: 'Localização do produto dentro da empresa.',
    type: JSON,
  })
  localizacaoInterna: JSON;
}
