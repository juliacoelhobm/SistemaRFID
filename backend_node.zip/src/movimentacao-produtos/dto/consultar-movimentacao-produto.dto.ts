import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';

import ValidatorMessage from 'src/shared/lang/pt-br/validator.messages';

export class ConsultarMovimentacaoProduto {
  
  
  @ApiProperty()
  //@IsNotEmpty({ message: ValidatorMessage.IsNotEmpty })
  @IsOptional()
  empresa: string;

  @ApiProperty()
  @IsOptional()
  produto: string;

  @ApiProperty()
  @IsOptional()
  usuario: string;

  @ApiProperty()
  @IsOptional()
  _id: string;

  @ApiProperty()
  @IsOptional()
  tipo: string;

  @ApiProperty()
  @IsOptional()
  startDate: string;

  @ApiProperty()
  @IsOptional()
  endDate: string;
}
