import { Test, TestingModule } from '@nestjs/testing';
import { MovimentacaoProdutosService } from './movimentacao-produtos.service';

describe('MovimentacaoProdutosService', () => {
  let service: MovimentacaoProdutosService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MovimentacaoProdutosService],
    }).compile();

    service = module.get<MovimentacaoProdutosService>(MovimentacaoProdutosService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
