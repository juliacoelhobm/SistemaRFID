import { Module } from '@nestjs/common';
import { MovimentacaoProdutosService } from './movimentacao-produtos.service';
import { MovimentacaoProdutosController } from './movimentacao-produtos.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { MovimentacaoProdutosSchema } from './schemas/movimentacao-produtos.schema';
import { ProdutosModule } from 'src/produtos/produtos.module';
import { UsuariosSchema, UsuariosDocument } from 'src/usuarios/schemas/usuarios.schemas';
import { UsuariosModule } from 'src/usuarios/usuarios.module';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'MovimentacaoProduto', schema: MovimentacaoProdutosSchema },
      { name: 'Usuarios', schema: UsuariosSchema },
      { name: 'UsuariosDocument', schema: UsuariosSchema },
    ]),
    ProdutosModule,
    UsuariosModule,
  ],
  controllers: [MovimentacaoProdutosController],
  providers: [MovimentacaoProdutosService],
})
export class MovimentacaoProdutosModule {}
