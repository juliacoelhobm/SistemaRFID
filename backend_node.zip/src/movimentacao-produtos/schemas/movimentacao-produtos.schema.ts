import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Empresas } from 'src/empresas/schemas/empresas.schema';
import { Produtos } from 'src/produtos/schemas/produtos.schema';
import { Usuarios } from 'src/usuarios/schemas/usuarios.schemas';
import { EntradaSaida } from 'src/shared/enums/entradasaida.enum';

export type MovimentacaoProdutosDocument = MovimentacaoProdutos & Document;

class Codigo {
  @Prop({ type: String, required: true, uppercase: true })
  tipo: string;
  @Prop({ required: true })
  codigo: string;
}

@Schema({ timestamps: true, collection: 'movimentacaoprodutos' })
export class MovimentacaoProdutos {
  @Prop({ type: JSON })
  codigo: Codigo;

  @Prop({ type: Types.ObjectId, ref: () => Produtos })
  produto: Produtos;

  @Prop({ required: true }) //entrada-saida
  tipo: EntradaSaida;

  @Prop({ required: true })
  quantidade: number;

  @Prop()
  EstoqueAnterior: number;

  @Prop()
  EstoqueAtual: number;

  @Prop({ type: Types.ObjectId, ref: () => Empresas })
  empresa: Empresas;

  @Prop({ type: Types.ObjectId, ref: () => Usuarios })
  usuario: Usuarios;

  @Prop({ type: JSON })
  localizacao: JSON;

  @Prop({ type: JSON })
  dadosAdicionais: JSON;

  @Prop({ type: JSON })
  localizacaoInterna: JSON;
}

export const MovimentacaoProdutosSchema =
  SchemaFactory.createForClass(MovimentacaoProdutos);
