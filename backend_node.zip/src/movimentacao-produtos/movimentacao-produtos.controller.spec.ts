import { Test, TestingModule } from '@nestjs/testing';
import { MovimentacaoProdutosController } from './movimentacao-produtos.controller';
import { MovimentacaoProdutosService } from './movimentacao-produtos.service';

describe('MovimentacaoProdutosController', () => {
  let controller: MovimentacaoProdutosController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [MovimentacaoProdutosController],
      providers: [MovimentacaoProdutosService],
    }).compile();

    controller = module.get<MovimentacaoProdutosController>(MovimentacaoProdutosController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
