import {
  BadRequestException,
  Injectable,
  NotAcceptableException,
  NotFoundException,
} from '@nestjs/common';
import { FilterQuery, Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { ProdutosService } from 'src/produtos/produtos.service';
import { UserEntity } from 'src/shared/entities/user.entity';
import { CreateMovimentacaoProdutoDto } from './dto/create-movimentacao-produto.dto';
import { MovimentacaoProdutos } from './schemas/movimentacao-produtos.schema';
import { Usuarios, UsuariosDocument } from 'src/usuarios/schemas/usuarios.schemas';


@Injectable()
export class MovimentacaoProdutosService {
  constructor(
    @InjectModel(Usuarios.name) private usuariosModel: Model<UsuariosDocument>,
    @InjectModel('MovimentacaoProduto')
    
    private readonly movimentacaoProdutoModel: Model<MovimentacaoProdutos>,
    private readonly produtosService: ProdutosService,
  ) {}

  async create(
    createMovimentacaoProdutoDto: CreateMovimentacaoProdutoDto,
    user: UserEntity,
  ) {
    if (createMovimentacaoProdutoDto.quantidade <= 0 && (createMovimentacaoProdutoDto.tipo == "Entrada" || createMovimentacaoProdutoDto.tipo == "Saida") ) {
      throw new BadRequestException('Quantidade menor ou igual a zero.');
    }

    const produto: any = await this.produtosService.findRfid(
      createMovimentacaoProdutoDto.codigo,
    );
    if (!produto.length) {
      throw new NotFoundException('Produto não encontrado!');
    }
    if (produto.length > 1) {
      throw new NotAcceptableException('Mais de um produto encontrado!');
    }

    const dado: any = {};
    dado.produto = produto[0].id;
    dado.tipo = createMovimentacaoProdutoDto.tipo;
    dado.quantidade = createMovimentacaoProdutoDto.quantidade;
    const estoque = produto[0].quantidade;
    let valorEstoque = 0
    if(createMovimentacaoProdutoDto.tipo == 'Entrada'){
      valorEstoque = createMovimentacaoProdutoDto.quantidade
    } else if(createMovimentacaoProdutoDto.tipo == 'Saida'){
      valorEstoque = -1 * createMovimentacaoProdutoDto.quantidade;
    }

    dado.EstoqueAnterior = estoque;
    dado.EstoqueAtual = estoque + valorEstoque;
    dado.empresa = user.empresa
    dado.localizacao = structuredClone(
      createMovimentacaoProdutoDto.localizacao,
    );
    dado.usuario = user.id;
    dado.dadosAdicionais = structuredClone(
      createMovimentacaoProdutoDto.dadosAdicionais,
    );
    dado.localizacaoInterna = structuredClone(
      createMovimentacaoProdutoDto.localizacaoInterna,
    );

    // atualiza estoque
    const atualizado = await this.produtosService.updateEstoque(
      produto[0].id,
      valorEstoque,
    );
    try {
      const createdMovimentacao = new this.movimentacaoProdutoModel(dado);
      return await createdMovimentacao.save();
    } catch (error) {
      throw new BadRequestException('Erro ao salvar movimentação!');
    }
    return dado;
  }

  async findOne(id: string) {
    return await this.movimentacaoProdutoModel
      .find({ produto: id })
      .sort({ createdAt: -1 })
      .populate('usuario','',this.usuariosModel);
  }
  async consultar(dt: FilterQuery<MovimentacaoProdutos>) {
    console.log('compare', dt)
    
    return await this.movimentacaoProdutoModel.find(dt).populate('usuario','',this.usuariosModel).exec();
  }
  async consultarTipo(empresaId:any) {
    var lista : any;

    var match_stage = {
      $match: { 
        $or:  [ {empresa : empresaId} , {empresa:null} ]} 
      }
    

    var group_stage = {
        $group:     {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
          "entrada": {
              "$sum": { "$cond": [
                  { "$eq": [ "$tipo", 'Entrada' ] },
                  1,
                  0
              ]}
          },
          "Saida": {
              "$sum": { "$cond": [
                  { "$eq": [ "$tipo", 'Saida' ] },
                  1,
                  0
              ]}
          },
          "totalCount": {
              "$sum": { "$cond": [{$or : [{ $eq: [ "$tipo", "Entrada"] },
                                          { $eq: [ "$tipo","Saida"] }
                                    ]},
                                    1,
                                    0]}
          }
      }
    }

    var pipeline = [ match_stage, group_stage ]
    console.log(pipeline)
    try { 
      //.lean() para plain object
      lista = await this.movimentacaoProdutoModel.aggregate(pipeline).limit(30)
    } catch(error) {
      console.log('error', error)
      
    }
    console.log('lista',lista)
    return lista;
    //return await this.movimentacaoProdutoModel.find(dt).populate('usuario','',this.usuariosModel).exec();
  }
}
