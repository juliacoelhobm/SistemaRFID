import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  BadGatewayException,
} from '@nestjs/common';
import { InfluxdbService } from '../services/influxdb/influxdb.service';
import { ILogger } from '../interfaces/logger.interface';
import { tap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  constructor(private readonly influxService: InfluxdbService) {}

  private writeData(data: ILogger, now: number) {
    const { host, method, user_agent, endpoint, id, email, empresa } = data;
    try {
      this.influxService.influx.writeMeasurement('logs', [
        {
          tags: { host, endpoint },
          fields: {
            method,
            user_agent,
            id_user: `${id}`,
            email,
            empresa: `${empresa}`,
            response_timeout: Date.now() - now,
          },
        },
      ]);
    } catch (error) {}
  }

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const ctx = context.switchToHttp();
    const request = ctx.getRequest();

    const { host } = request.headers;
    const email = request.user?.email || '';
    const empresa = request.user?.empresa || '';
    const nome = request.user?.nome || '';
    const id = request.user?._id || request.user?.id;

    const user_agent = request.headers['user-agent'];
    const { url, method } = request;
    const now = Date.now();

    return next.handle().pipe(
      tap(() => {
        this.writeData(
          {
            endpoint: url,
            method,
            user_agent,
            host,
            id,
            email,
            empresa,
            nome,
          } as ILogger,
          now,
        );
        catchError((err) => {
          throw new BadGatewayException();
        });
      }),
    );
  }
}
