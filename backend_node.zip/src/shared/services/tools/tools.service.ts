import { Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';

@Injectable()
export class ToolsService {
  convertToBoolean(vlr: any): boolean {
    if (typeof vlr == 'string') {
      const txt = vlr.toUpperCase();
      return txt == 'TRUE' || txt == 'T';
    } else if (typeof vlr == 'number') {
      return vlr != 0;
    }
    return vlr;
  }
  convertJson(str: any) {
    if (this.isJson(str)) {
      if (typeof str === 'string') {
        return JSON.parse(str);
      } else {
        return str;
      }
    }
    return {};
  }

  isJson(item) {
    item = typeof item !== 'string' ? JSON.stringify(item) : item;

    try {
      item = JSON.parse(item);
    } catch (e) {
      return false;
    }

    if (typeof item === 'object' && item !== null) {
      return true;
    }

    return false;
  }

  async encrypt(pwd: string): Promise<string> {
    const saltOrRounds = +(process.env.CRYPT_SALT || 10);
    return await bcrypt.hash(pwd, saltOrRounds);
  }

  async compareEncypt(pwd, hash): Promise<boolean> {
    return await bcrypt.compare(pwd, hash);
  }
}
