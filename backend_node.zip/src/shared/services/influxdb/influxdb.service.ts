import { InfluxDB, ISingleHostConfig } from 'influx';
import { Injectable, OnModuleInit } from '@nestjs/common';

@Injectable()
export class InfluxdbService implements OnModuleInit {
  influx: InfluxDB;
  constructor() {}

  async onModuleInit() {
    this.influx = this.createInstance();
  }

  private createInstance(): any {
    return new InfluxDB(this.getConfig());
  }

  private getConfig(): ISingleHostConfig {
    return {
      database: process.env.INFLUX_DB,
      host: process.env.INFLUX_HOST,
      port: +process.env.INFLUX_PORT,
      username: process.env.INFLUX_USER,
      password: process.env.INFLUX_PASSWORD,
    };
  }
}
