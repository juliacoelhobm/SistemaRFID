export class UserEntity {
  id: string;
  email: string;
  empresa: string;
}
