export enum EntradaSaida {
  Entrada = 'Entrada',
  Saida = 'Saida',
  Inventario = 'Inventario',
  Anotacao = 'Anotacao',
  Locacao_saida = 'Locacao_saida',
  Locacao_retorno = 'Locacao_retorno',
  Locacao_entrada_destino = 'Locacao_saida',
  Locacao_saida_destino = 'Locacao_retorno',
}
