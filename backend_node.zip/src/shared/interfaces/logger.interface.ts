export interface ILogger {
  host: string;
  endpoint: string;
  method: string;
  user_agent: string;
  response_timeout: string;
  cookies?: string;
  user?: string;
  error?: string;
  accessToken?: string;
  refreshToken?: string;
  id?: string;
  email?: string;
  empresa?: string;
  nome?: string;
}
